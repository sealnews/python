
import sqlalchemy
from sqlalchemy.orm import relationship, aliased
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import Column, Integer, String, Text, Table, Boolean, DateTime
from sqlalchemy import ForeignKey
from CommonBase import Base



#Base=declarative_base()


class TokenSentenceTable(Base):
  __tablename__ = 'tokensentencetable'

  #tentityTable=aliased(
  id=Column(Integer, primary_key=True)

  sentencetable_id = Column(Integer, ForeignKey('sentencetable.id') )
  sentencetable= relationship("SentenceTable", 
    back_populates="tokensentencetable_list", foreign_keys=[sentencetable_id])

  tokensentencecontent=Column(Text)

  def __repr__(self):
    return "<TokenSentenceTable(id='%d', sentencetable_id='%d', tokensentencecontent='%s' )>" % (self.id, 
            self.sentencetable_id, 
            self.tokensentencecontent, 
            )


