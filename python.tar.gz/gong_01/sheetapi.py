#! /usr/bin/env python

from __future__ import print_function
import httplib2
import os

from apiclient import discovery
from oauth2client import client
from oauth2client import tools
from oauth2client.file import Storage

try:
    import argparse
    flags = argparse.ArgumentParser(parents=[tools.argparser]).parse_args()
except ImportError:
    flags = None

# If modifying these scopes, delete your previously saved credentials
# at ~/.credentials/sheets.googleapis.com-python-quickstart.json
#SCOPES = 'https://www.googleapis.com/auth/spreadsheets.readonly'
SCOPES = 'https://www.googleapis.com/auth/spreadsheets'
CLIENT_SECRET_FILE = 'client_secret.json'
APPLICATION_NAME = 'FriendlyCharPythonUpdate'


def get_credentials():
    """Gets valid user credentials from storage.

    If nothing has been stored, or if the stored credentials are invalid,
    the OAuth2 flow is completed to obtain the new credentials.

    Returns:
        Credentials, the obtained credential.
    """
    credential_dir = os.path.join('/media', 'sf_xubuntu-01-share/tensorflowOrgExamplePython/scrapy-tutorial/gong_01/credentials')
    if not os.path.exists(credential_dir):
        os.makedirs(credential_dir)
    credential_path = os.path.join(credential_dir,
    #                               'client_secret.json')
                                   'sheets.googleapis.com-python-quickstart.json')

    #home_dir = os.path.expanduser('~')
    #credential_dir = os.path.join(home_dir, '.credentials')
    #if not os.path.exists(credential_dir):
    #    os.makedirs(credential_dir)
    #credential_path = os.path.join(credential_dir,
    #                               'sheets.googleapis.com-python-quickstart.json')


    print ('credential_path 1 = ', credential_path)
    store = Storage(credential_path)
    print ('credential_path 2 = ', credential_path)
    credentials = store.get()
    print ('credential_path 3 = ', credential_path)
    
    if not credentials or credentials.invalid:
        print ('credential_path 4 = ', credential_path)
        flow = client.flow_from_clientsecrets(CLIENT_SECRET_FILE, SCOPES)
        print ('credential_path 5 = ', credential_path)
        flow.user_agent = APPLICATION_NAME

        #if flags:
        credentials = tools.run_flow(flow, store, flags)
        #else: # Needed only for compatibility with Python 2.6
        #    credentials = tools.run(flow, store)

        print('Storing credentials to ' + credential_path)
    
    return credentials

def main():
    """Shows basic usage of the Sheets API.

    Creates a Sheets API service object and prints the names and majors of
    students in a sample spreadsheet:
    https://docs.google.com/spreadsheets/d/1BxiMVs0XRA5nFMdKvBdBZjgmUUqptlbs74OgvE2upms/edit
    """
    credentials = get_credentials()
    http = credentials.authorize(httplib2.Http())
    discoveryUrl = ('https://sheets.googleapis.com/$discovery/rest?'
                    'version=v4')
    service = discovery.build('sheets', 'v4', http=http,
                              discoveryServiceUrl=discoveryUrl)

    spreadsheetId = '1BcdJAywX2573xzlmXjggmEoyKzFF7wn4f5uK3kpUScA'
    rangeName = 'Sheet1!A2:D4'
    result = service.spreadsheets().values().get(
        spreadsheetId=spreadsheetId, range=rangeName).execute()
    values = result.get('values', [])

    if not values:
        print('No data found.')
    else:
        print('Name, Major:')
        for row in values:
            # Print columns A and E, which correspond to indices 0 and 4.
            #print('%s, %s' % (row[0], row[4]))
            print('row = ', row )

    values = [
        [ 
           5,
           "f5", 
           "l5", 
           5, 
        ],
        [ 
           6,
           "f6", 
           "l6", 
           6, 
        ],
     ]
    write_range_name = 'Sheet1!A6:D7'
    value_input_option = 'RAW'
    body = { 'values' : values}
    result = service.spreadsheets().values().update(
      spreadsheetId=spreadsheetId, range=write_range_name,
      valueInputOption=value_input_option, body=body).execute()  
    print ('result=',result)

if __name__ == '__main__':
    main()
