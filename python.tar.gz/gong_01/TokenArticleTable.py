
import sqlalchemy
from sqlalchemy.orm import relationship, aliased
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import Column, Integer, String, Text, Table
from sqlalchemy import ForeignKey
from CommonBase import Base
#from SentenceTable import SentenceTable


#Base=declarative_base()


class TokenArticleTable(Base):
  __tablename__ = 'tokenarticletable'

  id=Column(Integer, primary_key=True)

  articletable_id = Column(Integer, ForeignKey('articletable.id'))
  articletable = relationship("ArticleTable", back_populates="tokenarticletable_list", foreign_keys=[articletable_id])

  tokencontent = Column(Text)
  listofrelatedarticle = Column(Text)


  def __repr__(self):
    return "<TokenArticleTable(id='%d', articletable_id='%d', tokencontent='%s', listofrelatedarticle='%s')>" % (self.id, self.articletable_id, self.tokencontent, self.listofrelatedarticle)

