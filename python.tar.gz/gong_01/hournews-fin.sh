#!/bin/bash

#for i in a,b c,d ; do
#  IFS=",";
#  set $i;
#  echo $1 $2;
#done

if [ $# == 1 ]; then
  domainname=$1
  sleep 15
  idnumber=`docker ps | awk '{ if (NR > 1) print $1 }'`
  docker restart $idnumber
  sleep 15
  echo "-----> starting $domainname "
  scrapy crawl gong_01 -a domaintorun=$domainname -a newstypetorun=latestfinnews
  exit 0
fi


for i in hkej_now aastocks_now ; do
  sleep 15
  idnumber=`docker ps | awk '{ if (NR > 1) print $1 }'`
  docker restart $idnumber
  sleep 15
  echo "-----> starting $i "
  scrapy crawl gong_01 -a domaintorun=$i -a newstypetorun=latestfinnews
done

