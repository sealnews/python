import tensorflow as tf
import numpy as np


class TextCNN(object):
    """
    A CNN for text classification.
    Uses an embedding layer, followed by a convolutional, max-pooling and softmax layer.
    """
    def __init__(
      self, sequence_length, num_classes, vocab_size,
      embedding_size, filter_sizes, num_filters, l2_reg_lambda=0.0):

        # Placeholders for input, output and dropout
        self.input_x = tf.placeholder(tf.int32, [None, sequence_length], name="input_x")
        self.input_y = tf.placeholder(tf.float32, [None, num_classes], name="input_y")
        self.dropout_keep_prob = tf.placeholder(tf.float32, name="dropout_keep_prob")

        # Keeping track of l2 regularization loss (optional)
        l2_loss = tf.constant(0.0)
        print("-----TextCNN __init__ sequence_length=",sequence_length,
		" num_classes=",num_classes," vocab_size=", vocab_size," embedding_size=",
		embedding_size, " filter_sizes=",filter_sizes," num_filters=", num_filters," end")
        # Embedding layer
        with tf.device('/cpu:0'), tf.name_scope("embedding"):
            self.W = tf.Variable(
                tf.random_uniform([vocab_size, embedding_size], -1.0, 1.0),
                name="W")
            self.embedded_chars = tf.nn.embedding_lookup(self.W, self.input_x)
            print("-----TextCNN self.embedded_chars.shape=", self.embedded_chars.get_shape()," end\n")
            self.embedded_chars_expanded = tf.expand_dims(self.embedded_chars, -1)
            print("-----TextCNN self.embedded_chars_expanded.shape=", self.embedded_chars_expanded.get_shape()," end\n")
            # self.W is 18760(row)x128(col) matrix that need to be learned, 128 is the number of filter
            # or can call it as dimension, so each word in vocabulary(18760) has different random value
            #for now per filter/dimension, 
            #later after each sess.run, it will be update this value
            # self.embedded_chars will contain a 56(row)x128(col) this is a lookup table to the 18760x128
            # 56 : the largest number of words in a sentence within the sample(like rt-polarity.pos) 
            # for example "babyseal like to swim and to eat" sentence(input_x which is the placeholder
            # it will be 7 words in a sentence , tensor will find the corresponding each word like 
            # babyseal in which row of 18760(each row is a dict like "babyseal" : [0.1, 0.2,...]" contain
            # babyseal , put inside the 
            # self.embedded_chars[0][:] because it has 128 column for each row, (each row 
            # represent a word in the sentence  , each column of this row represent the value of the word in
            # vocabulary's column
            # is the same meaning as above
            
	        

        # Create a convolution + maxpool layer for each filter size
        pooled_outputs = []
        for i, filter_size in enumerate(filter_sizes):
            print("-----TextCNN i=", i,"filter_sizes=",filter_sizes," filter_size=",filter_size," end")
            with tf.name_scope("conv-maxpool-%s" % filter_size):
                # Convolution Layer
                filter_shape = [filter_size, embedding_size, 1, num_filters]
                print("-----TextCNN filter_shape=",filter_shape," filter_size=", filter_size,"embedding_size=",embedding_size," num_filters=",num_filters," end")
                W = tf.Variable(tf.truncated_normal(filter_shape, stddev=0.1), name="W")
                b = tf.Variable(tf.constant(0.1, shape=[num_filters]), name="b")                
                """
-----TextCNN self.embedded_chars_expanded.shape= (?, 56, 128, 1)  end
-----TextCNN i= 0 filter_sizes= [3, 4, 5]  filter_size= 3  end
-----TextCNN filter_shape= [3, 128, 1, 128]  filter_size= 3 embedding_size= 128  num_filters= 128  end
-----TextCNN conv.get_shape()= (?, 54, 1, 128)
-----TextCNN pooled_outputs.get_shape()= 1  h.get_shape()= (?, 54, 1, 128)  ksize= [1, 54, 1, 1]
-----TextCNN pooled.get_shape= (?, 1, 1, 128)  end

-----TextCNN i= 1 filter_sizes= [3, 4, 5]  filter_size= 4  end
-----TextCNN filter_shape= [4, 128, 1, 128]  filter_size= 4 embedding_size= 128  num_filters= 128  end
-----TextCNN conv.get_shape()= (?, 53, 1, 128)
-----TextCNN pooled_outputs.get_shape()= 2  h.get_shape()= (?, 53, 1, 128)  ksize= [1, 53, 1, 1]
-----TextCNN pooled.get_shape= (?, 1, 1, 128)  end
                """                
                conv = tf.nn.conv2d(
                    self.embedded_chars_expanded, #actually this is the x of Wx+b formula
                    # self.embedded_chars_expanded =
                    # (?, 56,128,1) = (batch_no, in_height(row),in_width(column), in_channels)
                    W,
                    # (3/4/5, 128,1,128)= (filter_height, filter_width, in_channels, out_channels)
                    # in other layer, W may have [... , ... , out_channels] : the out_channels is the 
                    # output shape 
                    strides=[1, 1, 1, 1],
                    padding="VALID", #this mean no padding the edge will be vanish very quickly
                    name="conv")
                print("-----TextCNN conv.get_shape()=", conv.get_shape())
                # Apply nonlinearity
                h = tf.nn.relu(tf.nn.bias_add(conv, b), name="relu")
                # Maxpooling over the outputs
                pooled = tf.nn.max_pool(
                    h,
                    ksize=[1, sequence_length - filter_size + 1, 1, 1],
                    # h :    (?,53,1,128) : batch_number, height, width, channel
                    # ksize :(1,53,1,1) : dimension match the above tensor "h" 
                    # so, it will h/ksize on each dimension, it become (1,1,1,128)
                    strides=[1, 1, 1, 1],
                    padding='VALID',
                    name="pool")
                pooled_outputs.append(pooled)
                print("-----TextCNN pooled_outputs.get_shape()=",len(pooled_outputs), " h.get_shape()=",
                h.get_shape(), " ksize=", [1, sequence_length - filter_size + 1, 1, 1] )
                print("-----TextCNN pooled.get_shape=", pooled.get_shape()," end\n")
        # Combine all the pooled features
        num_filters_total = num_filters * len(filter_sizes)
        print("-----TextCNN num_filters_total=", num_filters_total,"filter_sizes=",filter_sizes,"len(filter_sizes)=", len(filter_sizes)," num_filters=",num_filters," end\n")
        print("-----TextCNN pooled_output=", pooled_outputs," end-pooled_output")
        # there are three Tensor objects in pooled_outputs, each object has 
        # (?,1,1,128) : each object has 4 dimensions
        # tf.concat(pooled_outputs, x) x : will be 0-3=axis1-4
        # tf.concat will concat on the axis "x"
        # for our case concat 128 +128+128=384       
        self.h_pool = tf.concat(pooled_outputs, 3)
        print("-----TextCNN 1 self.h_pool.get_shape()=",self.h_pool.get_shape())
        self.h_pool_flat = tf.reshape(self.h_pool, [-1, num_filters_total])
        #self.h_pool_flat.get_shape()= (?, 384)  self.h_drop= (?, 384)
        print("-----TextCNN 2 self.h_pool_flat.get_shape()=",self.h_pool_flat.get_shape())

        # Add dropout
        with tf.name_scope("dropout"):
            self.h_drop = tf.nn.dropout(self.h_pool_flat, self.dropout_keep_prob)
            print("-----TextCNN self.h_pool_flat.get_shape()=",self.h_pool_flat.get_shape()," self.h_drop=", self.h_drop.get_shape())

        """
-----TextCNN num_filters_total= 384 filter_sizes= [3, 4, 5] len(filter_sizes)= 3  num_filters= 128  end

-----TextCNN 1 self.h_pool.get_shape()= (?, 1, 1, 384)
-----TextCNN 2 self.h_pool_flat.get_shape()= (?, 384)
-----TextCNN self.h_pool_flat.get_shape()= (?, 384)  self.h_drop= (?, 384)
-----TextCNN num_filters_total= 384  num_classes= 2
-----TextCNN W= (384, 2)  end
-----TextCNN self.scores= (?, 2)  end
-----TextCNN self.predictions= (?,)  end
-----TextCNN losses= (?,)  end
-----TextCNN self.loss= ()  end
        
        """
        # Final (unnormalized) scores and predictions
        with tf.name_scope("output"):
            W = tf.get_variable(
                "W",
                shape=[num_filters_total, num_classes],
                initializer=tf.contrib.layers.xavier_initializer())
            b = tf.Variable(tf.constant(0.1, shape=[num_classes]), name="b")
            l2_loss += tf.nn.l2_loss(W)
            l2_loss += tf.nn.l2_loss(b)
            # self.h_drop : x : [1(row),384(col)] , W : [384(row), 2(col)
            # xW = [ (1 row), (2 col) ]
            self.scores = tf.nn.xw_plus_b(self.h_drop, W, b, name="scores")
            # 
            # self.prediction will have two possible outcome value
            self.predictions = tf.argmax(self.scores, 1, name="predictions")
            print("-----TextCNN num_filters_total=",num_filters_total," num_classes=", num_classes)
            print("-----TextCNN W=", W.get_shape()," end") 
            print("-----TextCNN self.scores=", self.scores.get_shape()," end") 
            print("-----TextCNN self.predictions=", self.predictions.get_shape()," end") 
            
        # CalculateMean cross-entropy loss
        with tf.name_scope("loss"):
            losses = tf.nn.softmax_cross_entropy_with_logits(logits=self.scores, labels=self.input_y)
            self.loss = tf.reduce_mean(losses) + l2_reg_lambda * l2_loss
            print("-----TextCNN losses=", losses.get_shape()," end") 
            print("-----TextCNN self.loss=", self.loss.get_shape()," end") 

        # Accuracy
        # check whether the prediction(after all the formula like convolution, maxpool....)
        # is same as the supposed y value
        with tf.name_scope("accuracy"):
            correct_predictions = tf.equal(self.predictions, tf.argmax(self.input_y, 1))
            self.accuracy = tf.reduce_mean(tf.cast(correct_predictions, "float"), name="accuracy")
