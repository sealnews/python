#!/bin/bash

if [ $# == 1 ]; then
  domainname=$1
  sleep 15
  idnumber=`docker ps | awk '{ if (NR > 1) print $1 }'`
  docker restart $idnumber
  sleep 15
  echo "-----> starting $domainname "
  scrapy crawl gong_01 -a domaintorun=$domainname -a newstypetorun=financialnews
  exit 0
fi


for i in hkej aastocks orientaldaily appledaily ; do
  sleep 15
  idnumber=`docker ps | awk '{ if (NR > 1) print $1 }'`
  docker restart $idnumber
  sleep 15
  echo "-----> starting $i "
  scrapy crawl gong_01 -a domaintorun=$i -a newstypetorun=financialnews
done



