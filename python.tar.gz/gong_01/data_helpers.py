

import numpy as np
import re
import itertools
from collections import Counter
from datetime import datetime, timedelta,timezone
from gong_01_db import GongAllTable


def datasampling (train_percentage, casetuples , caselabels, final_tup_t, final_lab_t , final_tup_d, final_lab_d ) :
    devsample = int(train_percentage * float(len(casetuples)))
    if devsample == 0 :
      #the sample is <10 , at least use one
      if len(casetuples) == 1:
        print ('load_data_and_labels error casetuples ==1')
        return None, None, None, None
      casetuples_train , casetuples_dev = casetuples[:-1] , casetuples[-1:] 
      caselabels_train , caselabels_dev = caselabels[:-1] , caselabels[-1:] 
    else :  
      casetuples_train , casetuples_dev = casetuples[:-1 * devsample] , casetuples[-1 * devsample:] 
      caselabels_train , caselabels_dev = caselabels[:-1 * devsample] , caselabels[-1 * devsample:] 

    if ( len(final_lab_t) == 0) and ( len(final_lab_d) == 0 ) :
      return final_tup_t + casetuples_train, np.array( caselabels_train ),  final_tup_d + casetuples_dev, np.array( caselabels_dev )

    else : 
      return final_tup_t + casetuples_train, np.concatenate( [final_lab_t , caselabels_train] ,0),  final_tup_d + casetuples_dev, np.concatenate( [final_lab_d , caselabels_dev ], 0)





def load_data_and_labels(train_percentage, breakornot=True, needtraintype=True ):
    """
    Loads MR polarity data from files, splits the data into words and generates labels.
    Returns split sentences and labels.
    """

    gong=GongAllTable('gong.db')
    session=gong.init_all_table()

    final_tuple_t = []
    final_tuple_d = []
    final_label_t = []
    final_label_d = []

    """
    # Load data from files
    ## tuples (in_casenumber , sentencetableid, tokensentencetableid, tokensentence_content )
    casetuples_1 = gong.getTokenSentencesByCaseNumber ( 1, in_needTrainType=needtraintype , in_tokenbreak=breakornot ) 
    # [ 14, 13, 12, 11, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1 ] 
    # for example for case 1
    # [ 0,  0,  0,  0,  0,  0, 0, 0, 0, 0, 0, 0, 0, 1 ] 
    if needtraintype :
      caselabels_1 = [ [  0,  1,  0, 0, 0, 0, 0, 0, 0, 0, 0, 0 ] for _ in range(len(casetuples_1)) ]
    else :
      if len(casetuples_1) == 0 :
        caselabels_1 = []
      else :
        caselabels_1 = [ 1 for _ in range(len(casetuples_1)) ]
    final_tuple_t,final_label_t,final_tuple_d,final_label_d = datasampling(train_percentage, casetuples_1,caselabels_1, final_tuple_t, final_label_t, final_tuple_d, final_label_d )
    """

    largestcasenumber = 12
    for casenumber in range(1,largestcasenumber) :
      casetuples = gong.getTokenSentencesByCaseNumber ( casenumber, in_needTrainType=needtraintype , in_tokenbreak=breakornot )
      if casetuples is None or len(casetuples) == 1:
        continue
      if needtraintype :
        caselabels = [ [0] + [0] * (casenumber -1) + [1] + [0] * (largestcasenumber - casenumber -1 )  for _ in range(len(casetuples )) ]
      else :
        caselabels = [ casenumber for _ in range(len(casetuples )) ]
      final_tuple_t,final_label_t,final_tuple_d,final_label_d = datasampling(train_percentage, casetuples,caselabels, final_tuple_t, final_label_t, final_tuple_d, final_label_d )


    # tuples (in_casenumber , sentencetableid, tokensentencetableid, tokensentence_content )
    return final_tuple_t,final_label_t,final_tuple_d,final_label_d  





def batch_iter(data, batch_size, num_epochs, shuffle=True):
    """
    Generates a batch iterator for a dataset.
    """
    data = np.array(data)
    data_size = len(data)
    num_batches_per_epoch = int((len(data)-1)/batch_size) + 1
    #print ("-----batch_iter 1 data_size=",data_size," num_batches_per_epoch=", num_batches_per_epoch)
    for epoch in range(num_epochs):
        # Shuffle the data at each epoch
        #print ("-----batch_iter epoch=",epoch)
        if shuffle:
            shuffle_indices = np.random.permutation(np.arange(data_size))
            shuffled_data = data[shuffle_indices]
        else:
            shuffled_data = data
        for batch_num in range(num_batches_per_epoch):
            start_index = batch_num * batch_size
            end_index = min((batch_num + 1) * batch_size, data_size)
            #print ("-----batch_iter batch_num=",batch_num," start_index=",start_index, \
            #" end_index=",end_index)
            yield shuffled_data[start_index:end_index]
