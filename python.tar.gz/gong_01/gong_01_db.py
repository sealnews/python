import sqlalchemy
from sqlalchemy.orm import relationship
from sqlalchemy.orm import sessionmaker
from sqlalchemy.orm import aliased
from sqlalchemy.sql import exists
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import Column, Integer, String, Text, Table, func, exc
from sqlalchemy import ForeignKey, create_engine, Sequence, and_, or_, text
from ArticleTable import ArticleTable, Base as articleBase
from CaseTable import CaseTable, Base as caseBase
from CategoryTable import CategoryTable, Base as categoryBase
from DomainTable import DomainTable, Base as domainBase
from EntityTable import EntityTable, Base as entityBase
from FirstSubDomainTable import FirstSubDomainTable, Base as firstSubBase
from SentenceTable import SentenceTable, Base as sentenceBase
from NameEntityTable import NameEntityTable, Base as nameentityBase
from TokenArticleTable import TokenArticleTable, Base as tokenarticleBase
from TokenSentenceTable import TokenSentenceTable, Base as tokensentenceBase
from CommonBase import Base
from datetime import datetime, timedelta, timezone
import lxml.html
import jieba
import re
import os
import threading
import fcntl

class GongAllTable():
  database_loc='gong.db'

  def __init__(self, database_loc):
    self.database_loc=database_loc
    #self.engine=create_engine('sqlite:///%s'%self.database_loc , echo=True)
    self.engine=create_engine('sqlite:///%s'%self.database_loc , echo=False, connect_args={ 'timeout' : 1000 } )
    Base.metadata.create_all(self.engine)
    jieba.load_userdict('/media/sf_xubuntu-01-share/tensorflowOrgExamplePython/scrapy-tutorial/gong_01/combine-dict-zhwiki.txt')
    self._save_article_entry = threading.Lock()


#from DomainTable import DomainTable
#domaintable_entry=DomainTable(
#baseurl='http://hk.on.cc',chi_name='東網',eng_name='orientaldaily_net')
#gong.create_default_value()
#gong.create_default_value_article()
#r_dict=gong.getRetrieveURLPair(nowTime)
#newArticleEntry=ArticleTable( firstsubdomaintable_id=11, finalurl='http://www.881903.com/Page/ZH-TW/newsdetail.aspx?ItemId=952177&csid=261_341', timestampondoc=nowTime, timestamponretrieve=nowTime, title='塔拉斯將掠過海南島南部', content='中央氣象台預測，熱帶風暴塔拉斯，今日將會在海南島南部近海掠過，隨後進入北部灣 ，預料星期一凌晨，在越南北部沿海登陸。海南島南部地區，將出現暴雨，三亞等城市有五十毫米以上的雨量。', jpegname='hello-1.jpeg')
#r=session.query(FirstSubDomainTable).get(11)
#


  def init_all_table(self):
    Session=sessionmaker(bind=self.engine)
    self.session=Session()
    self.session.commit()
    result = self.session.query(DomainTable).all()
    print('----------------- init_all_table 0.1=', result)
    return self.session

  def getRetrieveURLPair(self, subsitute_time=None):
    #in query, the order of selection matter

    print('----------------- getRetrieveURLPair 0=', subsitute_time)
    result = self.session.query(DomainTable).all()
    print('----------------- getRetrieveURLPair 0.1=', result)


    result=self.session.query(FirstSubDomainTable.id, DomainTable.eng_name, CategoryTable.eng_name,  DomainTable.baseurl + FirstSubDomainTable.firstsubd ).join(CategoryTable).filter(and_(DomainTable.id == FirstSubDomainTable.domaintable_id, FirstSubDomainTable.categorytable_id == CategoryTable.id)).all()
    final_dict = {}
    print('----------------- getRetrieveURLPair 1=', result)
    #nowTime=datetime.now(timezone(timedelta(hours=8)))
    if subsitute_time is not None:
      for i in result :
        final_dict[ (i[1],i[2]) ] = [ i[0], 
                re.sub(r'MM', "%02d"%subsitute_time.month, 
                  re.sub(r'DD', "%02d"%subsitute_time.day, 
                    re.sub(r'YYYY', str(subsitute_time.year), i[3]))) ]
    else :
      final_dict= { (i[1],i[2]) : [ i[0], i[3] ] for i in result }

    #(DomainTable.eng_name, CategoryTable.eng_name):
    #    [FirstSubDomainTable.id, DomainTable.baseurl 
    #                             + FirstSubDomainTable.firstsubd ]
    print('----------------- getRetrieveURLPair 3')
    for i in final_dict:
      print(i , '\n')
    return final_dict


  def getLatestUpdateTimeAndUrl(self, row_id):
    entry= self.session.query( FirstSubDomainTable).get(row_id)
    result= (entry.latestupdateurl, entry.latestupdatetime)
    return result

  def setLatestUpdateTimeAndUrl(self, row_id, in_datetime, in_url ):
    try : 
      result=self.session.query(FirstSubDomainTable).filter(FirstSubDomainTable.id == row_id).update({FirstSubDomainTable.latestupdateurl : in_url , FirstSubDomainTable.latestupdatetime : in_datetime} )
      self.session.commit()
    except exc.SQLAlchemyError :
      print ('error error error setlatestupdatetimeandurl exception')
      self.session.rollback()
      result=0
    else : 
      if result != 1 :
        print ('error error error setLatestUpdateTimeAndUrl')
    return result
#
#in_firstsubdomaintableid=11
#in_finalurl='http://www.881903.com/Page/ZH-TW/newsdetail.aspx?ItemId=952274&csid=261_341'
#nowTime=datetime.now(timezone(timedelta(hours=8)))
#in_timestampondoc=nowTime
#in_title='馬季煞科1174億投注額刷新紀錄'
#in_content='今季馬季煞科，全季總投注額一千一百七十四億元，較上季度增加一成，刷新單季最高投注紀錄，應支付的博彩稅是一百三十一億元，上升8%，全季有二百一十七萬入場人次，增長6%。 年度獎項方面，巴西籍騎師莫雷拉，全季勝出破紀錄的一百七十一場冠軍，第三次奪得冠軍騎師榮銜。澳洲籍練馬師蔡約翰全季共勝出九十五場頭馬，同樣刷新紀錄，第九度榮膺冠軍練馬師；佳龍駒成為本年度馬王，是首匹勝出香港四歲馬經典賽事系列全部三關賽事的良駒，但在五月出賽時不幸嚴重受傷，其後去世。'
#in_content='江蘇。常熟位，市一在「幢兩在」層高在(出租在)凌晨在！發生在【二十在】在人死，在三人、在二人死。在人死亡《在三人》發生火在；蘇常熟在：蘇常在，常熟市在。在晨四時許第三次奪得冠軍騎師榮銜。澳洲籍練馬師蔡約翰全季共勝出九十五場頭馬，同樣第九度榮膺冠軍練馬師；佳龍駒成為本年度馬王傷，其後去世。'
#in_jpegname='jpeg_name1'
#result=gong.setArticleEntry(in_firstsubdomaintableid, in_finalurl, nowTime, in_title, in_content, in_jpegname)



  def setArticleEntry(self, in_firstsubdomaintableid, in_finalurl, in_timestampondoc, in_title, in_content, in_jpegname, in_imageurl=None, parseIt=False) :
    try : 
      with self._save_article_entry : 
        #double check the same entry
        result = self.session.query( ArticleTable.id, ArticleTable.timestampondoc ).filter(ArticleTable.firstsubdomaintable_id == in_firstsubdomaintableid ).filter( ArticleTable.finalurl == in_finalurl ).filter( ArticleTable.title == in_title ).all()
        if len(result) > 0 :
          print (" error : why there is a duplicate article entry id=",result[0][0], ",timestampondoc=", result[0][1], ", in_timestampondoc=", in_timestampondoc)
          return 0 

        nowTime=datetime.now(timezone(timedelta(hours=8)))
        print('-------------- 1')
        #try to remove unnecessary character
        for x in ['【本報訊】', '(星島日報報道)','【明報專訊】','【本報綜合報道】' ]:
          if x in in_content :
            in_content=in_content.lstrip(x)
            #only either one will occur
            break

        print('-------------- 1.1')
        newArticleEntry=ArticleTable( firstsubdomaintable_id=in_firstsubdomaintableid, finalurl=in_finalurl, timestampondoc=in_timestampondoc, timestamponretrieve=nowTime, title=in_title, content=in_content, jpegname=in_jpegname, imageurl=in_imageurl)
        self.session.add(newArticleEntry)
        self.session.commit()
        #print('-------------- 2')
        row=self.session.query(ArticleTable).order_by(ArticleTable.id.desc()).first()
        result=row.id     
      if parseIt :
        #print('-------------- 3')
        if row.content is None or (len(row.content) < 2) :
          combine_content = row.title
        else :
          root = lxml.html.fromstring(in_content)
          listStripHTMLTagsString = root.xpath("//text()")
          combine_content = ''.join(listStripHTMLTagsString) 
        strip_content=re.sub(r"[^\u4e00-\u9fff()?.,%0-9\u3002\u300c\u300d\uff01\u3010\u3011\uff0c\u3001\u3002\u300a\u300b\uff1a\uff1b]"," ",combine_content)

        out_list=[strip_content.strip()] 
        #for sentenceDivider in ['\u3002','\uff01','\uff1b', '\u3000'] :
        for sentenceDivider in ['\u3002\u300d', '\uff01\u300d', '\uff1f\u300d','\u3002', '\uff01', '\uff1b', '\u3000'] :
          #print('-------------- 4', sentenceDivider, '----')
          intermediate_list=[]
          for index_list in out_list:
            #print('-------------- 5', index_list, '---------')
            intermediate_list=intermediate_list + index_list.strip().split(sentenceDivider)
            #print('-------------- 6', index_list, '---------')
          out_list= intermediate_list
          #print('-------------- 7')
        articlerow_id=row.id
        previousSentRowId=None
        out_list = [x for x in out_list if len(x) > 0 ]
        for indSentence in out_list:
          #print('-------------- 8----', indSentence, '---------')
          indSentence = re.sub(r'\s{2,}', ' ', indSentence)
          sentencerow_id = self.setSentenceEntry(articlerow_id, 
                                                 indSentence, 
                                                 previousSentRowId, 
                                                 None)
          #print('-------------- 9 ---',sentencerow_id, '---------')
          if previousSentRowId is not None :
            #print('-------------- 10 ---', 'prev=',previousSentRowId, '--next=', sentencerow_id)
            self.setSentenceNextSentenceID( previousSentRowId, 
                                            sentencerow_id)
          previousSentRowId = sentencerow_id
                                        
    except exc.SQLAlchemyError :
      print ('error error error setArticleEntry exception')
      result=0
      self.session.rollback()
    else : 
      print ('----> setArticleEntry good')
      self.session.commit()
    return result


  def setSentenceNextSentenceID(self, in_rowid, in_nextsentenceid) :
    try:
      result=self.session.query(SentenceTable).filter(SentenceTable.id == in_rowid).update({SentenceTable.nextsentence_id : in_nextsentenceid } )
    except exc.SQLAlchemyError :
      result=0
      print ('error error error setSentenceNextSentenceID exception')
      self.session.rollback()
    else :
      self.session.commit()
    return result


  def setSentenceEntry(self, in_articletableid, 
                       in_sentencecontent, 
                       in_previoussentenceid, 
                       in_nextsentenceid) :
    try : 
      newSentenceEntry=SentenceTable( articletable_id=in_articletableid, sentencecontent=in_sentencecontent, previoussentence_id=in_previoussentenceid, nextsentence_id=in_nextsentenceid )
      self.session.add(newSentenceEntry)
      self.session.commit()
      row=self.session.query(SentenceTable).order_by(SentenceTable.id.desc()).first()
    except exc.SQLAlchemyError :
      print ('error error error setSentenceEntry exception')
      self.session.rollback()
      row_id=0
    else : 
      #print ('----> setSentenceEntry good')
      row_id=row.id
      self.session.commit()
    return row_id

  def getSentenceEntry(self, row_id=0):
    if row_id ==0 :
      #get the latest one
      entry= self.session.query( SentenceTable).order_by('-id').first()
    else :
      entry= self.session.query( SentenceTable).get(row_id)
    final_dict=entry.__dict__
    #print (final_dict)
    return final_dict
    

  def setNameEntityEntry(self, in_name, 
                       in_urllink ) :
    try : 
      if (self.session.query(NameEntityTable).filter(NameEntityTable.name == in_name).count() == 0) :
        print (' ------ > no entry setNameEntityEntry')
        newNameEntityEntry=NameEntityTable( name=in_name, urllink=in_urllink)
        self.session.add(newNameEntityEntry)
        self.session.commit()
        row_id = self.session.query(NameEntityTable.id).order_by(NameEntityTable.id.desc()).first()[0]
        print (' ------ > setNameEntityEntry row_id=',  row_id)
      else :
        print (' ------ > has entry setNameEntityEntry')
        row_id = self.session.query(NameEntityTable.id).order_by(NameEntityTable.id.desc()).first()
    except exc.SQLAlchemyError :
      print ('error error error setNameEntityEntry exception')
      self.session.rollback()
      row_id=0
    else : 
      #print ('----> setNameEntityEntry good')
      self.session.commit()
    return row_id


  def getTokenDailyNewsArticle(self, 
                               in_startTime, 
                               in_endTime,
                               in_domain_eng_name,
                               in_category_eng_name
                               ) :
    print (' time tokendaily 1 : ', datetime.now(timezone(timedelta(hours=8))) )

    result = self.session.query( FirstSubDomainTable.id ).join(DomainTable).join(CategoryTable).filter(and_(DomainTable.eng_name == in_domain_eng_name, CategoryTable.eng_name== in_category_eng_name )).all()
    if len(result) == 0:
      #empty result
      print (' error getTokenDailyNewsArticle 1')
      return 0

    print (' time tokendaily 2 : ', datetime.now(timezone(timedelta(hours=8))) )

    print ('result[0][0]=',result[0][0])
    print ('in_startTime=',in_startTime)
    print ('in_endTime=',in_endTime)
    result = self.session.query( ArticleTable.id, ArticleTable.content, ArticleTable.title ).filter(ArticleTable.firstsubdomaintable_id == result[0][0]).filter(and_( ArticleTable.timestampondoc >= in_startTime , ArticleTable.timestampondoc <= in_endTime)).all()

    print (' time tokendaily 3 : ', datetime.now(timezone(timedelta(hours=8))) )

    if len(result) == 0:
      #empty result
      print (' error getTokenDailyNewsArticle 2')
      return 0
    
    #start the tokenization
    #get the nameentity
    #nameentityTuple = self.session.query( NameEntityTable.name ).all()
    #nameentityList = [ re.sub(r'([\u4e00-\u9fff])' , r' \1', x[0]) for x in nameentityTuple ]

    articleTableIDList =[]
    resultList=[] 

    print (' time tokendaily 4 : ', datetime.now(timezone(timedelta(hours=8))) , ', len(result)=', len(result))

    for indTuple in result: 
        #with self.session.no_autoflush:
        articleTableIDList.append(indTuple[0]) 
        tokenContentTuples = self.session.query(TokenArticleTable.articletable_id, TokenArticleTable.tokencontent).filter(TokenArticleTable.articletable_id == indTuple[0]).all() 
        #if self.session.query(TokenArticleTable).filter(TokenArticleTable.articletable_id == indTuple[0]).count() >= 1:
        if tokenContentTuples is not None and len(tokenContentTuples) >= 1:
          #it has the entry
          resultList.append(tokenContentTuples[0])
          continue

        #let's start tokenization
        
        #strip_content = re.sub(r"[^\u4e00-\u9fff]", " ", indTuple[2] + ' ' + indTuple[2] + ' ' + indTuple[1][:150])
        strip_content = re.sub(r"[^\u4e00-\u9fff]", " ", indTuple[2] + ' ' + indTuple[1][:200])
        #strip_content = re.sub(r"\s{2,}", " ", " "+strip_content)
        #strip_content = re.sub(r'([\u4e00-\u9fff])' , r' \1', strip_content) 
        #for needleCount , needle in enumerate(nameentityList) :
        #  strip_content = strip_content.replace(needle, " " + nameentityTuple[needleCount][0])
        stoplist = ['的' , '在', '有', '他','為', '她', '到', '及','我', '係','與',  '和', '月',    '會','咁','佢', '但', '是', '就', '好', '亦', '嘅', '都', '唔', '於', '或', '時' , '由', '咗', '後', '仍' , '年', '日',  '冇', '多' , '至',    '哋', '吧','小' ]
        strip_content = re.sub(r'[的在有他為她到及我係與和月會咁佢但是就好亦嘅都唔於或時由咗後仍年日冇多至哋吧小]','' , strip_content)
      
        strip_content = ' '.join(jieba.cut(strip_content, cut_all=False))
     
        strip_content = re.sub(r'\s{2,}', ' ', strip_content)
        strip_content = re.sub(r'\u3000', '', strip_content)
 
        #write to database 
        newTokenArticleEntry=TokenArticleTable( articletable_id=indTuple[0], tokencontent=strip_content)
        self.session.add(newTokenArticleEntry)
        resultList.append((indTuple[0], strip_content))
      
    with open("databaselockfile", "w") as test_fd :
      print ("before locking ...", "domain=", 
        in_domain_eng_name, ", in_category_eng_name=" ,
        in_category_eng_name)
      fcntl.lockf(test_fd, fcntl.LOCK_EX)
      self.session.commit()
      print ("right before  releasing ...", "domain=", 
        in_domain_eng_name, ", in_category_eng_name=" ,
        in_category_eng_name)
      fcntl.lockf(test_fd, fcntl.LOCK_UN)
      print ("after locking ...", "domain=", 
        in_domain_eng_name, ", in_category_eng_name=" ,
        in_category_eng_name)


    print (' time tokendaily 5 : ', datetime.now(timezone(timedelta(hours=8))) )

    #for x in articleTableIDList :
    #  tokenContentTuples = self.session.query(TokenArticleTable.articletable_id, TokenArticleTable.tokencontent).filter(TokenArticleTable.articletable_id == x).one() 
    #  resultList.append(tokenContentTuples)

    #print (' time tokendaily 6 : ', datetime.now(timezone(timedelta(hours=8))) )

    return resultList
    #self.session.query 



  def getOneTokenSentence(self, 
                       in_sentencetableid = None) :
    result = self.session.query(TokenSentenceTable.id, TokenSentenceTable.tokensentencecontent ).filter( TokenSentenceTable.sentencetable_id == in_sentencetableid ).first()

    if result is None or (result is not None and len(result) == 0 ):
      #empty result
      result = self.session.query(SentenceTable.sentencecontent ).filter( SentenceTable.id == in_sentencetableid ).first()

      if len(result) == 0 :
        print ('getOneTokenSentence error get sentencetable id')
        return None

      #let's start tokenization
      strip_content = re.sub(r"[^\u4e00-\u9fff\uff1a\u300c\u300d\ufe55]", "",  result[0] )
      strip_content = re.sub(r'\u3000', ' ', strip_content)
      stoplist = ['的' , '在', '有', '他','為', '她', '到', '及','我', '係','與',  '和', '月',    '會','咁','佢', '但', '是', '就', '好', '亦', '嘅', '都', '唔', '於', '或', '時' , '由', '咗', '後', '仍' , '年', '日',  '冇', '多' , '至',    '哋', '吧','小' ]
      strip_content = re.sub(r'[的在有為到及我係與和月會咁佢但是就好亦嘅都唔於或時由咗後仍年日冇多至哋吧小]','' , strip_content)
      strip_content = re.sub(r'\s{2,}', ' ', strip_content)
      strip_content = ' '.join(jieba.cut(strip_content, cut_all=False))
      strip_content = re.sub(r'\s{2,}', ' ', strip_content)
 
      #write to database 
      newTokenSentenceEntry=TokenSentenceTable( sentencetable_id= in_sentencetableid, tokensentencecontent=strip_content )
      self.session.add(newTokenSentenceEntry)
      self.session.commit()
      tokenContentTuples = self.session.query(TokenSentenceTable.id ).filter( TokenSentenceTable.sentencetable_id == in_sentencetableid ).one() 
      return (in_sentencetableid, tokenContentTuples[0], strip_content )
    elif len(result) == 2:
      return (in_sentencetableid, result[0], result[1] )
    else :
      print ( 'getOneTokenSentence error get result len sentencetableid=', in_sentencetableid )
      return None



  def getTokenSentencesByCaseNumber (self, 
                       in_casenumber,
                       in_startTime=None, 
                       in_endTime=None,
                       in_needTrainType=False,
                       in_tokenbreak=True
                               ) :
    if in_casenumber < 1 and in_casenumber > 14 :
      print ('getTokenSentencesbycasenumber error casenumber ')
      return None

    if ( in_startTime != None and in_endTime == None) or ( in_endTime != None and in_startTime == None) :
      print ('getTokenSentencessbycasenumber error in_xxxtime  ')
      return None

    if ( in_startTime != None and in_endTime != None ) :
      result = self.session.query( SentenceTable.id ).join(ArticleTable).filter( and_( ArticleTable.timestampondoc >= in_startTime , ArticleTable.timestampondoc <= in_endTime)).filter( SentenceTable.casetable_id == in_casenumber ).filter( SentenceTable.traintype == int(in_needTrainType) ).all()
    else :
      result = self.session.query( SentenceTable.id , SentenceTable.sentencecontent ).filter( SentenceTable.casetable_id == in_casenumber ).filter( SentenceTable.traintype == int(in_needTrainType) ).all()

    if len(result) == 0:
      print ('getTokenSentencessbycasenumber error no result  ')
      #empty result
      return  None

    listOfTokenSentences = []
    for indRow in result :
      if in_tokenbreak :
        indTokenSentences = self.getOneTokenSentence( indRow[0] )
        if indTokenSentences is None :
          print ('getTokenSentencesByCaseNumber error cannot getonetokensentence ')
          return None
        # tuples (in_casenumber , sentencetableid, tokensentencetableid, tokensentence_content )
        listOfTokenSentences.append(( in_casenumber, indTokenSentences[0], indTokenSentences[1], indTokenSentences[2] ) ) 
      else :
        # tuples (in_casenumber , sentencetableid, tokensentencetableid, tokensentence_content )
        listOfTokenSentences.append(( in_casenumber, indRow[0], indRow[0], ' '.join(list(indRow[1])) ) ) 

    return listOfTokenSentences


  def getEntityDictEmptyList (self,
                       separator='ZZ',
                       numOfZeroFill=10) :
    result = self.session.query( EntityTable.name , 
             EntityTable.id , 
             EntityTable.checkrelatedcaselist ).filter( 
               EntityTable.hasfirebasetable == 1).all()
    resultdict = {}
    if ( (result is not None) and  len(result) > 0) :
      for indResult in result :
        resultdict[ separator.join( [ indResult[0].zfill(numOfZeroFill),
            str(indResult[1] ).zfill(numOfZeroFill) ] ) ] =  { \
               'checkrelatedcaseList' : [ int(z) for z in indResult[2].strip().split() ],
               'relatedarticleList' : [] }

    return resultdict  


  def getTokenSenCaseList (self, articleID ) :
    #does it have the tokensentence
    #assume no tokensentence
    #do parse it
    row=self.session.query(ArticleTable).filter( ArticleTable.id == articleID ).first()
    #print ("getTokenSenCaseList articleid=",articleID)
    if row.content is None or (len(row.content) < 2) :
      combine_content = row.title
    else :
      root = lxml.html.fromstring(row.content)
      listStripHTMLTagsString = root.xpath("//text()")
      combine_content = ''.join(listStripHTMLTagsString)
    strip_content=re.sub(r"[^\u4e00-\u9fff()?.,%0-9\u3002\u300c\u300d\uff01\u3010\u3011\uff0c\u3001\u3002\u300a\u300b\uff1a\uff1b]"," ",combine_content)

    out_list=[strip_content.strip()]
    for sentenceDivider in ['\u3002\u300d', '\uff01\u300d', '\uff1f\u300d','\u3002', '\uff01', '\uff1b', '\u3000'] :
      #print('-------------- 4', sentenceDivider, '----')
      intermediate_list=[]
      for index_list in out_list:
        #print('-------------- 5', index_list, '---------')
        intermediate_list=intermediate_list + index_list.strip().split(sentenceDivider)
        #print('-------------- 6', index_list, '---------')
      out_list= intermediate_list
      #print('-------------- 7')
    articlerow_id=row.id
    out_list = [x for x in out_list if len(x) > 0 ]
    tokenResultList = []
    #let's start tokenization
    for indSentence in out_list :
      strip_content = re.sub(r"[^\u4e00-\u9fff\uff1a\u300c\u300d\ufe55]", "",  indSentence )
      strip_content = re.sub(r'\u3000', ' ', strip_content)
      stoplist = ['的' , '在', '有', '他','為', '她', '到', '及','我', '係','與',  '和', '月',    '會','咁','佢', '但', '是', '就', '好', '亦', '嘅', '都', '唔', '於', '或', '時' , '由', '咗', '後', '仍' , '年', '日',  '冇', '多' , '至',    '哋', '吧','小' ]
      strip_content = re.sub(r'[的在有為到及我係與和月會咁佢但是就好亦嘅都唔於或時由咗後仍年日冇多至哋吧小]','' , strip_content)
      strip_content = re.sub(r'\s{2,}', ' ', strip_content)
      strip_content = ' '.join(jieba.cut(strip_content, cut_all=False))
      strip_content = re.sub(r'\s{2,}', ' ', strip_content)

      tokenResultList.append( strip_content )

    return tokenResultList
      







  def setArticleSimilaritieslist(self, in_articleTablePair) :
    #print ( 'setArticleSimilaritieslist 1 ', in_articleTablePair) 
    for index, entryID in enumerate(in_articleTablePair) :
      updateEntryID = in_articleTablePair[1] if index == 0 else in_articleTablePair[0]
      #the first one
      result = self.session.query(ArticleTable.similaritieslist, ArticleTable.finalurl ).filter(ArticleTable.id == entryID ).first()
      result_updateEntryID = self.session.query( ArticleTable.finalurl ).filter(ArticleTable.id == updateEntryID ).first()
      #print ( 'setArticleSimilaritieslist entryID=%s updateEntryID=%s' % (entryID, updateEntryID)) 
      if result is None  :
        #print ('setArticleSimilaritieslist 3 set error ' )
        return
      #print ( 'setArticleSimilaritieslist 4 result[0]=', result[0]) 
      if result[1] in result_updateEntryID[0] :
        #print ('setArticleSimilaritieslist 5 almost same url ' )
        return


      updatelist =''
      updatecount = 0
      if result[0] is None :
        updatelist = updateEntryID 
        updatecount = 1
      else :
        if (' ' + str(updateEntryID) + ' ') not in (' ' + result[0] + ' ') :
          updatelist = result[0].strip() + ' ' +str(updateEntryID)  
          updatecount = len( updatelist.split() ) 

      #print ( 'setArticleSimilaritieslist 6 updatecount=', updatecount ) 
      if updatelist != '' :    
        #print ( 'setArticleSimilaritieslist 7 updatelist=', updatelist) 
        result=1
        with open ("databaselockfile", "w") as test_fd :
          fcntl.lockf(test_fd, fcntl.LOCK_EX)
          result = self.session.query(ArticleTable.id).filter(ArticleTable.id == entryID ).update( {ArticleTable.similaritieslist : updatelist , ArticleTable.similaritiescount : updatecount } )
          self.session.commit()
          fcntl.lockf(test_fd, fcntl.LOCK_UN)

        if result is None  :
          print ('setArticleSimilaritieslist 8 set error ')
          return
        #print ( 'setArticleSimilaritieslist 8.1 result[0]=%d' % result) 

    #print ( 'setArticleSimilaritieslist 9 ') 




  def getArticleSimilaritieslist(self, in_articleid) :
    print ( 'getArticleSimilaritieslist 1 ') 
    result = self.session.query(ArticleTable.similaritieslist).filter(ArticleTable.id == in_articleid ).first()
    print ( 'getArticleSimilaritieslist 2 ') 
    return result

  def getArticleContentTimestamp (self, in_articleid) :
    print ( 'getArticleContentTimestamp 1 ') 
    result = self.session.query( ArticleTable.content , ArticleTable.timestampondoc ).filter(ArticleTable.id == in_articleid ).first()
    print ( 'getArticleContentTimestamp 2 ') 
    return result

  def getListOfArticleContent (self, in_listarticleid) :
    final_resultlist= []
    print ( 'getListOfArticleContent 1 ') 
    for indArticleID in in_listarticleid :
      print ( 'getListOfArticleContent 2 ', indArticleID ) 
      result = self.getArticleContentTimestamp(int(indArticleID))
      print ( 'getListOfArticleContent 3 ', indArticleID ) 
      if result is not None :
        print ( 'getListOfArticleContent 4 ', indArticleID ) 
        #all (indArticleID, result[0/1]  are  str 
        final_resultlist.append( (indArticleID, result[0], result[1] ) )
    return final_resultlist
   

  def recursiveSimlist(self, in_checkArticleid, in_withinrangesimlistDict, in_notwithinrangesimlistDict , in_starttime, in_endtime ) :
    print ( 'recursiveSimlist 1 in_checkArticleid,=', in_checkArticleid) 
    result = self.session.query(ArticleTable.similaritieslist).filter(ArticleTable.id == in_checkArticleid ).filter( and_( ArticleTable.timestampondoc >= in_starttime , ArticleTable.timestampondoc <= in_endtime) ).first()
    print ( 'recursiveSimlist 2 in_checkArticleid,=', in_checkArticleid) 
    if result is not None and result[0] is not None :
      for indArticleid in result[0].strip().split():
        print ( 'recursiveSimlist 3 in_checkArticleid,=%d indArticleid=%s ' % (in_checkArticleid,indArticleid) ) 
        if ( indArticleid not in in_withinrangesimlistDict) and ( indArticleid not in in_notwithinrangesimlistDict  ) : 
          in_withinrangesimlistDict[indArticleid] = indArticleid
          print ( 'recursiveSimlist 4 in_checkArticleid,=%d indArticleid=%s ' % (in_checkArticleid,indArticleid) ) 
          self.recursiveSimlist( in_checkArticleid, in_withinrangesimlistDict, in_notwithinrangesimlistDict , in_starttime, in_endtime )
          print ( 'recursiveSimlist 5 in_checkArticleid,=%d indArticleid=%s ' % (in_checkArticleid,indArticleid) ) 
    else :
      in_notwithinrangesimlistDict[in_checkArticleid] = in_checkArticleid
      print ( 'recursiveSimlist 6 in_checkArticleid,=', in_checkArticleid) 


  def getRecursiveArticleContentfromSimlistInRange (self, in_articleid, in_starttime, in_endtime ) :
    withinrangesimlistDict = {}
    notwithinrangesimlistDict = {}
    print ('getRecursiveArticleContentfromSimlistInRange 1 ')
    self.recursiveSimlist(in_articleid, withinrangesimlistDict, notwithinrangesimlistDict , in_starttime, in_endtime )
    print ('getRecursiveArticleContentfromSimlistInRange 2 ' , in_articleid)
    if len(withinrangesimlistDict) == 0 :
      print ('getRecursiveArticleContentfromSimlistInRange 2.1 ' , in_articleid)
      resultlist = [ in_articleid ]
    else :
      print ('getRecursiveArticleContentfromSimlistInRange 2.4= ' , list(withinrangesimlistDict.keys()) )
      resultlist = list(withinrangesimlistDict.keys())
      resultlist.insert(0, str(in_articleid))
    print ('getRecursiveArticleContentfromSimlistInRange 3 ', resultlist )
    return self.getListOfArticleContent ( resultlist )
    







  def getIndArticleEntry(self, entryID) :
    result = self.session.query(ArticleTable).filter(ArticleTable.id == entryID ).first()
    return result
 
  def getArticleTableCount(self):
    result_list= self.session.query(ArticleTable).count()
    return result_list 

  def getArticleTableRange(self, startrow, endrow=0):
    result_list=[] 
    if endrow == 0 :
      result_list = self.session.query(ArticleTable).filter(ArticleTable.id > startrow).order_by(ArticleTable.id.asc()).all()
    else : 
      result_list = self.session.query(ArticleTable).filter(and_(ArticleTable.id > startrow , ArticleTable.id < endrow)).order_by(ArticleTable.id.asc()).all()
    return result_list 



  def getSumOfArticleWithCategory(self, category_eng_name) :
    stmt = self.session.query(FirstSubDomainTable.id).join(CategoryTable).filter(CategoryTable.eng_name==category_eng_name , CategoryTable.id == FirstSubDomainTable.categorytable_id ).subquery()
    newtotal = self.session.query(ArticleTable).join(stmt, ArticleTable.firstsubdomaintable_id==stmt.c.id ).order_by( ArticleTable.timestampondoc.asc() ).count()
    if newtotal == 0:
      print ("error getSumOfArticleWithCategory  ...... ")
      return 0
    return newtotal


  def getArticleWithCategoryAndOffset(self, category_eng_name, totalcountfromfirebase, category_eng_name2=None, totalcountfromfirebase_name2=0) :
    if category_eng_name2 is None :
      stmt = self.session.query(FirstSubDomainTable.id).join(CategoryTable).filter(CategoryTable.eng_name==category_eng_name , CategoryTable.id == FirstSubDomainTable.categorytable_id ).subquery()
    else :
      stmt = self.session.query(FirstSubDomainTable.id).join(CategoryTable).filter( or_(  and_(CategoryTable.eng_name==category_eng_name , CategoryTable.id == FirstSubDomainTable.categorytable_id ) , and_(CategoryTable.eng_name==category_eng_name2 , CategoryTable.id == FirstSubDomainTable.categorytable_id ) ) ).subquery()

    newtotal = self.session.query(ArticleTable).join(stmt, ArticleTable.firstsubdomaintable_id==stmt.c.id ).order_by( ArticleTable.timestampondoc.asc() ).count()
    totaloffset = totalcountfromfirebase + totalcountfromfirebase_name2
    result = self.session.query(ArticleTable).join(stmt, ArticleTable.firstsubdomaintable_id==stmt.c.id ).order_by( ArticleTable.timestampondoc.asc() ).offset(totaloffset ).limit( newtotal - totaloffset ).all()
    if len(result) == 0:
      print ("error getArticleWithCategoryAndOffset  ...... ")
      return 0
    return result




  def getArticleDict(self):
    #result_list= [ itemContent.__dict__ for itemContent in self.session.query(ArticleTable).all()  ]
    result_list= self.session.query(ArticleTable).all()
    return result_list 

  def getCaseDict(self):
    result_list= [ itemContent.__dict__ for itemContent in self.session.query(CaseTable).all()  ]
    return result_list 

  def getCategoryDict(self):
    #result_list= [ itemContent.__dict__ for itemContent in self.session.query(CategoryTable).all()  ]
    result_list= self.session.query(CategoryTable).all() 
    return result_list 

  def getDomainDict(self):
    #result_list= [ itemContent.__dict__ for itemContent in self.session.query(DomainTable).all()  ]
    result_list= self.session.query(DomainTable).all() 
    return result_list 

  def getEntityDict(self):
    result_list= [ itemContent.__dict__ for itemContent in self.session.query(EntityTable).all()  ]
    return result_list 

  def getFirstSubDomainDict(self):
    #result_list= [ itemContent.__dict__ for itemContent in self.session.query(FirstSubDomainTable).all()  ]
    result_list= self.session.query(FirstSubDomainTable).all() 
    return result_list 

  def getSentenceDict(self):
    result_list= [ itemContent.__dict__ for itemContent in self.session.query(SentenceTable).all()  ]
    return result_list 














#the following is for initialize database information
#
#
#

  def create_default_value(self):
    domaintable_entry=DomainTable(
      baseurl='http://hk.on.cc',
      chi_name='東網',
      eng_name='orientaldaily_net')
    self.session.add(domaintable_entry)
    domaintable_entry=DomainTable(
      baseurl='http://orientaldaily.on.cc',
      chi_name='東方日報',
      eng_name='orientaldaily')
    self.session.add(domaintable_entry)
    domaintable_entry=DomainTable(
      baseurl='http://m.on.cc',
      chi_name='東網(流動)',
      eng_name='orientaldaily_mobile')
    self.session.add(domaintable_entry)
    domaintable_entry=DomainTable(
      baseurl='http://hk.apple.nextmedia.com',
      chi_name='蘋果日報',
      eng_name='appledaily')
    self.session.add(domaintable_entry)
    domaintable_entry=DomainTable(
      baseurl='http://hkm.appledaily.com',
      chi_name='蘋果日報(流動)',
      eng_name='appledaily_mobile')
    self.session.add(domaintable_entry)
    domaintable_entry=DomainTable(
      baseurl='https://news.mingpao.com',
      chi_name='明報',
      eng_name='mingpao')
    self.session.add(domaintable_entry)
    domaintable_entry=DomainTable(
      baseurl='https://m.mingpao.com',
      chi_name='明報(流動)',
      eng_name='mingpao_mobile')
    self.session.add(domaintable_entry)
    domaintable_entry=DomainTable(
      baseurl='http://std.stheadline.com',
      chi_name='星島日報',
      eng_name='singtao')
    self.session.add(domaintable_entry)
    domaintable_entry=DomainTable(
      baseurl='http://news.rthk.hk',
      chi_name='香港電台',
      eng_name='rthk')
    self.session.add(domaintable_entry)
    domaintable_entry=DomainTable(
      baseurl='http://881903.com',
      chi_name='商業電台',
      eng_name='crhk')
    self.session.add(domaintable_entry)


    categorytable_entry=CategoryTable(
      chi_name='總新聞',
      eng_name='allnews')
    self.session.add(categorytable_entry)
    categorytable_entry=CategoryTable(
      chi_name='要聞港聞',
      eng_name='headlinenews')
    self.session.add(categorytable_entry)
    categorytable_entry=CategoryTable(
      chi_name='即時新聞',
      eng_name='latestnews')
    self.session.add(categorytable_entry)
    categorytable_entry=CategoryTable(
      chi_name='立法會',
      eng_name='legistration')
    self.session.add(categorytable_entry)
    
    firstsubdomaintable_entry=FirstSubDomainTable(
      domaintable_id=1,
      categorytable_id=3,
      firstsubd='/hk/news/index.html',
      onlyweekdays=False)
    self.session.add(firstsubdomaintable_entry)
    firstsubdomaintable_entry=FirstSubDomainTable(
      domaintable_id=2,
      categorytable_id=2,
      firstsubd='/cnt/news/YYYYMMDD/index.html',
      onlyweekdays=False)
    self.session.add(firstsubdomaintable_entry)
    firstsubdomaintable_entry=FirstSubDomainTable(
      domaintable_id=4,
      categorytable_id=3,
      firstsubd='/realtime/breaking/index',
      onlyweekdays=False)
    self.session.add(firstsubdomaintable_entry)
    firstsubdomaintable_entry=FirstSubDomainTable(
      domaintable_id=5,
      categorytable_id=2,
      firstsubd='/list.php?category_guid=4104&category=daily',
      onlyweekdays=False)
    self.session.add(firstsubdomaintable_entry)
    firstsubdomaintable_entry=FirstSubDomainTable(
      domaintable_id=5,
      categorytable_id=3,
      firstsubd='/list.php?category_guid=6996647&category=instant',
      onlyweekdays=False)
    self.session.add(firstsubdomaintable_entry)
    firstsubdomaintable_entry=FirstSubDomainTable(
      domaintable_id=6,
      categorytable_id=2,
      firstsubd='/pns/港聞/web_tc/section/YYYYMMDD/s00002',
      onlyweekdays=False)
    self.session.add(firstsubdomaintable_entry)
    firstsubdomaintable_entry=FirstSubDomainTable(
      domaintable_id=6,
      categorytable_id=3,
      firstsubd='/ins/港聞/web_tc/section/YYYYMMDD/s00001',
      onlyweekdays=False)
    self.session.add(firstsubdomaintable_entry)
    firstsubdomaintable_entry=FirstSubDomainTable(
      domaintable_id=8,
      categorytable_id=2,
      firstsubd='/daily/section-list.php?page=1&cat=12',
      onlyweekdays=False)
    self.session.add(firstsubdomaintable_entry)
    firstsubdomaintable_entry=FirstSubDomainTable(
      domaintable_id=8,
      categorytable_id=3,
      firstsubd='/instant/articles/listview/香港',
      onlyweekdays=False)
    self.session.add(firstsubdomaintable_entry)
    firstsubdomaintable_entry=FirstSubDomainTable(
      domaintable_id=9,
      categorytable_id=3,
      firstsubd='/rthk/ch/news-archive.htm?archive_year=YYYY&archive_month=MM&archive_day=DD&archive_cat=all',
      onlyweekdays=False)
    self.session.add(firstsubdomaintable_entry)
    firstsubdomaintable_entry=FirstSubDomainTable(
      domaintable_id=10,
      categorytable_id=3,
      firstsubd='/Page/ZH-TW/News.aspx?sdate=DD.MM.YYYY&csid=261_341',
      onlyweekdays=False)
    self.session.add(firstsubdomaintable_entry)
    firstsubdomaintable_entry=FirstSubDomainTable(
      domaintable_id=10,
      categorytable_id=4,
      firstsubd='/Page/ZH-TW/News.aspx?sdate=DD.MM.YYYY&csid=261_4000',
      onlyweekdays=True)
    self.session.add(firstsubdomaintable_entry)
     
    casetable_entry= CaseTable(
      active='Person',
      passive='Thing')
    self.session.add(casetable_entry)
    casetable_entry= CaseTable(
      active='Person',
      passive='Person')
    self.session.add(casetable_entry)
    casetable_entry= CaseTable(
      active='Person',
      passive='GroupOfPerson')
    self.session.add(casetable_entry)
    casetable_entry= CaseTable(
      active='GroupOfPerson',
      passive='Thing')
    self.session.add(casetable_entry)
    casetable_entry= CaseTable(
      active='GroupOfPerson',
      passive='Person')
    self.session.add(casetable_entry)
    casetable_entry= CaseTable(
      active='GroupOfPerson',
      passive='GroupOfPerson')
    self.session.add(casetable_entry)
    casetable_entry= CaseTable(
      active='Thing',
      passive='Thing')
    self.session.add(casetable_entry)
    casetable_entry= CaseTable(
      active='Multiplecase',
      passive='Multiplecase')
    self.session.add(casetable_entry)
     
     
    entitytable_entry= EntityTable(
      organization='政府',
      title='財經事務及庫務局局長',
      name='劉怡翔',
      nickname='',
      previoustitle='')
    self.session.add(entitytable_entry)
    entitytable_entry= EntityTable(
      organization='政府',
      title='政府',
      name='政府',
      nickname='政府',
      previoustitle='政府')
    self.session.add(entitytable_entry)
    entitytable_entry= EntityTable(
      organization='政府',
      title='財政司司長',
      name='陳茂波',
      nickname='波叔',
      previoustitle='發展局局長')
    self.session.add(entitytable_entry)
    entitytable_entry= EntityTable(
      organization='政府',
      title='內會副主席',
      name='郭榮鏗',
      nickname='',
      previoustitle='')
    self.session.add(entitytable_entry)
    entitytable_entry= EntityTable(
      organization='政府',
      title='內會主席',
      name='李慧琼',
      nickname='',
      previoustitle='')
    self.session.add(entitytable_entry)
    entitytable_entry= EntityTable(
      organization='政府',
      title='政務司司長',
      name='張建宗',
      nickname='',
      previoustitle='')
    self.session.add(entitytable_entry)
    entitytable_entry= EntityTable(
      organization='政府',
      title='特首',
      name='林鄭月娥',
      nickname='',
      previoustitle='')
    self.session.add(entitytable_entry)
     
    self.session.commit() 
     
     
  def create_default_value_domain(self):
    domaintable_entry=DomainTable(
      baseurl='http://hk.on.cc',
      chi_name='東網',
      eng_name='orientaldaily_net')
    self.session.add(domaintable_entry)
    domaintable_entry=DomainTable(
      baseurl='http://orientaldaily.on.cc',
      chi_name='東方日報',
      eng_name='orientaldaily')
    self.session.add(domaintable_entry)
    domaintable_entry=DomainTable(
      baseurl='http://m.on.cc',
      chi_name='東網(流動)',
      eng_name='orientaldaily_mobile')
    self.session.add(domaintable_entry)
    domaintable_entry=DomainTable(
      baseurl='http://hk.apple.nextmedia.com',
      chi_name='蘋果日報',
      eng_name='appledaily')
    self.session.add(domaintable_entry)
    domaintable_entry=DomainTable(
      baseurl='http://hkm.appledaily.com',
      chi_name='蘋果日報(流動)',
      eng_name='appledaily_mobile')
    self.session.add(domaintable_entry)
    domaintable_entry=DomainTable(
      baseurl='https://news.mingpao.com',
      chi_name='明報',
      eng_name='mingpao')
    self.session.add(domaintable_entry)
    domaintable_entry=DomainTable(
      baseurl='https://m.mingpao.com',
      chi_name='明報(流動)',
      eng_name='mingpao_mobile')
    self.session.add(domaintable_entry)
    domaintable_entry=DomainTable(
      baseurl='http://std.stheadline.com',
      chi_name='星島日報',
      eng_name='singtao')
    self.session.add(domaintable_entry)
    domaintable_entry=DomainTable(
      baseurl='http://news.rthk.hk',
      chi_name='香港電台',
      eng_name='rthk')
    self.session.add(domaintable_entry)
    domaintable_entry=DomainTable(
      baseurl='http://881903.com',
      chi_name='商業電台',
      eng_name='crhk')
    self.session.add(domaintable_entry)

    self.session.commit() 
     
     
  def create_default_value_category(self):
    categorytable_entry=CategoryTable(
      chi_name='總新聞',
      eng_name='allnews')
    self.session.add(categorytable_entry)
    categorytable_entry=CategoryTable(
      chi_name='要聞港聞',
      eng_name='headlinenews')
    self.session.add(categorytable_entry)
    categorytable_entry=CategoryTable(
      chi_name='即時新聞',
      eng_name='latestnews')
    self.session.add(categorytable_entry)
    categorytable_entry=CategoryTable(
      chi_name='立法會',
      eng_name='legistration')
    self.session.add(categorytable_entry)
     
    self.session.commit() 
     
  def create_default_value_first(self):
    firstsubdomaintable_entry=FirstSubDomainTable(
      domaintable_id=1,
      categorytable_id=3,
      firstsubd='/hk/news/index.html',
      onlyweekdays=False)
    self.session.add(firstsubdomaintable_entry)
    firstsubdomaintable_entry=FirstSubDomainTable(
      domaintable_id=2,
      categorytable_id=2,
      firstsubd='/cnt/news/YYYYMMDD/index.html',
      onlyweekdays=False)
    self.session.add(firstsubdomaintable_entry)
    firstsubdomaintable_entry=FirstSubDomainTable(
      domaintable_id=4,
      categorytable_id=3,
      firstsubd='/realtime/breaking/index',
      onlyweekdays=False)
    self.session.add(firstsubdomaintable_entry)
    firstsubdomaintable_entry=FirstSubDomainTable(
      domaintable_id=5,
      categorytable_id=2,
      firstsubd='/list.php?category_guid=4104&category=daily',
      onlyweekdays=False)
    self.session.add(firstsubdomaintable_entry)
    firstsubdomaintable_entry=FirstSubDomainTable(
      domaintable_id=5,
      categorytable_id=3,
      firstsubd='/list.php?category_guid=6996647&category=instant',
      onlyweekdays=False)
    self.session.add(firstsubdomaintable_entry)
    firstsubdomaintable_entry=FirstSubDomainTable(
      domaintable_id=6,
      categorytable_id=2,
      firstsubd='/pns/港聞/web_tc/section/YYYYMMDD/s00002',
      onlyweekdays=False)
    self.session.add(firstsubdomaintable_entry)
    firstsubdomaintable_entry=FirstSubDomainTable(
      domaintable_id=6,
      categorytable_id=3,
      firstsubd='/ins/港聞/web_tc/section/YYYYMMDD/s00001',
      onlyweekdays=False)
    self.session.add(firstsubdomaintable_entry)
    firstsubdomaintable_entry=FirstSubDomainTable(
      domaintable_id=8,
      categorytable_id=2,
      firstsubd='/daily/section-list.php?page=1&cat=12',
      onlyweekdays=False)
    self.session.add(firstsubdomaintable_entry)
    firstsubdomaintable_entry=FirstSubDomainTable(
      domaintable_id=8,
      categorytable_id=3,
      firstsubd='/instant/articles/listview/香港',
      onlyweekdays=False)
    self.session.add(firstsubdomaintable_entry)
    firstsubdomaintable_entry=FirstSubDomainTable(
      domaintable_id=9,
      categorytable_id=3,
      firstsubd='/rthk/ch/news-archive.htm?archive_year=YYYY&archive_month=MM&archive_day=DD&archive_cat=all',
      onlyweekdays=False)
    self.session.add(firstsubdomaintable_entry)
    firstsubdomaintable_entry=FirstSubDomainTable(
      domaintable_id=10,
      categorytable_id=3,
      firstsubd='/Page/ZH-TW/News.aspx?sdate=DD.MM.YYYY&csid=261_341',
      onlyweekdays=False)
    self.session.add(firstsubdomaintable_entry)
    firstsubdomaintable_entry=FirstSubDomainTable(
      domaintable_id=10,
      categorytable_id=4,
      firstsubd='/Page/ZH-TW/News.aspx?sdate=DD.MM.YYYY&csid=261_4000',
      onlyweekdays=True)
    self.session.add(firstsubdomaintable_entry)
     
    self.session.commit() 
     
  def create_default_value_case(self):
    casetable_entry= CaseTable(
      active='Person',
      passive='Thing')
    self.session.add(casetable_entry)
    casetable_entry= CaseTable(
      active='Person',
      passive='Person')
    self.session.add(casetable_entry)
    casetable_entry= CaseTable(
      active='Person',
      passive='GroupOfPerson')
    self.session.add(casetable_entry)
    casetable_entry= CaseTable(
      active='GroupOfPerson',
      passive='Thing')
    self.session.add(casetable_entry)
    casetable_entry= CaseTable(
      active='GroupOfPerson',
      passive='Person')
    self.session.add(casetable_entry)
    casetable_entry= CaseTable(
      active='GroupOfPerson',
      passive='GroupOfPerson')
    self.session.add(casetable_entry)
    casetable_entry= CaseTable(
      active='Thing',
      passive='Thing')
    self.session.add(casetable_entry)
    casetable_entry= CaseTable(
      active='Multiplecase',
      passive='Multiplecase')
    self.session.add(casetable_entry)
     
    self.session.commit() 
     
     
  def create_default_value_entity(self):
    entitytable_entry= EntityTable(
      organization='政府',
      title='財經事務及庫務局局長',
      name='劉怡翔',
      nickname='',
      previoustitle='')
    self.session.add(entitytable_entry)
    entitytable_entry= EntityTable(
      organization='政府',
      title='政府',
      name='政府',
      nickname='政府',
      previoustitle='政府')
    self.session.add(entitytable_entry)
    entitytable_entry= EntityTable(
      organization='政府',
      title='財政司司長',
      name='陳茂波',
      nickname='波叔',
      previoustitle='發展局局長')
    self.session.add(entitytable_entry)
    entitytable_entry= EntityTable(
      organization='政府',
      title='內會副主席',
      name='郭榮鏗',
      nickname='',
      previoustitle='')
    self.session.add(entitytable_entry)
    entitytable_entry= EntityTable(
      organization='政府',
      title='內會主席',
      name='李慧琼',
      nickname='',
      previoustitle='')
    self.session.add(entitytable_entry)
    entitytable_entry= EntityTable(
      organization='政府',
      title='政務司司長',
      name='張建宗',
      nickname='',
      previoustitle='')
    self.session.add(entitytable_entry)
    entitytable_entry= EntityTable(
      organization='政府',
      title='特首',
      name='林鄭月娥',
      nickname='',
      previoustitle='')
    self.session.add(entitytable_entry)
     
    self.session.commit() 
     
     
  def create_default_value_s_1(self):
    content='社民連主席吳文遠則表示， 5名成員從昨天至今仍被可疑人士跟蹤， 質疑是打壓滋擾， 而立法會議員羅冠聰亦指被人跟蹤。'
    sentence_entry=SentenceTable(
      articletable_id=1,
      sentencecontent=content,
      casetable_id = 1,
      activeentity_id =2,
      passiveentity_id =3,
      nextsentence_id=2)
    self.session.add(sentence_entry)
    content='  教育實驗學社成員黃子悅表示， 被關進俗稱「臭格」的羈留室期間， 警方向她表示，只會有女警巡邏， 但她發現，期間不時有男警經過， 質疑警方違返正當程序， 考慮向警察投訴科投訴。'
    sentence_entry=SentenceTable(
      articletable_id=1,
      sentencecontent=content,
      casetable_id = 3,
      activeentity_id =4,
      passiveentity_id =5,
      previoussentence_id=1,
      nextsentence_id=3)
    self.session.add(sentence_entry)
    sentence_entry=SentenceTable(
      articletable_id=1,
      sentencecontent=content,
      casetable_id = 4,
      activeentity_id =5,
      passiveentity_id =6,
      previoussentence_id=2,
      nextsentence_id=4)
    self.session.add(sentence_entry)
    self.session.commit() 

  def create_default_value_article(self):
    td=timedelta(hours=8)
    finalurl_l='https://www.hk01.com/%E6%B8%AF%E8%81%9E/101658/-%E4%BD%94%E9%A0%98%E9%87%91%E7%B4%AB%E8%8D%8A-%E9%BB%83%E4%B9%8B%E9%8B%92%E6%89%B9%E8%AD%A6%E6%96%B9%E6%BF%AB%E7%94%A8%E7%A8%8B%E5%BA%8F%E6%8B%96%E5%BB%B6%E9%8C%84%E5%8F%A3%E4%BE%9B-%E5%A4%9A%E4%BA%BA%E4%BA%8B%E5%BE%8C%E8%A2%AB%E8%B7%9F%E8%B9%A4'
    timeondoc=datetime(2017,7,13,13,14,15,0,tzinfo=timezone(td))
    timeonret=datetime(2017,7,13,16,17,18,0,tzinfo=timezone(td))
    title_l='【宣誓覆核案】4議員全敗訴 全被取消議席'
    content_l='前特首梁振英及律政司去年入稟提出司法覆核，指控立法會議員社民連梁國雄、香港眾志羅冠聰、專業議政姚松炎和小麗民主教室劉小麗的宣誓違反《宣誓及聲明條例》，要求法庭撤銷4人議員資格。高院今午三時開庭頒布裁決判詞，裁定4議員全敗訴全被取消議席。 去年10月立法會復會後旋即爆出「宣誓風波」，引發人大釋法，未完成宣誓的青年新政>梁頌恆及游蕙禎遭政府提出司法覆核，被裁定喪失議員資格。律政司司長當時根據釋法，指出梁國雄、羅冠聰、姚松炎和劉小麗在首次宣誓已不符《基本法》第104條及《宣誓及聲明>條例》，不可重新再宣誓，因此立法會主席並無權力去接納梁國雄的宣誓及批准另外3人再>宣誓。入稟狀又要求法院頒布禁制令，禁止4人再聲稱或以立法會議員身份行事。 期後在今年3月的聆訊中，代表政府一方的資深大律師莫樹聯質疑4人宣誓並非真誠，指梁國雄破壞宣誓儀式的莊嚴性；姚松炎擅自更改誓詞；劉小麗以慢速讀出誓詞；而羅冠聰完成宣誓後高叫「權力歸於人民，暴政必亡，民主自決，抗爭到底」，實是支持港獨，以變調方式朗讀誓詞，反映他並非真誠同意誓詞。 代表梁國雄的資深大律師李柱銘指出，立法會議員履行職務>前設是需要宣誓，但不代表要即時宣誓，議員當選一刻已代表他們可以履行職務，強調宣誓無效和拒絕宣誓是兩件事；代表劉小麗的榮譽資深大律師陳文敏表示，劉小麗宣誓前曾經有一連串準備功夫，證劉小麗是「隆重其事」宣誓；代表姚松炎的資深大律師余若薇就指他在完成誓詞後讀出聲明，不構成宣誓無效，因為法定誓詞已完成；代表羅冠聰的資深大律師戴啟思則表示，羅於宣誓前所說的話，並沒有違背其效忠的承諾，如煽動暴力和勾結敵人等，亦沒有刻意破壞《基本法》的條文，羅冠聰另一名代表律師就指出，宣誓時將「國」字提高聲調，沒有改變「中華人民共和國」的意思，而中華人民共和國與政權共產黨有分別。 4人在今日早前已表明，若法庭裁定4人被褫奪議員資格，他們會與律師商量，估計將會上訴。'
    article_entry=ArticleTable(
      firstsubdomaintable_id=5,
      finalurl=finalurl_l,
      timestampondoc=timeondoc,
      timestamponretrieve=timeonret,
      title=title_l,
      content=content_l
      )
    self.session.add(article_entry)
    self.session.commit() 
     

      
