import time
import scrapy
import json
import base64
from scrapy_splash import SplashRequest
#from scrapy import Selector
from datetime import datetime, timedelta,timezone
import re
from gong_01_db import GongAllTable


class GongGenericSource() :
  base_url = 'hello:GongGenericSource' 
  log_main_jpeg = False
  log_main_html = False
  log_item_jpeg = False
  log_item_html = False
  itemParseIt = False
  endpointexecute = 'render.json'
  endpointexecute_item = 'render.json'
  numOfYieldRequestLimit = 20
  dopagination = False
  splash_args = {
            'html': 1,
            'jpeg': 1,
            'width': 600,
            'render_all': 1,
            'wait' : 15,
    }
  splash_args_item = splash_args
  max_retry_times = 10
  secondtryItemTime = False

  def parse_result_func (self, response) :
    print (' GongGenericSource : ---- > parse_result_func')
  
  def parse_result_item_func (self, response) :
    print (' GongGenericSource : ---- > parse_result_item_func')

  def get_endpoint(self) :
    print (' GongGenericSource : ---- > get_endpoint')

  def get_splash_args (self) :
    print (' GongGenericSource : ---- > get_splash_args')
 
  def get_splash_args_item (self) :
    print (' GongGenericSource : ---- > get_splash_args')
 

  def get_newsItemList (self, resp=None, info=None) :
    print (' GongGenericSource : ---- > get_newsItemList')

  def get_indNewsItemURL (self, itemtext, base_url=None) :
    print (' GongGenericSource : ---- > get_indNewsItemURL')
 
  def get_indNewsItemTitle (self, itemtext) :
    print (' GongGenericSource : ---- > get_indNewsItemTitle')
 
  def get_indNewsItemTime (self, iteminfo, url=None, iyear=None, imonth=None, iday=None) :
    print (' GongGenericSource : ---- > get_indNewsItemTime')
 
  def get_dopagination (self, response) :
    print (' GongGenericSource : ---- > get_dopagination')

  def get_havenextpage (self, response) :
    print (' GongGenericSource : ---- > get_havenextpage')
    return True

  def get_newPageURL (self, response) :
    print (' GongGenericSource : ---- > get_newPageURL')
 
  def get_itemParseIt (self) :
    print (' GongGenericSource : ---- > get_itemParseIt')

  def get_secondItemTime(self, response):
    print (' GongGenericSource : ---- > get_seconditemtime')
  
  def get_articleContent (self, response) :
    print (' GongGenericSource : ---- > get_newPageURL')
 
  def get_parseImageURL (self, response) :
    print (' GongGenericSource : ---- > get_parseImageURL')



 
################## am730  
class Am730DailyNewsParser(GongGenericSource) :
  base_url = 'https://www.am730.com.hk'
  #log_main_jpeg = False
  #log_main_html = False
  #log_item_jpeg = False
  #log_item_html = False
  #self.itemParseIt = False
  #endpointexecute = 'render.json'
  #endpointexecute_item = 'render.json'
  #splash_args=""" """
  #splash_args_item=""" """
  #numOfYieldRequestLimit = 20
  #dopagination = True

  def get_endpoint(self) :
    print (' am730DailyNewsParser : ---- > get_endpoint')
    endpointexecute = 'render.json'

  def get_newsItemList (self, resp=None, info=None) :
    print (' am730DailyNewsParser : ---- > get_newsItemList')
    return resp.xpath('//optgroup[@label="新聞"]/option').extract()

  def get_indNewsItemURL (self, itemtext, use_this_url=None) :
    print (' am730DailyNewsParser : ---- > get_indNewsItemURL')
    return scrapy.Selector(text=itemtext).xpath('//@value').extract_first()

  def get_indNewsItemTitle (self, itemtext) :
    print (' am730DailyNewsParser : ---- > get_indNewsItemTitle')
    return scrapy.Selector(text=itemtext).xpath('//text()').extract_first()
 
  def get_indNewsItemTime (self, iteminfo, url=None, iyear=None, imonth=None, iday=None) :
    print (' am730DailyNewsParser : ---- > get_indNewsItemTime')
    self.nowTime= datetime.now(timezone(timedelta(hours=8)))
    #the dailynews update time is around 3amHKT
    if self.nowTime.hour < 6 :
      self.nowTime = self.nowTime - timedelta(hours=4)

    return datetime( self.nowTime.year,
                                    self.nowTime.month ,
                                    self.nowTime.day ,
                                    0,
                                    0,
                                    0,
                                    999999,
                                    tzinfo=timezone(timedelta(hours=8)))

 
  def get_dopagination (self, response) :
    print (' am730DailyNewsParser : ---- > get_dopagination')

  def get_newPageURL (self, response) :
    print (' am730DailyNewsParser : ---- > get_newPageURL')
 
  def get_itemParseIt (self) :
    print (' am730DailyNewsParser : ---- > get_itemParseIt')
 
  def get_articleContent (self, response) :
    print (' am730DailyNewsParser : ---- > get_newPageURL')
    articleParagraphList = response.xpath('//div[contains(@class, "news-detail-title") and contains(@class, "print-title")]/following-sibling::div/p').extract()
    articleContent =''.join( [ x.strip() for x in articleParagraphList ])
 
    if articleContent is not None and len(articleContent.strip()) < 1 :
      articleContent = response.request.meta['indNewsItemTitle']

    return articleContent
    
 
  def get_parseImageURL (self, response) :
    print (' am730DailyNewsParser : ---- > get_parseImageURL')
    checkparseImageURL = response.xpath('//div[contains(@class, "news-detail-title") and contains(@class, "print-title")]/following-sibling::div/a//img/@src | //div[contains(@class,"category-title")]//img/@src ').extract_first()
    if checkparseImageURL is None :
      parseImageURL=None
    else :
      parseImageURL = checkparseImageURL
    return parseImageURL 




################## now latestnews  
class NowLatestNewsParser(GongGenericSource) :
  base_url = 'http://news.now.com'
  #log_main_jpeg = False
  #log_main_html = False
  #log_item_jpeg = False
  #log_item_html = False
  #self.itemParseIt = False
  #self.endpointexecute = 'execute'
  numOfYieldRequestLimit = 20
  dopagination = True

  splash_args_item = {
            'html': 1,
            'width': 600,
            'render_all': 1,
            'wait' : 15,
            'js_source' : ' var elements = document.getElementsById("flashplayer") ; elements[0].parentNode.removeChild(elements[0]); elements = document.getElementsById("html5Player") ; elements[0].parentNode.removeChild(elements[0]); elements = document.getElementsById("preRollAdContainer");  elements[0].parentNode.removeChild(elements[0]); '
  }

  #def get_endpoint(self) :
  #  print (' GongGenericSource : ---- > get_endpoint')
  #  return self.endpointexecute

  def get_newsItemList (self, resp=None, info=None) :
    newsItemList = resp.xpath('//div[@class="newsCategoryColLeft"]//a[contains(@class, "focusNewsWrap1") or contains(@class, "focusNewsWrap2") or contains(@class, "focusNewsWrap3") or contains(@class, "focusNewsWrap4") or contains(@class, "newsWrap")]').extract()
   
    print (' nowlatestnewsparser : ---- > get_newsitemlist')
    return newsItemList


  def get_indNewsItemURL (self, itemtext, base_url=None) :

    print (' nowlatestnewsparser : ---- > get_indNewsItemURL')
    return self.base_url + (scrapy.Selector(text=itemtext).xpath('//a/@href').extract_first() )


  def get_indNewsItemTitle (self, itemtext) :
    print (' nowlatestnewsparser : ---- > get_indNewsItemTitle')
    return scrapy.Selector(text=itemtext).xpath('//div[@class="newsTitle"]/text()').extract_first().strip()
 
  def get_indNewsItemTime (self, iteminfo, url=None, iyear=None, imonth=None, iday=None) :
      check_date = scrapy.Selector(text=iteminfo).xpath('//div[@class="newsTime"]/text()').extract_first().strip()

      self.nowTime= datetime.now(timezone(timedelta(hours=8)))
      indNewsItemTime = self.nowTime
      if (check_date is not None) and (len(check_date) > 0):

        if ('年' in check_date) and ('月' in check_date) and ('日' in check_date) :
          indNewsItemTime= datetime( int(check_date.split('年')[0]),
                                int(check_date.split('年')[1].split('月')[0]),
                                int(check_date.split('年')[1].split('月')[1].split('日')[0]),
                                0,
                                0,
                                0,
                                tzinfo=timezone(timedelta(hours=8)))
        #check what is the time format
        elif '小時前' in check_date:
          indNewsItemTime = self.nowTime - timedelta(hours=int(check_date.split('小時前')[0]))
          #if so, that means it is with in 00:00-23:59
        elif '分鐘前' in check_date:
          indNewsItemTime = self.nowTime - timedelta( minutes=int(check_date.split('分鐘前')[0]))
        else :
          indNewsItemTime = self.nowTime
    
      return indNewsItemTime 

  def get_numOfYieldRequestLimit (self) :
     return self.numOfYieldRequestLimit
 
  def get_dopagination (self, response) :
    print (' nowlatestnewsparser : ---- > get_dopagination')
    return self.dopagination

  def get_newPageURL (self, response) :
    print (' nowlatestnewsparser : ---- > get_newPageURL')
    pageNumber = response.url.rsplit('=',maxsplit=1)[-1]
    rootNewPageURL = response.url.rsplit('=',maxsplit=1)[0]
    newPageURL = rootNewPageURL + '=' + str(int(pageNumber) + 1)

    return newPageURL

 
  #def get_itemParseIt (self) :
  #  print (' nowlatestnewsparser : ---- > get_itemParseIt')
 
  def get_articleContent (self, response) :
    print (' nowlatestnewsparser : ---- > get_newPageURL')
    articleParagraphList = response.xpath('//div[@class="newsLeading"]//div[@class="contentTxt"]').extract()

    articleContent = ''.join(articleParagraphList)
    if len(articleContent.strip()) < 1 :
      articleContent = response.request.meta['indNewsItemTitle']

    return articleContent
    
 
  def get_parseImageURL (self, response) :
    print (' nowlatestnewsparser : ---- > get_parseImageURL')
    parseImageURL = response.xpath('//figure[@class="photo"]/img/@src | //a[@class="photo"]/img/@src ').extract_first()
    if parseImageURL is not None and len(parseImageURL) == 0 :
      parseImageURL=None

    return parseImageURL 




################## appledaily dailynews  
class AppledailyDailyNewsParser(GongGenericSource) :
  base_url = 'https://hk.news.appledaily.com'
  log_main_jpeg = False
  log_main_html = False
  log_item_jpeg = False
  log_item_html = False
  #self.itemParseIt = False
  #self.endpointexecute = 'execute'
  #numOfYieldRequestLimit = 20
  #dopagination = True
  #self.splash_args 
  #self.splash_args_item 



  #def get_endpoint(self) :
  #  print (' GongGenericSource : ---- > get_endpoint')
  #  return self.endpointexecute

  def get_newsItemList (self, resp=None, info=None) :
    newsItemList = resp.xpath('//div[@id="tab1"]/div[contains(@class, "ArchiveContainerLHS")]/div[@class="title"]/text()[(string-length(.) = 2 ) and (contains(. ,"頭條") or contains(. , "要聞") or contains(. , "港聞") )]/following::ul[1]/li/a[1]').extract()
   
    print (' appledailydailynewsparser : ---- > get_newsitemlist')
    return newsItemList


  def get_indNewsItemURL (self, itemtext, base_url=None) :

    print (' appledailydailynewsparser : ---- > get_indNewsItemURL')
    return scrapy.Selector(text=itemtext).xpath('//a/@href').extract_first()


  def get_indNewsItemTitle (self, itemtext) :
    print (' appledailydailynewsparser : ---- > get_indNewsItemTitle')
    return scrapy.Selector(text=itemtext).xpath('//a/text()').extract_first().replace('<br>','')
 
  def get_indNewsItemTime (self, iteminfo, url=None, iyear=None, imonth=None, iday=None) :
    self.nowTime= datetime.now(timezone(timedelta(hours=8)))
    indNewsItemTime= datetime( self.nowTime.year,
                                    self.nowTime.month ,
                                    self.nowTime.day ,
                                    0,
                                    0,
                                    0,
                                    999999,
                                    tzinfo=timezone(timedelta(hours=8)))


    return indNewsItemTime 

  #def get_numOfYieldRequestLimit (self) :
  #   return self.numOfYieldRequestLimit
 
  #def get_dopagination (self, response) :
  #  print (' appledailydailynewsparser : ---- > get_dopagination')
  #  return self.dopagination

  #def get_newPageURL (self, response) :
  #  print (' appledailydailynewsparser : ---- > get_newPageURL')

 
  #def get_itemParseIt (self) :
  #  print (' appledailydailynewsparser : ---- > get_itemParseIt')
 
  def get_articleContent (self, response) :
    print (' appledailydailynewsparser : ---- > get_newPageURL')
    articleContent=''
    articleParagraphList = response.xpath('//div[@class="ArticleContent_Inner"]').extract()
    for y in articleParagraphList :
      #savewhole
      #articleContent = articleContent + ''.join( [ x.strip() for x in scrapy.Selector(text=y).xpath('//text()').extract() ])
      articleContent = articleContent + ''.join( [ x.strip() for x in y ])

    if len(articleContent.strip()) < 1 :
      articleContent = response.request.meta['indNewsItemTitle']

    return articleContent
    
 
  def get_parseImageURL (self, response) :
    print (' appledailydailynewsparser : ---- > get_parseImageURL')
    parseImageURL = response.xpath('//div[@id="articleContent"]//div[contains(@class,"photo intro_photo") or contains(@class, "photo_right") or contains(@class, "photo_left") or contains(@class, "photo_center")]//a/@href').extract_first()
    #if there is a video, there is no pic
    if parseImageURL is not None and len(parseImageURL) == 0 :
      parseImageURL=None

    return parseImageURL 



################## singtao dailynews  
class SingtaoDailyNewsParser(GongGenericSource) :
  base_url = 'http://std.stheadline.com/daily/'
  #log_main_jpeg = False
  #log_main_html = False
  #log_item_jpeg = False
  #log_item_html = False
  #self.itemParseIt = False
  #self.endpointexecute = 'execute'
  numOfYieldRequestLimit = 0
  dopagination = True
  #self.splash_args 
  #self.splash_args_item 
  splash_args_item = {
            'html': 1,
            'jpeg': 1,
            'width': 600,
            'render_all': 1,
            'wait' : 20,
            'timeout': 350
    }



  #def get_endpoint(self) :
  #  print (' GongGenericSource : ---- > get_endpoint')
  #  return self.endpointexecute

  def get_newsItemList (self, resp=None, info=None) :
    print (' singtaodailynewsparser : ---- > get_newsitemlist')
    newsItemList = resp.xpath('//div[contains(@class,"top-news")]//div[@class="underline"]/a  |  //div[contains(@class,"list-content")]/div[contains(@class, "module-wrap") and contains(@class, "underline")]/a').extract()
    return newsItemList


  def get_indNewsItemURL (self, itemtext, base_url=None) :

    print (' singtaodailynewsparser : ---- > get_indNewsItemURL')
    return self.base_url + (scrapy.Selector(text=itemtext).xpath('//a/@href').extract_first())


  def get_indNewsItemTitle (self, itemtext) :
    print (' singtaodailynewsparser : ---- > get_indNewsItemTitle')
    return scrapy.Selector(text=itemtext).xpath('//a//div[@class="title"]/text()').extract_first()
 
  def get_indNewsItemTime (self, iteminfo, url=None, iyear=None, imonth=None, iday=None) :
    self.nowTime= datetime.now(timezone(timedelta(hours=8)))
    indNewsItemTime= datetime( self.nowTime.year,
                                    self.nowTime.month ,
                                    self.nowTime.day ,
                                    0,
                                    0,
                                    0,
                                    999999,
                                    tzinfo=timezone(timedelta(hours=8)))
    return indNewsItemTime 

  #def get_numOfYieldRequestLimit (self) :
  #   return self.numOfYieldRequestLimit
 
  #def get_dopagination (self, response) :
  #  print (' singtaodailynewsparser : ---- > get_dopagination')
  #  return self.dopagination

  def get_newPageURL (self, response) :
    print (' singtaodailynewsparser : ---- > get_newPageURL')
    if 'page' in response.url :
      pageNumber = response.url.rsplit('&', maxsplit=1)[0].rsplit('=', maxsplit=1)[-1]
    else :
      pageNumber = '1'
    howManyPageNumber = len( response.xpath('//nav[@class="pagination-bar"]/ul/li').extract() )
    if howManyPageNumber > 2:
       howManyPageNumber -= 2
    else :
       howManyPageNumber = 1

    newPageURL=self.base_url
    if (int(pageNumber) + 1) <= howManyPageNumber :
      newPageURL = 'http://std.stheadline.com/daily/section-list.php?page='  + str(int(pageNumber) + 1)  + '&cat=12'

    print (' singtaodailynewsparser : ---- > get_newPageURL=', newPageURL)
    return newPageURL

 
  #def get_itemParseIt (self) :
  #  print (' singtaodailynewsparser : ---- > get_itemParseIt')
 
  def get_articleContent (self, response) :
    print (' singtaodailynewsparser : ---- > get_newPageURL')
    articleParagraphList = response.xpath('//div[@class="paragraph"]/p').extract_first()
    articleContent =''.join( [ x.strip() for x in scrapy.Selector(text=articleParagraphList).xpath('//text()').extract() ])

    if articleContent is not None and len(articleContent.strip()) < 1 :
      articleContent = response.request.meta['indNewsItemTitle']

    return articleContent
    
 
  def get_parseImageURL (self, response) :
    print (' singtaodailynewsparser : ---- > get_parseImageURL')
    parseImageURL = response.xpath('//div[@class="paragraph"]//img/@src').extract_first()
    #if there is a video, there is no pic
    if parseImageURL is not None and len(parseImageURL) == 0 :
      parseImageURL=None

    return parseImageURL 



################## oriental dailynews  
class OrientaldailyDailyNewsParser(GongGenericSource) :
  base_url = 'http://orientaldaily.on.cc'
  #log_main_jpeg = False
  #log_main_html = False
  #log_item_jpeg = False
  #log_item_html = False
  #self.itemParseIt = False
  #self.endpointexecute = 'execute'
  #numOfYieldRequestLimit = 0
  #dopagination = True
  #self.splash_args 
  #self.splash_args_item 



  #def get_endpoint(self) :
  #  print (' GongGenericSource : ---- > get_endpoint')
  #  return self.endpointexecute

  def get_newsItemList (self, resp=None, info=None) :
    newsItemList = resp.xpath('//ul[@title="要聞"]//a | //ul[@title="港>聞"]//a ').extract()
    print (' orientaldailydailynewsparser : ---- > get_newsitemlist')
    return newsItemList


  def get_indNewsItemURL (self, itemtext, base_url=None) :

    print (' orientaldailydailynewsparser : ---- > get_indNewsItemURL')
    return self.base_url + scrapy.Selector(text=itemtext).xpath('//a/@href').extract_first()


  def get_indNewsItemTitle (self, itemtext) :
    print (' orientaldailydailynewsparser : ---- > get_indNewsItemTitle')
    return scrapy.Selector(text=itemtext).xpath('//a/text()').extract_first()
 
  def get_indNewsItemTime (self, iteminfo, url=None, iyear=None, imonth=None, iday=None) :
    self.nowTime= datetime.now(timezone(timedelta(hours=8)))
    indNewsItemTime= datetime( self.nowTime.year,
                                    self.nowTime.month ,
                                    self.nowTime.day ,
                                    0,
                                    0,
                                    0,
                                    999999,
                                    tzinfo=timezone(timedelta(hours=8)))
    return indNewsItemTime 

  #def get_numOfYieldRequestLimit (self) :
  #   return self.numOfYieldRequestLimit
 
  #def get_dopagination (self, response) :
  #  print (' orientaldailydailynewsparser : ---- > get_dopagination')
  #  return self.dopagination

  #def get_newPageURL (self, response) :
  #  print (' orientaldailydailynewsparser : ---- > get_newPageURL')
 
  #def get_itemParseIt (self) :
  #  print (' orientaldailydailynewsparser : ---- > get_itemParseIt')
 
  def get_articleContent (self, response) :
    print (' orientaldailydailynewsparser : ---- > get_newPageURL')
    articleParagraphList = response.xpath('//div[@id="leadin"]//p | //div[@id="contentCTN-right"]/p').extract()

    articleContent = ''.join([ x.strip() for x in articleParagraphList])
    if len(articleContent.strip()) < 1 :
      articleContent = response.request.meta['indNewsItemTitle']

    return articleContent
    
 
  def get_parseImageURL (self, response) :
    print (' orientaldailydailynewsparser : ---- > get_parseImageURL')
    checkparseImageURL = response.xpath('//div[contains(@class, "photo") or contains(@class, "hPhoto") or contains(@class, "vPhoto")]/a/img/@src').extract_first()
    if checkparseImageURL is None :
      parseImageURL=None
    else :
      parseImageURL = 'http://orientaldaily.on.cc' + checkparseImageURL

    return parseImageURL 



################## mingpao dailynews  
class MingpaoDailyNewsParser(GongGenericSource) :
  base_url = 'https://news.mingpao.com'
  #log_main_jpeg = False
  #log_main_html = False
  #log_item_jpeg = False
  #log_item_html = False
  #self.itemParseIt = False
  #self.endpointexecute = 'execute'
  #numOfYieldRequestLimit = 0
  #dopagination = True
  #self.splash_args 
  #self.splash_args_item 



  #def get_endpoint(self) :
  #  print (' GongGenericSource : ---- > get_endpoint')
  #  return self.endpointexecute

  def get_newsItemList (self, resp=None, info=None) :
    print (' mingpaodailynewsparser : ---- > get_newsitemlist')
    newsItemList =  resp.xpath('//div[@id="blocklisting1"]//div[@class="right"]//a | //div[@id="blocklisting2"]//div[@class="listing"]//a').extract()
    return newsItemList


  def get_indNewsItemURL (self, itemtext, base_url=None) :
    print (' mingpaodailynewsparser : ---- > get_indNewsItemURL')
    return self.base_url + scrapy.Selector(text=itemtext).xpath('//a/@href').extract_first()


  def get_indNewsItemTitle (self, itemtext) :
    print (' mingpaodailynewsparser : ---- > get_indNewsItemTitle')
    return scrapy.Selector(text=itemtext).xpath('//a/h1/text() | //a/text()').extract_first()
 
  def get_indNewsItemTime (self, iteminfo, url=None, iyear=None, imonth=None, iday=None) :
    self.nowTime= datetime.now(timezone(timedelta(hours=8)))
    indNewsItemTime= datetime( self.nowTime.year,
                                    self.nowTime.month ,
                                    self.nowTime.day ,
                                    0,
                                    0,
                                    0,
                                    999999,
                                    tzinfo=timezone(timedelta(hours=8)))
    return indNewsItemTime 

  #def get_numOfYieldRequestLimit (self) :
  #   return self.numOfYieldRequestLimit
 
  #def get_dopagination (self, response) :
  #  print (' mingpaodailynewsparser : ---- > get_dopagination')
  #  return self.dopagination

  #def get_newPageURL (self, response) :
  #  print (' mingpaodailynewsparser : ---- > get_newPageURL')
 
  #def get_itemParseIt (self) :
  #  print (' mingpaodailynewsparser : ---- > get_itemParseIt')
 
  def get_articleContent (self, response) :
    print (' mingpaodailynewsparser : ---- > get_articleContent')
    articleParagraphList = response.xpath('//span[@id="advenueINTEXT"]//div[contains(@id,"upper") or contains(@id,"lower")]/p[not(descendant::a)]').extract()
    articleContent =''.join( [ x.strip() for x in articleParagraphList ])
    if articleContent is None or len(articleContent.strip()) < 2 :
      articleContent = response.request.meta['indNewsItemTitle']

    return articleContent
    
 
  def get_parseImageURL (self, response) :
    print (' mingpaodailynewsparser : ---- > get_parseImageURL')
    checkparseImageURL = response.xpath('//div[@id="topvideo"]//div[@id="zoomedimg"]//img/@data-original').extract_first()
    if checkparseImageURL is None :
      parseImageURL=None
    else :
      parseImageURL = 'https:' + checkparseImageURL

    return parseImageURL 



################## hk01 latestnews  
class Hk01LatestNewsParser(GongGenericSource) :
  base_url = 'https://www.hk01.com'
  #log_main_jpeg = False
  #log_main_html = False
  #log_item_jpeg = False
  #log_item_html = False
  #self.itemParseIt = False
  endpointexecute = 'execute'
  #self.numOfYieldRequestLimit = 20
  #self.dopagination = True

  ###### hk01_latestnews
  script_org_hk01_latestnews = """
function main(splash, args)
    treat = require("treat")
    local num_scrolls = 20
    local scroll_delay = 5
    local result={}

    local scroll_to = splash:jsfunc("window.scrollTo")
    local get_body_height = splash:jsfunc(
        "function() {return document.body.scrollHeight;}"
    )
    local nowtimefunc = splash:jsfunc( [[
          function() {
             var nowTime = new Date();
             return nowTime.toString();
          }
    ]])

    splash:set_user_agent('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36')
    splash:go( args.url)
   splash:wait(3)
    width, height=splash:set_viewport_full()
    result['inside_width']= width
    result['inside_height']= height
    splash:wait(3)
    for num_scroll = 0, 2 do
        scroll_to(0, get_body_height())
        splash:wait(scroll_delay)
    end    

    -- splash:select('div[class*="lazyload_container"]'):scrollIntoViewIfNeeded()
    -- splash:wait(5)
    -- local loadmore = splash:select('div[class*="lazyload_container"]')
    local loadmore = splash:select('nav[class="channel_menubar"] li[class*="current"] a')
    loadmore:mouse_click()
    splash:wait(10)

    -- it does not have infinity scroll, it will be end like

    for num_scroll = 0, num_scrolls do
         splash:select('footer[class*="nocontent"]'):scrollIntoViewIfNeeded()    
         splash:wait(5)
        -- loadmore = splash:select('div[class*="lazyload_container"]')
        -- loadmore:mouse_click()
        -- scroll_to(0, get_body_height())
        -- splash:wait(scroll_delay)
    end    


    local name_html= "lua_scroll_html"
    result[name_html]=splash:html()
    result['jpeg']=splash:jpeg()
    result['lua_nowtime'] = nowtimefunc()
    return result
end
                   """
  splash_args = {
            'html': 1,
            'width': 600,
            'render_all': 1,
            'wait' : 20,
            'timeout' : 350,
            'lua_source' : script_org_hk01_latestnews,
  }
  splash_args_item = {
            'html': 1,
            'width': 600,
            'render_all': 1,
            'wait' : 15,
  }
  secondtryItemTime = True



  #def get_endpoint(self) :
  #  print (' GongGenericSource : ---- > get_endpoint')
  #  return self.endpointexecute

  def get_newsItemList (self, resp=None, info=None) :
    print (' hk01latestnewsparser : ---- > get_newsitemlist')
    newsItemList = scrapy.Selector(text=info).xpath('//div[contains(@class,"blog_listing__item") or contains(@class, "blog_listing__item normal")]/a').extract()
    return newsItemList


  def get_indNewsItemURL (self, itemtext, base_url=None) :
    print (' hk01latestnewsparser : ---- > get_indNewsItemURL')
    return scrapy.Selector(text=itemtext).xpath('//a/@href').extract_first() 


  def get_indNewsItemTitle (self, itemtext) :
    print (' hk01latestnewsparser : ---- > get_indNewsItemTitle')
    return scrapy.Selector(text=itemtext).xpath('//a//div[@class="blog_listing__item__content__tit"]/h3/text()').extract_first()
 
  def get_indNewsItemTime (self, iteminfo, url=None, iyear=None, imonth=None, iday=None) :
      check_date = scrapy.Selector(text=iteminfo).xpath('//a//div[@class="blog_listing__item__content__time"]/span/text()').extract_first()

      self.nowTime= datetime.now(timezone(timedelta(hours=8)))
      indNewsItemTime = self.nowTime
      if (check_date is not None) and (len(check_date) > 0):

        if ('年' in check_date) and ('月' in check_date) and ('日' in check_date) :
          indNewsItemTime= datetime( int(check_date.split('年')[0]),
                                int(check_date.split('年')[1].split('月')[0]),
                                int(check_date.split('年')[1].split('月')[1].split('日')[0]),
                                0,
                                0,
                                0,
                                tzinfo=timezone(timedelta(hours=8)))
        #check what is the time format
        elif '小時前' in check_date:
          indNewsItemTime = self.nowTime - timedelta(hours=int(check_date.split('小時前')[0]))
          #if so, that means it is with in 00:00-23:59
        elif '分鐘前' in check_date:
          indNewsItemTime = self.nowTime - timedelta( minutes=int(check_date.split('分鐘前')[0]))
        else :
          indNewsItemTime = self.nowTime
    
      return indNewsItemTime 

  #def get_numOfYieldRequestLimit (self) :
  #   return self.numOfYieldRequestLimit
 
  #def get_dopagination (self, response) :
  #  print (' hk01latestnewsparser : ---- > get_dopagination')
  #  return self.dopagination

  #def get_newPageURL (self, response) :
  #  print (' hk01latestnewsparser : ---- > get_newPageURL')
 
  #def get_itemParseIt (self) :
  #  print (' nowlatestnewsparser : ---- > get_itemParseIt')

  def get_secondItemTime(self, response):
    indNewsItemTime = response.request.meta['indNewsItemTime']
    indNewsItemTimeInfo = response.xpath('//div[contains(@class, "article_info") and contains(@class, "nocontent")]//div[@class="date"]/text()').extract()
    indNewsItemTimeInfo = indNewsItemTimeInfo[0].split('：')[1].strip()
    if indNewsItemTimeInfo is not None and len(indNewsItemTimeInfo) >0 :
      indNewsItemYearMonthDay = indNewsItemTimeInfo.split(' ')[0].split('-')
      indNewsItemHourandMin = indNewsItemTimeInfo.split(' ')[1].split(':')
      indNewsItemTime= datetime( int(indNewsItemYearMonthDay[0]),
                                    int(indNewsItemYearMonthDay[1]),
                                    int(indNewsItemYearMonthDay[2]),
                                    int(indNewsItemHourandMin[0]),
                                    int(indNewsItemHourandMin[1]),
                                    0,
                                    tzinfo=timezone(timedelta(hours=8)))
    return indNewsItemTime

  
 
  def get_articleContent (self, response) :
    print (' hk01latestnewsparser : ---- > get_newPageURL')
    articleParagraphList = response.xpath('//div[contains(@class, "article_content__module") and ( contains(@class, "article_summary") or contains(@class, "module_paragraph") or contains(@class, "module_rightside_content") or contains(@class,"module_leftside_content") )]//*[self::p or self::h2]').extract()
    articleContent =''.join( [ x.strip() for x in articleParagraphList ])
    if len(articleContent.strip()) < 1 :
      articleContent = response.request.meta['indNewsItemTitle']

    return articleContent
    
 
  def get_parseImageURL (self, response) :
    print (' hk01latestnewsparser : ---- > get_parseImageURL')
    parseImageURL = response.xpath('//div[contains(@class, "article_content__module") and contains(@class, "module_fullimg")]/object/@data').extract_first()
    if parseImageURL is not None and len(parseImageURL) == 0 :
      parseImageURL=None

    return parseImageURL 



################## post852 latestnews  
class Post852LatestNewsParser(GongGenericSource) :
  base_url = 'http://www.post852.com'
  #log_main_jpeg = False
  #log_main_html = False
  #log_item_jpeg = False
  #log_item_html = False
  #self.itemParseIt = False
  #self.endpointexecute = 'execute'
  numOfYieldRequestLimit = 20
  dopagination = True
  #self.splash_args 
  #self.splash_args_item 



  #def get_endpoint(self) :
  #  print (' GongGenericSource : ---- > get_endpoint')
  #  return self.endpointexecute

  def get_newsItemList (self, resp=None, info=None) :
    print (' post852latestnewsparser : ---- > get_newsitemlist')
    newsItemList = resp.xpath('//ul[@class="postcollection"]/li').extract()
    return newsItemList


  def get_indNewsItemURL (self, itemtext, base_url=None) :

    print (' post852latestnewsparser : ---- > get_indNewsItemURL')
    return scrapy.Selector(text=itemtext).xpath('//li/a/@href').extract_first()


  def get_indNewsItemTitle (self, itemtext) :
    print (' post852latestnewsparser : ---- > get_indNewsItemTitle')
    return scrapy.Selector(text=itemtext).xpath('//li/a/h3/text()').extract_first()
 
  def get_indNewsItemTime (self, iteminfo, url=None, iyear=None, imonth=None, iday=None) :
    indNewsItemTimeInfo = scrapy.Selector(text=iteminfo).xpath('//li/a/p/text()').extract_first().strip().split(' ')
    indNewsItemYearMonthDay = indNewsItemTimeInfo[0].strip().split('-')
    indNewsItemYear = indNewsItemYearMonthDay[0]
    indNewsItemMonth = indNewsItemYearMonthDay[1]
    indNewsItemDay = indNewsItemYearMonthDay[2]
    indNewsItemHourandMin = indNewsItemTimeInfo[1].strip().split(':')

    indNewsItemTime= datetime( int(indNewsItemYear),
                                    int(indNewsItemMonth),
                                    int(indNewsItemDay),
                                    int(indNewsItemHourandMin[0]),
                                    int(indNewsItemHourandMin[1]),
                                    0,
                                    tzinfo=timezone(timedelta(hours=8)))

    return indNewsItemTime 

  #def get_numOfYieldRequestLimit (self) :
  #   return self.numOfYieldRequestLimit
 
  #def get_dopagination (self, response) :
  #  print (' post852latestnewsparser : ---- > get_dopagination')
  #  return self.dopagination

  def get_newPageURL (self, response) :
    if 'page' in response.url :
      pageNumber = response.url.rsplit('/', maxsplit=1)[0].rsplit('/', maxsplit=1)[-1]
      rootNewPageURL =  response.url.rsplit('/', maxsplit=1)[0].rsplit('/', maxsplit=1)[0] + '/'
    else :
      pageNumber = '1'
      rootNewPageURL =  response.url + '/page/'
    newPageURL = rootNewPageURL  + str(int(pageNumber) + 1)

    print (' post852latestnewsparser : ---- > get_newPageURL')

    return newPageURL

 
  #def get_itemParseIt (self) :
  #  print (' post852latestnewsparser : ---- > get_itemParseIt')
 
  def get_articleContent (self, response) :
    print (' post852latestnewsparser : ---- > get_newPageURL')
    articleParagraphList = response.xpath('//div[contains(@class, "content") and contains(@class,  "clearfix")]/p').extract()

    articleContent =''.join( [ x.strip() for x in articleParagraphList ])
    if len(articleContent.strip()) < 1 :
      articleContent = response.request.meta['indNewsItemTitle']

    return articleContent
    
 
  def get_parseImageURL (self, response) :
    print (' post852latestnewsparser : ---- > get_parseImageURL')
    parseImageURL = response.xpath('//div[@class="image"]/img/@src').extract_first()
    if parseImageURL is not None and len(parseImageURL) == 0 :
      parseImageURL=None

    return parseImageURL 




################## passiontimes latestnews  
class PassiontimesLatestNewsParser(GongGenericSource) :
  base_url = 'http://www.passiontimes.hk'
  #log_main_jpeg = False
  #log_main_html = False
  #log_item_jpeg = False
  #log_item_html = False
  #self.itemParseIt = False
  #self.endpointexecute = 'execute'
  numOfYieldRequestLimit = 20
  dopagination = True
  #self.splash_args 
  #self.splash_args_item 



  #def get_endpoint(self) :
  #  print (' GongGenericSource : ---- > get_endpoint')
  #  return self.endpointexecute

  def get_newsItemList (self, resp=None, info=None) :
    print (' passiontimeslatestnewsparser : ---- > get_newsitemlist')
    newsItemList = resp.xpath('//div[@id="search-result-list"]/ul[@class="search"]/li').extract()
    return newsItemList


  def get_indNewsItemURL (self, itemtext, base_url=None) :

    print (' passiontimeslatestnewsparser : ---- > get_indNewsItemURL')
    return scrapy.Selector(text=itemtext).xpath('//div[@class="textBox"]/h4/a/@href').extract_first()


  def get_indNewsItemTitle (self, itemtext) :
    print (' passiontimeslatestnewsparser : ---- > get_indNewsItemTitle')
    return scrapy.Selector(text=itemtext).xpath('//div[@class="textBox"]/h4/a/text()').extract_first()

 
  def get_indNewsItemTime (self, iteminfo, url=None, iyear=None, imonth=None, iday=None) :
    self.nowTime= datetime.now(timezone(timedelta(hours=8)))
    indNewsItemTimeInfo = scrapy.Selector(text=iteminfo).xpath('//div[@class="textBox"]/h6/span[@class="date"]/text()').extract_first().strip().split('-')
    indNewsItemYear = indNewsItemTimeInfo[2]
    indNewsItemMonth = indNewsItemTimeInfo[0]
    indNewsItemDay = indNewsItemTimeInfo[1]
    #use the now time hour and min because passiontimes
    #does not have hour and minute information
    indNewsItemMicrosecond = url.split('/')[-1]
    indNewsItemTime= datetime( int(indNewsItemYear),
                                  int(indNewsItemMonth),
                                  int(indNewsItemDay),
                                  self.nowTime.hour,
                                  self.nowTime.minute,
                                  0,
                                  int(indNewsItemMicrosecond),
                                  tzinfo=timezone(timedelta(hours=8)))

    return indNewsItemTime 

  #def get_numOfYieldRequestLimit (self) :
  #   return self.numOfYieldRequestLimit
 
  #def get_dopagination (self, response) :
  #  print (' passiontimeslatestnewsparser : ---- > get_dopagination')
  #  return self.dopagination

  def get_newPageURL (self, response) :
    pageNumber = response.url.rsplit('=',maxsplit=1)[-1]
    rootNewPageURL = response.url.rsplit('=',maxsplit=1)[0]
    newPageURL = rootNewPageURL + '=' + str(int(pageNumber) + 1)

    return newPageURL

 
  #def get_itemParseIt (self) :
  #  print (' passiontimeslatestnewsparser : ---- > get_itemParseIt')
 
  def get_articleContent (self, response) :
    print (' passiontimeslatestnewsparser : ---- > get_articleContent')
    articleParagraphList = response.xpath('//div[@class="article-body"]/p').extract()

    articleContent =''.join( [ x.strip() for x in articleParagraphList ])
    if len(articleContent.strip()) < 1 :
      #savewhole
      articleParagraphList = response.xpath('//div[@class="article-body"]/div').extract()
      articleContent =''.join( [ x.strip() for x in articleParagraphList ])
      if len(articleContent.strip()) < 1 :
        articleContent = response.request.meta['indNewsItemTitle']

    return articleContent
    
 
  def get_parseImageURL (self, response) :
    print (' passiontimeslatestnewsparser : ---- > get_parseImageURL')
    parseImageURL = response.xpath('//div[@class="article-body"]/p/img/@src | //div[@class="article-body"]/div/img/@src').extract_first()
    if parseImageURL is not None :
      if len(parseImageURL) == 0 :
        parseImageURL=None
      else :
        parseImageURL= 'http://www.passiontimes.hk' + parseImageURL

    return parseImageURL 



################## standnews latestnews  
class StandnewsLatestNewsParser(GongGenericSource) :
  base_url = 'https://www.thestandnews.com'
  #log_main_jpeg = False
  #log_main_html = False
  #log_item_jpeg = False
  #log_item_html = False
  #self.itemParseIt = False
  #self.endpointexecute = 'execute'
  numOfYieldRequestLimit = 15 
  dopagination = True
  #self.splash_args 
  #self.splash_args_item 



  #def get_endpoint(self) :
  #  print (' GongGenericSource : ---- > get_endpoint')
  #  return self.endpointexecute

  def get_newsItemList (self, resp=None, info=None) :
    print (' standnewslatestnewsparser : ---- > get_newsitemlist')
    newsItemList = resp.xpath('//div[@class="article-large-list"]/div[contains(@class,  "article-block article")]').extract()

    return newsItemList


  def get_indNewsItemURL (self, itemtext, base_url=None) :

    print (' standnewslatestnewsparser : ---- > get_indNewsItemURL')
    return self.base_url + (scrapy.Selector(text=itemtext).xpath('//div[contains(@class, "info")]/h3/a/@href').extract_first()  )


  def get_indNewsItemTitle (self, itemtext) :
    print (' standnewslatestnewsparser : ---- > get_indNewsItemTitle')
    return scrapy.Selector(text=itemtext).xpath('//div[contains(@class, "info")]/h3/a/text()').extract_first()


 
  def get_indNewsItemTime (self, iteminfo, url=None, iyear=None, imonth=None, iday=None) :
    indNewsItemTimeInfo = scrapy.Selector(text=iteminfo).xpath('//div[contains(@class, "info")]/p/span/text()').extract_first().strip()
    indNewsItemTimeInfo = indNewsItemTimeInfo.split('\u2014')
    indNewsItemYear = indNewsItemTimeInfo[0].strip().split('/')[0]
    indNewsItemMonth = indNewsItemTimeInfo[0].strip().split('/')[1]
    indNewsItemDay = indNewsItemTimeInfo[0].strip().split('/')[2]
    indNewsItemHourandMin = indNewsItemTimeInfo[1].strip().split(':')

    indNewsItemTime= datetime( int(indNewsItemYear),
                              int(indNewsItemMonth),
                              int(indNewsItemDay),
                              int(indNewsItemHourandMin[0]),
                              int(indNewsItemHourandMin[1]),
                              0,
                              tzinfo=timezone(timedelta(hours=8)))

    return indNewsItemTime 

  #def get_numOfYieldRequestLimit (self) :
  #   return self.numOfYieldRequestLimit
 
  #def get_dopagination (self, response) :
  #  print (' standnewslatestnewsparser : ---- > get_dopagination')
  #  return self.dopagination

  def get_newPageURL (self, response) :
    pageNumber = response.url.rsplit('=',maxsplit=1)[-1]
    rootNewPageURL = response.url.rsplit('=',maxsplit=1)[0]
    newPageURL = rootNewPageURL + '=' + str(int(pageNumber) + 1)

    return newPageURL

 
  #def get_itemParseIt (self) :
  #  print (' standnewslatestnewsparser : ---- > get_itemParseIt')
 
  def get_articleContent (self, response) :
    print (' standnewslatestnewsparser : ---- > get_articleContent')
    articleParagraphList = response.xpath('//div[@class="article-content"]/p[not(descendant::a) and not(descendant::iframe)]').extract()
    articleContent = ''.join(articleParagraphList)
    if len(articleContent.strip()) < 1 :
      articleContent = response.request.meta['indNewsItemTitle']

    return articleContent
    
 
  def get_parseImageURL (self, response) :
    print (' standnewslatestnewsparser : ---- > get_parseImageURL')
    parseImageURL = response.xpath('//div[contains(@class, "article-photo") and contains(@class, "article-media") ]/a/img/@src | //div[@class="article-content"]/p/a/img/@src').extract_first()
    if parseImageURL is not None and len(parseImageURL) == 0 :
      parseImageURL=None

    return parseImageURL 



################## mingpao latestnews  
class MingpaoLatestNewsParser(GongGenericSource) :
  base_url = 'https://news.mingpao.com'
  #log_main_jpeg = False
  #log_main_html = False
  #log_item_jpeg = False
  #log_item_html = False
  #self.itemParseIt = False
  endpointexecute = 'execute'
  #numOfYieldRequestLimit = 0
  #dopagination = True
  #self.splash_args 
  #self.splash_args_item 

  ###### mingpao_latestnews
  script_org_mingpao_latestnews = """
function main(splash, args)
    treat = require("treat")
    local num_scrolls = 15
    local scroll_delay = 2
    local result={}

    local scroll_to = splash:jsfunc("window.scrollTo")
    local get_body_height = splash:jsfunc(
        "function() {return document.body.scrollHeight;}"
    )
    local nowtimefunc = splash:jsfunc( [[
          function() {
             var nowTime = new Date();
             return nowTime.toString();
          }
    ]])

    local check_and_remove_video = splash:jsfunc( [[
          function() {
            var element = document.getElementById("video_player") ;
            if (element === null) {
              return false ;
            }
            element.parentNode.removeChild(element); '
            return true;
          }
     ]])
    splash:set_user_agent('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36')
    splash:go( args.url)
    splash:wait(3)
    width, height=splash:set_viewport_full()
    result['inside_width']= width
    result['inside_height']= height
    splash:wait(3)
    for num_scroll = 0, num_scrolls do
        scroll_to(0, get_body_height())
        splash:wait(scroll_delay)
    end    

    splash:select('button[class*="loadmore"]'):scrollIntoViewIfNeeded()
    splash:wait(5)
    local loadmore = splash:select('button[class*="loadmore"]')
    loadmore:mouse_click()
    splash:wait(10)


    for num_scroll = 0, num_scrolls do
        splash:select('button[class*="loadmore"]'):scrollIntoViewIfNeeded()
        splash:wait(5)
        loadmore = splash:select('button[class*="loadmore"]')
        loadmore:mouse_click()
        scroll_to(0, get_body_height())
        splash:wait(scroll_delay)
    end    


    local name_html= "lua_scroll_html"
    result[name_html]=splash:html()
    result['jpeg']=splash:jpeg()
    result['lua_nowtime'] = nowtimefunc()
    return result
end
                   """
  splash_args = {
            'html': 1,
            'width': 600,
            'render_all': 1,
            'wait' : 20,
            'timeout' : 350,
            'lua_source' : script_org_mingpao_latestnews,
  }
  splash_args_item = {
            'html': 1,
            'width': 600,
            'render_all': 1,
            'wait' : 15,
            'js_source' : """ var element = document.querySelector('div[id="topvideo"] div[id="zoomedimg"] a iframe') ; if (element === null) { return false ; } element.parentNode.removeChild(element); element = document.querySelector('div[class*="span_4_of_12"] ') ; if (element === null) { return false ; } element.parentNode.removeChild(element); return true; """
  }


  #def get_endpoint(self) :
  #  print (' GongGenericSource : ---- > get_endpoint')
  #  return self.endpointexecute

  def get_newsItemList (self, resp=None, info=None) :
    print (' mingpaolatestnewsparser : ---- > get_newsitemlist')
    newsItemList =  scrapy.Selector(text=info).xpath('//div[@class="cat12"]//ul[contains(@class,"twocol") and contains(@class, "left")]/div[@class="date"] | //div[@class="cat12"]//ul[contains(@class,"twocol") and contains(@class, "left")]/li[@class="list1"]').extract()

    return newsItemList


  def get_indNewsItemURL (self, itemtext, base_url=None) :
    print (' mingpaolatestnewsparser : ---- > get_indNewsItemURL')
    return self.base_url + scrapy.Selector(text=itemtext).xpath('//a/@href').extract_first()


  def get_indNewsItemTitle (self, itemtext) :
    print (' mingpaolatestnewsparser : ---- > get_indNewsItemTitle')
    return scrapy.Selector(text=itemtext).xpath('//a/text()').extract_first()
 
  def get_indNewsItemTime (self, iteminfo, url=None, iyear=None, imonth=None, iday=None) :
    indNewsItemHourandMin= scrapy.Selector(text=iteminfo).xpath('//a/span[@class="time"]/text()').extract_first().strip()[1:-1].split(':')
    indNewsItemTime= datetime( int(iyear),
                              int(imonth),
                              int(iday),
                              int(indNewsItemHourandMin[0]),
                              int(indNewsItemHourandMin[1]),
                              0,
                              tzinfo=timezone(timedelta(hours=8)))

    return indNewsItemTime 

  #def get_numOfYieldRequestLimit (self) :
  #   return self.numOfYieldRequestLimit
 
  #def get_dopagination (self, response) :
  #  print (' mingpaolatestnewsparser : ---- > get_dopagination')
  #  return self.dopagination

  #def get_newPageURL (self, response) :
  #  print (' mingpaolatestnewsparser : ---- > get_newPageURL')
 
  #def get_itemParseIt (self) :
  #  print (' mingpaolatestnewsparser : ---- > get_itemParseIt')
 
  def get_articleContent (self, response) :
    print (' mingpaolatestnewsparser : ---- > get_articleContent')
    articleParagraphList = response.xpath('//span[@id="advenueINTEXT"]//div[contains(@id,"upper") or contains(@id,"lower")]/p[not(descendant::a)]').extract()
    articleContent =''.join( [ x.strip() for x in articleParagraphList ])
    if articleContent is None or len(articleContent.strip()) < 2 :
      articleContent = response.request.meta['indNewsItemTitle']

    return articleContent
    
 
  def get_parseImageURL (self, response) :
    print (' mingpaolatestnewsparser : ---- > get_parseImageURL')
    checkparseImageURL = response.xpath('//div[@id="topvideo"]//div[@id="zoomedimg"]//img/@data-original').extract_first()
    if checkparseImageURL is None :
      parseImageURL=None
    else :
      parseImageURL = 'https:' + checkparseImageURL

    return parseImageURL 





################## singtao latestnews  
class SingtaoLatestNewsParser(GongGenericSource) :
  base_url = 'http://std.stheadline.com/daily/'
  #log_main_jpeg = False
  #log_main_html = False
  #log_item_jpeg = False
  #log_item_html = False
  #self.itemParseIt = False
  #self.endpointexecute = 'execute'
  numOfYieldRequestLimit = 0
  dopagination = True
  #self.splash_args 
  #self.splash_args_item 
  ###### singtao_latestnews
  script_org_singtao_latestnews = """
function main(splash, args)
    treat = require("treat")
    local num_scrolls = 5
    local scroll_delay = 2
    local result={}

    local scroll_to = splash:jsfunc("window.scrollTo")
    local get_body_height = splash:jsfunc(
        "function() {return document.body.scrollHeight;}"
    )

    local check_and_remove_video = splash:jsfunc( [[
          function() {
            var element = document.getElementById("video_player") ;
            if (element === null) {
              return false ;
            }
            element.parentNode.removeChild(element); '
            return true;
          }
     ]])
    splash:set_user_agent('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36')
    splash:go( args.url)
    splash:wait(3)
    width, height=splash:set_viewport_full()
    result['inside_width']= width
    result['inside_height']= height
    splash:wait(3)
    for num_scroll = 0, num_scrolls do
        scroll_to(0, get_body_height())
        splash:wait(scroll_delay)
    end    

    splash:select('a[href="#hk"]'):scrollIntoViewIfNeeded()
    splash:wait(5)
    local breakingnewstab = splash:select('a[href="#hk"]')
    breakingnewstab:mouse_click()
    splash:wait(10)

    splash:select('div.load-more'):scrollIntoViewIfNeeded()
    splash:wait(5)
    local loadmore = splash:select('div.load-more')
    num_scrolls = 35
    for num_scroll = 0, num_scrolls do
        splash:select('div.load-more'):scrollIntoViewIfNeeded()
        splash:wait(5)
        loadmore = splash:select('div.load-more')
        loadmore:mouse_click()
        scroll_to(0, get_body_height())
        splash:wait(scroll_delay)
    end    


    local name_html= "lua_scroll_html"
    result[name_html]=splash:html()
    result['jpeg']=splash:jpeg()
    return result
end
                   """
  splash_args = {
            'html': 1,
            'width': 600,
            'render_all': 1,
            'wait' : 20,
            'timeout' : 350,
            'lua_source' : script_org_singtao_latestnews,
  }
  splash_args_item = {
            'html': 1,
            'width': 600,
            'render_all': 1,
            'wait' : 15,
            'js_source' : ' var element = document.getElementById("video_player") ; if (element === null) { return false ; } element.parentNode.removeChild(element);  return true; '
  }



  #def get_endpoint(self) :
  #  print (' GongGenericSource : ---- > get_endpoint')
  #  return self.endpointexecute

  def get_newsItemList (self, resp=None, info=None) :
    print (' singtaolatestnewsparser : ---- > get_newsitemlist')
    newsItemList = scrapy.Selector(text=info).xpath('//div[@id="hk"]/div').extract()
    return newsItemList


  def get_indNewsItemURL (self, itemtext, base_url=None) :

    print (' singtaolatestnewsparser : ---- > get_indNewsItemURL')
    return  scrapy.Selector(text=itemtext).xpath('//div[contains(@class, "module-wrap") and contains(@class, "underline")]/a/@href').extract_first()


  def get_indNewsItemTitle (self, itemtext) :
    print (' singtaolatestnewsparser : ---- > get_indNewsItemTitle')
    return scrapy.Selector(text=itemtext).xpath('//div[contains(@class, "module-wrap") and contains(@class, "underline")]/a/div[@class="module-detail"]/div[@class="title"]/text()').extract_first()
 
  def get_indNewsItemTime (self, iteminfo, url=None, iyear=None, imonth=None, iday=None) :
    self.nowTime= datetime.now(timezone(timedelta(hours=8)))
    indNewsItemDateandTime= scrapy.Selector(text=iteminfo).xpath('//div[contains(@class, "module-wrap") and contains(@class, "underline")]/a/div[@class="module-detail"]/div[@class="time"]/text()').extract_first().strip()
    indNewsItemTime= datetime( int(indNewsItemDateandTime[:4]),
                              int(indNewsItemDateandTime[5:7]),
                              int(indNewsItemDateandTime[8:10]),
                              int(indNewsItemDateandTime[11:13]),
                              int(indNewsItemDateandTime[14:]),
                              0,
                              tzinfo=timezone(timedelta(hours=8)))

    return indNewsItemTime 

  #def get_numOfYieldRequestLimit (self) :
  #   return self.numOfYieldRequestLimit
 
  #def get_dopagination (self, response) :
  #  print (' singtaolatestnewsparser : ---- > get_dopagination')
  #  return self.dopagination

  #def get_newPageURL (self, response) :
  #  print (' singtaolatestnewsparser : ---- > get_newPageURL')

 
  #def get_itemParseIt (self) :
  #  print (' singtaodailynewsparser : ---- > get_itemParseIt')
 
  def get_articleContent (self, response) :
    print (' singtaolatestnewsparser : ---- > get_newPageURL')
    articleParagraphList = response.xpath('//div[@class="paragraph"]/p').extract_first()
    articleContent =''.join( [ x.strip() for x in scrapy.Selector(text=articleParagraphList).xpath('//text()').extract() ])

    if articleContent is not None and len(articleContent.strip()) < 1 :
      articleContent = response.request.meta['indNewsItemTitle']

    return articleContent
    
 
  def get_parseImageURL (self, response) :
    print (' singtaolatestnewsparser : ---- > get_parseImageURL')
    parseImageURL = response.xpath('//div[@class="paragraph"]//img/@src').extract_first()
    #if there is a video, there is no pic
    if parseImageURL is not None and len(parseImageURL) == 0 :
      parseImageURL=None

    return parseImageURL 





################## appledaily latestnews  
class AppledailyLatestNewsParser(GongGenericSource) :
  base_url = 'https://hk.news.appledaily.com'
  #log_main_jpeg = False
  #log_main_html = False
  #log_item_jpeg = False
  #log_item_html = False
  #self.itemParseIt = False
  endpointexecute = 'execute'
  #numOfYieldRequestLimit = 20
  #dopagination = True
  #self.splash_args 
  #self.splash_args_item 

  script_org_appledaily_latestnews = """
function main(splash, args)
    treat = require("treat")
    local num_scrolls = 5
    local scroll_delay = 2
    local result={}

    local scroll_to = splash:jsfunc("window.scrollTo")
    local get_body_height = splash:jsfunc(
        "function() {return document.body.scrollHeight;}"
    )

    local check_and_remove_video = splash:jsfunc( [[
          function() {
            var element = document.getElementById("video_player") ;
            if (element === null) {
              return false ;
            }
            element.parentNode.removeChild(element); '
            return true;
          }
     ]])
    splash:set_user_agent('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36')
    splash:go( args.url)
    splash:wait(3)
    width, height=splash:set_viewport_full()
    result['inside_width']= width
    result['inside_height']= height
    splash:wait(3)
    for num_scroll = 0, num_scrolls do
        scroll_to(0, get_body_height())
        splash:wait(scroll_delay)
    end    
--    splash:select('#news_tab'):scrollIntoViewIfNeeded()
    splash:select('#local_tab'):scrollIntoViewIfNeeded()
    splash:wait(5)
--    local breakingnewstab = splash:select('#news_tab')
    local breakingnewstab = splash:select('#local_tab')
    breakingnewstab:mouse_click()
    splash:wait(10)

    local name_html= "lua_scroll_html"
    result[name_html]=splash:html()
    result['jpeg']=splash:jpeg()
    return result
end
                   """
  splash_args = {
            'html': 1,
            'width': 600,
            'render_all': 1,
            'wait' : 20,
            'timeout' : 350,
            'lua_source' : script_org_appledaily_latestnews,
  }
  splash_args_item = {
            'html': 1,
            'width': 600,
            'render_all': 1,
            'wait' : 15,
            'js_source' : ' var element = document.getElementById("video_player") ; if (element === null) { return false ; } element.parentNode.removeChild(element);  return true; '
  }



  #def get_endpoint(self) :
  #  print (' GongGenericSource : ---- > get_endpoint')
  #  return self.endpointexecute

  def get_newsItemList (self, resp=None, info=None) :
    print (' appledailydailynewsparser : ---- > get_newsitemlist')
    newsItemList =  scrapy.Selector(text=info).xpath('//div[@class="itemContainer"]//div[@class="RTitem"]//div[@class="RTitemRHS"]').extract()

    return newsItemList


  def get_indNewsItemURL (self, itemtext, base_url=None) :
    print (' appledailydailynewsparser : ---- > get_indNewsItemURL')
    return scrapy.Selector(text=itemtext).xpath('//div[@class="text"]/a/@href').extract_first()

  def get_indNewsItemTitle (self, itemtext) :
    print (' appledailydailynewsparser : ---- > get_indNewsItemTitle')
    return scrapy.Selector(text=itemtext).xpath('//div[@class="text"]/a/text()').extract_first()
 
  def get_indNewsItemTime (self, iteminfo, url=None, iyear=None, imonth=None, iday=None) :
    self.nowTime= datetime.now(timezone(timedelta(hours=8)))
    indNewsItemHourandMin = scrapy.Selector(text=iteminfo).xpath('//div[@class="time"]/text()').extract_first().strip().split(':')
    indNewsItemYearMonthDay = scrapy.Selector(text=iteminfo).xpath('//div[@class="date"]/text()').extract_first()

    indNewsItemYear = indNewsItemYearMonthDay[:4]
    indNewsItemMonth = indNewsItemYearMonthDay[4:6]
    indNewsItemDay = indNewsItemYearMonthDay[6:]
    indNewsItemTime= datetime( int(indNewsItemYear),
                              int(indNewsItemMonth),
                              int(indNewsItemDay),
                              int(indNewsItemHourandMin[0]),
                              int(indNewsItemHourandMin[1]),
                              0,
                              tzinfo=timezone(timedelta(hours=8)))

    return indNewsItemTime 

  #def get_numOfYieldRequestLimit (self) :
  #   return self.numOfYieldRequestLimit
 
  #def get_dopagination (self, response) :
  #  print (' appledailydailynewsparser : ---- > get_dopagination')
  #  return self.dopagination

  #def get_newPageURL (self, response) :
  #  print (' appledailydailynewsparser : ---- > get_newPageURL')

 
  #def get_itemParseIt (self) :
  #  print (' appledailydailynewsparser : ---- > get_itemParseIt')
 
  def get_articleContent (self, response) :
    print (' appledailydailynewsparser : ---- > get_newPageURL')
    articleContent=''
    articleParagraphList = response.xpath('//div[@class="ArticleContent_Inner"]').extract()
    for y in articleParagraphList :
      #savewhole
      #articleContent = articleContent + ''.join( [ x.strip() for x in scrapy.Selector(text=y).xpath('//text()').extract() ])
      articleContent = articleContent + ''.join( [ x.strip() for x in y ])

    if len(articleContent.strip()) < 1 :
      articleContent = response.request.meta['indNewsItemTitle']

    return articleContent
    
 
  def get_parseImageURL (self, response) :
    print (' appledailydailynewsparser : ---- > get_parseImageURL')
    parseImageURL = response.xpath('//div[@id="articleContent"]//div[contains(@class,"photo intro_photo") or contains(@class, "photo_right") or contains(@class, "photo_left") or contains(@class, "photo_center")]//a/@href').extract_first()
    #if there is a video, there is no pic
    if parseImageURL is not None and len(parseImageURL) == 0 :
      parseImageURL=None

    return parseImageURL 










################## on.cc latestnews  
class OrientaldailyNetLatestNewsParser(GongGenericSource) :
  base_url = 'http://hk.on.cc'
  #log_main_jpeg = False
  #log_main_html = False
  #log_item_jpeg = False
  #log_item_html = False
  #itemParseIt = False
  endpointexecute = 'execute'
  #self.numOfYieldRequestLimit = 20
  #self.dopagination = True

    ####   on_cc_latestnews
  script_org_on_cc_latestnews = """
function main(splash, args)
    treat = require("treat")
    local num_scrolls = 30
    local scroll_delay = 5

    local scroll_to = splash:jsfunc("window.scrollTo")
    local get_body_height = splash:jsfunc(
        "function() {return document.body.scrollHeight;}"
    )
    local log_iteration = splash:jsfunc(
        "function(number_log) {return document.title=number_log;}"
    )

    local num_of_div_class_seq = splash:jsfunc( [[
          function() {
            var seqstringlist = document.evaluate('//div[@class="seq"]', document , null, XPathResult.ANY_TYPE, null);
            var seqstring = seqstringlist.iterateNext();
            var seqstringcount =0;
            while (seqstring) {
              seqstringcount = seqstringcount +1;
              seqstring = seqstringlist.iterateNext() ;
            }
            return seqstringcount;
          }
     ]])
    -- splash:go( 'http://spidyquotes.herokuapp.com/scroll')
    splash:set_user_agent('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/59.0.3071.115 Safari/537.36')
    -- splash:go( 'https://hk.news.yahoo.com/hong-kong/archive')
    splash:go( args.url)
    splash:wait(3)
    width, height=splash:set_viewport_full()
    splash:wait(3)
    splash:runjs(' document.title="hello world";')
    local result={}
    result['num_scrolls']= num_scrolls
    result['inside_width']= width
    result['inside_height']= height
    local check_div=0
    local addfooter= splash:select('#footer')

    splash:wait(10)
--    splash:select('#breakingnewsContent'):scrollIntoViewIfNeeded()
    splash:select('#breakingnewsTab'):scrollIntoViewIfNeeded()
    splash:wait(5)
    local breakingnewstab = splash:select('#breakingnewsTab')
    breakingnewstab:mouse_click()
    splash:wait(15)
    local count_num_scroll=0
--    for num_scroll = 0, num_scrolls do
--        scroll_to(0, get_body_height())
--        splash:wait(scroll_delay)
--        count_num_scroll= 1 + count_num_scroll
--    end  
    for num_scroll = 0, num_scrolls do
--       log_class_seq(num_scroll)
--
         if (num_scroll /10) then
           check_div= num_of_div_class_seq()
--           if (check_div > 1)then
--             break
--           end
         end
--       scroll_to(0, get_body_height())
--       splash:wait(scroll_delay)
         splash:select('#footer'):scrollIntoViewIfNeeded()
         splash:wait(scroll_delay)
         breakingnewstab = splash:select('#footer')
--         breakingnewstab:mouse_click()
    end    
--    check_div=num_of_div_class_seq()
    local name_html= "lua_scroll_html"
    result[name_html]=splash:html()
    result['jpeg']=splash:jpeg()
    result['check_div']= check_div
    result['count_num_scroll']= count_num_scroll
    return result
end
                   """
  splash_args = {
            'html': 1,
            'width': 600,
            'render_all': 1,
            'wait' : 20,
            'timeout' : 350,
            'lua_source' : script_org_on_cc_latestnews,
    }
  splash_args_item = {
            'html': 1,
            'width': 600,
            'render_all': 1,
            'wait' : 15,
            'js_source' : ' var elements = document.getElementsByClassName("video") ; elements[0].parentNode.removeChild(elements[0]); '
    }





  def get_endpoint(self) :
    print (' GongGenericSource : ---- > get_endpoint')
    return self.endpointexecute

  def get_newsItemList (self, resp=None, info=None) :
    print (' orientaldailynetlatestnewsparser : ---- > get_newsItemList')
    return scrapy.Selector(text=info).xpath('//div[contains(@class,"focus clearfix") and not(contains(@class, "gemini-loaded"))]').extract()


  def get_indNewsItemURL (self, itemtext, base_url=None) :
    print (' orientaldailynetlatestnewsparser : ---- > get_indNewsItemURL')
    return self.base_url + (scrapy.Selector(text=itemtext).xpath('//div[@class="thumb"]/a/@href').extract_first()  )


  def get_indNewsItemTitle (self, itemtext) :
    print (' orientaldailynetlatestnewsparser : ---- > get_indNewsItemTitle')
    return scrapy.Selector(text=itemtext).xpath('//div[@class="thumb"]/a/@title').extract_first()
 
  def get_indNewsItemTime (self, iteminfo, url=None, iyear=None, imonth=None, iday=None) :
      indNewsItemHourandMin = scrapy.Selector(text=iteminfo).xpath('//div[@class="datetime"]/a/text()').extract_first().strip()[10:15].split(':')
      indNewsItemMonthandDay = scrapy.Selector(text=iteminfo).xpath('//div[@class="datetime"]/a/text()').extract_first().strip()[:5]

      indNewsItemMonth = indNewsItemMonthandDay[:2]
      indNewsItemDay = indNewsItemMonthandDay[3:]

      self.nowTime= datetime.now(timezone(timedelta(hours=8)))
      indNewsItemTime= datetime( self.nowTime.year,
                                    int(indNewsItemMonth),
                                    int(indNewsItemDay),
                                    int(indNewsItemHourandMin[0]),
                                    int(indNewsItemHourandMin[1]),
                                    0,
                                    tzinfo=timezone(timedelta(hours=8)))
      return indNewsItemTime


 
  #def get_dopagination (self, response) :
  #  print (' orientaldailynetlatestnewsparser : ---- > get_dopagination')

  #def get_newPageURL (self, response) :
  #  print (' orientaldailynetlatestnewsparser : ---- > get_newPageURL')
 
  #def get_itemParseIt (self) :
  #  print (' orientaldailynetlatestnewsparser : ---- > get_itemParseIt')
 
  def get_articleContent (self, response) :
    print (' orientaldailynetlatestnewsparser : ---- > get_newPageURL')
    articleParagraphList = response.xpath('//div[@class="leftSide"]/div[@class="breakingNewsContent"]/p[@class="summary"]').extract()

    articleContent = ''.join([ x.strip() for x in articleParagraphList])
    if len(articleContent.strip()) < 1 :
      articleContent = response.request.meta['indNewsItemTitle']

    return articleContent
    
 
  def get_parseImageURL (self, response) :
    print (' orientaldailynetlatestnewsparser : ---- > get_parseImageURL')
    parseImageURL = response.xpath('//div[@id="centerCTN"]//div[@class="photoCTN"]//img/@src').extract_first()
    if parseImageURL is not None and len(parseImageURL) == 0 :
       parseImageURL=None
    else :
       parseImageURL = 'http://hk.on.cc' + parseImageURL

    return parseImageURL 







################## rthk latestnews  
class RthkLatestNewsParser(GongGenericSource) :
  base_url = 'http://news.rthk.hk'
  #log_main_jpeg = False
  #log_main_html = False
  #log_item_jpeg = False
  #log_item_html = False
  #self.itemParseIt = False
  #self.endpointexecute = 'execute'
  #numOfYieldRequestLimit = 15 
  #dopagination = True
  #self.splash_args 
  #self.splash_args_item 



  #def get_endpoint(self) :
  #  print (' GongGenericSource : ---- > get_endpoint')
  #  return self.endpointexecute

  def get_newsItemList (self, resp=None, info=None) :
    print (' rthklatestnewsparser : ---- > get_newsitemlist')
    newsItemList = resp.xpath('//div[@class="newsContainer"]/div[@class="item"]').extract()

    return newsItemList


  def get_indNewsItemURL (self, itemtext, base_url=None) :

    print (' rthklatestnewsparser : ---- > get_indNewsItemURL')
    return self.base_url + (scrapy.Selector(text=itemtext).xpath('//span[@class="title"]/a/@href').extract_first()  )


  def get_indNewsItemTitle (self, itemtext) :
    print (' rthklatestnewsparser : ---- > get_indNewsItemTitle')
    return scrapy.Selector(text=itemtext).xpath('//span[@class="title"]/a/@title').extract_first()



 
  def get_indNewsItemTime (self, iteminfo, url=None, iyear=None, imonth=None, iday=None) :
    self.nowTime= datetime.now(timezone(timedelta(hours=8)))

    indNewsItemHourandMin = scrapy.Selector(text=iteminfo).xpath('//span[@class="newsArchiveLiveTime"]/font/text()').extract_first().strip()[-5:].split(':')
    indNewsItemTime= datetime( self.nowTime.year,
                              self.nowTime.month,
                              self.nowTime.day,
                              int(indNewsItemHourandMin[0]),
                              int(indNewsItemHourandMin[1]),
                              0,
                              tzinfo=timezone(timedelta(hours=8)))

    return indNewsItemTime 

  #def get_numOfYieldRequestLimit (self) :
  #   return self.numOfYieldRequestLimit
 
  #def get_dopagination (self, response) :
  #  print (' rthklatestnewsparser : ---- > get_dopagination')
  #  return self.dopagination

  #def get_newPageURL (self, response) :
  #  print (' rthklatestnewsparser : ---- > get_dopagination')

 
  #def get_itemParseIt (self) :
  #  print (' rthklatestnewsparser : ---- > get_itemParseIt')
 
  def get_articleContent (self, response) :
    print (' rthklatestnewsparser : ---- > get_articleContent')
    articleParagraphList = response.xpath('//div[@class="itemFullText"]').extract()
    articleContent = ''.join([ x.strip() for x in articleParagraphList])
    if len(articleContent.strip()) < 1 :
      articleContent = response.request.meta['indNewsItemTitle']

    return articleContent
    
 
  def get_parseImageURL (self, response) :
    print (' rthklatestnewsparser : ---- > get_parseImageURL')
    parseImageURL = response.xpath('//meta[@property="og:image"]/@content').extract_first()
    if parseImageURL is not None and len(parseImageURL) == 0 :
      parseImageURL=None

    return parseImageURL 












################## crhk latestnews  
class CrhkLatestNewsParser(GongGenericSource) :
  base_url = 'http://www.881903.com/Page/ZH-TW/'
  #log_main_jpeg = False
  #log_main_html = False
  #log_item_jpeg = False
  #log_item_html = False
  #self.itemParseIt = False
  #self.endpointexecute = 'execute'
  numOfYieldRequestLimit = 20
  dopagination = True
  #self.splash_args 
  #self.splash_args_item 



  #def get_endpoint(self) :
  #  print (' GongGenericSource : ---- > get_endpoint')
  #  return self.endpointexecute

  def get_newsItemList (self, resp=None, info=None) :
    print (' crhklatestnewsparser : ---- > get_newsitemlist')
    newsItemList = resp.xpath('//div[@class="newsAboutArticleRow"]').extract()
    return newsItemList


  def get_indNewsItemURL (self, itemtext, base_url=None) :
    print (' crhklatestnewsparser : ---- > get_indNewsItemURL')
    return self.base_url + (scrapy.Selector(text=itemtext).xpath('//span[@class="newsAboutArticleLeft"]/a/@href').extract_first()  )


  def get_indNewsItemTitle (self, itemtext) :
    print (' crhklatestnewsparser : ---- > get_indNewsItemTitle')
    return scrapy.Selector(text=itemtext).xpath('//span[@class="newsAboutArticleLeft"]/a/text()').extract_first()


 
  def get_indNewsItemTime (self, iteminfo, url=None, iyear=None, imonth=None, iday=None) :
    self.nowTime= datetime.now(timezone(timedelta(hours=8)))

    indNewsItemHourandMin = scrapy.Selector(text=iteminfo).xpath('//span[@class="newsAboutArticleRight"]/span[@class="newsAboutArticleDate"]/text()').extract_first().strip().split(':')

    indNewsItemTime= datetime( self.nowTime.year,
                              self.nowTime.month,
                              self.nowTime.day,
                              int(indNewsItemHourandMin[0]),
                              int(indNewsItemHourandMin[1]),
                              0,
                              tzinfo=timezone(timedelta(hours=8)))

    return indNewsItemTime 

  def get_havenextpage (self, response) :
    print (' crhklatestnewsparser : ---- > get_havenextpage')
    if len(response.xpath('//div[@class="newsPage"]//table').extract() ) > 0 :
      return True
    else :
      return False




  #def get_numOfYieldRequestLimit (self) :
  #   return self.numOfYieldRequestLimit
 
  #def get_dopagination (self, response) :
  #  print (' crhklatestnewsparser : ---- > get_dopagination')
  #  return self.dopagination

  def get_newPageURL (self, response) :
    print (' crhklatestnewsparser : ---- > get_newPageURL')
    if 'paginationNum' in response.request.meta :
      paginationNum= response.request.meta['paginationNum']
    else  :
      paginationNum= 1
    strNextPaginationNum = 'page=' + str(paginationNum+1)
    xpathSelectString='//div[@class="newsPage"]//table//td/a[contains(@href, "%s")]'%strNextPaginationNum
    nextPageHTML = response.xpath(xpathSelectString).extract_first()
    newPageURL = self.base_url + scrapy.Selector(text=nextPageHTML).xpath('//a/@href').extract_first()
    return newPageURL
 
  #def get_itemParseIt (self) :
  #  print (' crhklatestnewsparser : ---- > get_itemParseIt')
 
  def get_articleContent (self, response) :
    print (' crhklatestnewsparser : ---- > get_articleContent')
    articleParagraphList = response.xpath('//div[@class="newsTextContent2"]/p').extract()
    articleContent = '\u3002'.join(articleParagraphList)

    if len(articleContent.strip()) < 1 :
      articleContent = response.request.meta['indNewsItemTitle']

    return articleContent
    
 
  def get_parseImageURL (self, response) :
    print (' crhklatestnewsparser : ---- > get_parseImageURL')
    parseImageURL = response.xpath('//div[@id="newsImage"]/div[@id="middleImageBox"]//img/@src').extract_first()
    if parseImageURL is not None and len(parseImageURL) == 0 :
      parseImageURL=None

    return parseImageURL 







################## hkej latestnews  
class HkejLatestNewsParser(GongGenericSource) :
  base_url = 'http://www2.hkej.com'
  #www2.hkej.com/instantnews?date=YYYY-MM-DD&page=1
  #log_main_jpeg = False
  #log_main_html = False
  #log_item_jpeg = False
  #log_item_html = False
  #self.itemParseIt = False
  #self.endpointexecute = 'execute'
  numOfYieldRequestLimit = 30
  dopagination = True
  #self.splash_args 
  #self.splash_args_item 



  #def get_endpoint(self) :
  #  print (' GongGenericSource : ---- > get_endpoint')
  #  return self.endpointexecute

  def get_newsItemList (self, resp=None, info=None) :
    print (' hkejlatestnewsparser : ---- > get_newsitemlist')
    newsItemList = resp.xpath('//div[@class="hkej_toc_listingAll_news2_2014"]').extract()
    return newsItemList


  def get_indNewsItemURL (self, itemtext, base_url=None) :
    print (' hkejlatestnewsparser : ---- > get_indNewsItemURL')
    return self.base_url + (scrapy.Selector(text=itemtext).xpath('//a/@href').extract_first()  )


  def get_indNewsItemTitle (self, itemtext) :
    print (' hkejlatestnewsparser : ---- > get_indNewsItemTitle')
    return scrapy.Selector(text=itemtext).xpath('//h3//text()').extract_first()


 
  def get_indNewsItemTime (self, iteminfo, url=None, iyear=None, imonth=None, iday=None) :
    self.nowTime= datetime.now(timezone(timedelta(hours=8)))

    indNewsItemHourandMin = scrapy.Selector(text=iteminfo).xpath('//span[@class="hkej_toc_top2_timeStamp_2014"]/text()').extract_first().strip().split(':')

    indNewsItemTime= datetime( self.nowTime.year,
                              self.nowTime.month,
                              self.nowTime.day,
                              int(indNewsItemHourandMin[0]),
                              int(indNewsItemHourandMin[1]),
                              0,
                              tzinfo=timezone(timedelta(hours=8)))

    return indNewsItemTime 

  def get_havenextpage (self, response) :
    print (' hkejlatestnewsparser : ---- > get_havenextpage')
    if 'page' in response.url :
      pageNumber = response.url.rsplit('=', maxsplit=1)[1]
    else :
      pageNumber = '1'
    listPageNumber = response.xpath('//div[@class="paging-wrapper"]//a').extract() 
    lastPageNumber = len(listPageNumber)
    if (int(pageNumber)+1) <= lastPageNumber :
      return True
    else :
      return False




  #def get_numOfYieldRequestLimit (self) :
  #   return self.numOfYieldRequestLimit
 
  #def get_dopagination (self, response) :
  #  print (' crhklatestnewsparser : ---- > get_dopagination')
  #  return self.dopagination

  def get_newPageURL (self, response) :
    print (' hkejlatestnewsparser : ---- > get_newPageURL')
    if 'page' in response.url :
      pageNumber = response.url.rsplit('=', maxsplit=1)[1]
    else :
      pageNumber = '1'
    newPageURL = response.url.rsplit('=', maxsplit=1)[0] + '='  + str(int(pageNumber) +1)
    return newPageURL
 
  #def get_itemParseIt (self) :
  #  print (' hkejlatestnewsparser : ---- > get_itemParseIt')
 
  def get_articleContent (self, response) :
    print (' hkejlatestnewsparser : ---- > get_articleContent')
    articleParagraphList = response.xpath('//div[@id="article-content"]/p').extract()
    articleContent = ''.join(articleParagraphList)

    if len(articleContent.strip()) < 1 :
      articleContent = response.request.meta['indNewsItemTitle']

    return articleContent
    
 
  def get_parseImageURL (self, response) :
    print (' hkejlatestnewsparser : ---- > get_parseImageURL')
    parseImageURL = response.xpath('//div[@id="article-detail-wrapper"]//img[not(@align)]').extract_first()
    if parseImageURL is not None and len(parseImageURL) == 0 :
      parseImageURL=None

    return parseImageURL 




################## hkej dailynews  
class HkejDailyNewsParser(GongGenericSource) :
  base_url = 'http://www1.hkej.com'
  #www2.hkej.com/instantnews?date=YYYY-MM-DD&page=1
  #log_main_jpeg = False
  #log_main_html = False
  #log_item_jpeg = False
  #log_item_html = False
  #self.itemParseIt = False
  #self.endpointexecute = 'execute'
  #numOfYieldRequestLimit = 20
  #dopagination = True
  #self.splash_args 
  #self.splash_args_item 



  #def get_endpoint(self) :
  #  print (' GongGenericSource : ---- > get_endpoint')
  #  return self.endpointexecute

  def get_newsItemList (self, resp=None, info=None) :
    print (' hkejlatestnewsparser : ---- > get_newsitemlist')
    newsItemList = resp.xpath('//div[@class="hkej_toc_listingAll_news2_2014"]').extract()
    return newsItemList


  def get_indNewsItemURL (self, itemtext, base_url=None) :
    print (' hkejlatestnewsparser : ---- > get_indNewsItemURL')
    return self.base_url + (scrapy.Selector(text=itemtext).xpath('//a/@href').extract_first()  )


  def get_indNewsItemTitle (self, itemtext) :
    print (' hkejlatestnewsparser : ---- > get_indNewsItemTitle')
    return scrapy.Selector(text=itemtext).xpath('//h3//text()').extract_first()


 
  def get_indNewsItemTime (self, iteminfo, url=None, iyear=None, imonth=None, iday=None) :
    self.nowTime= datetime.now(timezone(timedelta(hours=8)))

    indNewsItemHourandMin = scrapy.Selector(text=iteminfo).xpath('//span[@class="hkej_toc_top2_timeStamp_2014"]/text()').extract_first().strip().split(':')

    indNewsItemTime= datetime( self.nowTime.year,
                              self.nowTime.month,
                              self.nowTime.day,
                              int(indNewsItemHourandMin[0]),
                              int(indNewsItemHourandMin[1]),
                              0,
                              tzinfo=timezone(timedelta(hours=8)))

    return indNewsItemTime 

  def get_havenextpage (self, response) :
    print (' hkejlatestnewsparser : ---- > get_havenextpage')
    if 'page' in response.url :
      pageNumber = response.url.rsplit('=', maxsplit=1)[1]
    else :
      pageNumber = '1'
    listPageNumber = response.xpath('//div[@class="paging-wrapper"]//a').extract() 
    lastPageNumber = len(listPageNumber)
    if (int(pageNumber)+1) <= lastPageNumber :
      return True
    else :
      return False




  #def get_numOfYieldRequestLimit (self) :
  #   return self.numOfYieldRequestLimit
 
  #def get_dopagination (self, response) :
  #  print (' crhklatestnewsparser : ---- > get_dopagination')
  #  return self.dopagination

  def get_newPageURL (self, response) :
    print (' hkejlatestnewsparser : ---- > get_newPageURL')
    if 'page' in response.url :
      pageNumber = response.url.rsplit('=', maxsplit=1)[1]
    else :
      pageNumber = '1'
    newPageURL = response.url.rsplit('=', maxsplit=1)[0] + '='  + str(int(pageNumber) +1)
    return newPageURL
 
  #def get_itemParseIt (self) :
  #  print (' hkejlatestnewsparser : ---- > get_itemParseIt')
 
  def get_articleContent (self, response) :
    print (' hkejlatestnewsparser : ---- > get_articleContent')
    articleParagraphList = response.xpath('//div[@id="article-content"]/p').extract()
    articleContent = ''.join(articleParagraphList)

    if len(articleContent.strip()) < 1 :
      articleContent = response.request.meta['indNewsItemTitle']

    return articleContent
    
 
  def get_parseImageURL (self, response) :
    print (' hkejlatestnewsparser : ---- > get_parseImageURL')
    parseImageURL = response.xpath('//div[@id="article-detail-wrapper"]//img[not(@align)]').extract_first()
    if parseImageURL is not None and len(parseImageURL) == 0 :
      parseImageURL=None

    return parseImageURL 































