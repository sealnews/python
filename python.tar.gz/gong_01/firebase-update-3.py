#! /usr/bin/env python

from __future__ import print_function
import httplib2
import os
from collections import OrderedDict

from datetime import datetime, timedelta, timezone, date
import firebase_admin
from firebase_admin import credentials
from firebase_admin import db
from pprint import pprint
from gong_01_db import GongAllTable

import io
from apiclient import discovery
from apiclient.http import MediaUpload
from apiclient.http import MediaFileUpload
from apiclient.http import MediaIoBaseDownload
from oauth2client import client
from oauth2client import tools
from oauth2client.file import Storage

#here is for tensorflow
import tensorflow as tf
import numpy as np
import os
import time
import datetime
import data_helpers
from text_cnn import TextCNN
from tensorflow.contrib import learn
import csv
from datetime import datetime, timedelta,timezone



import time
import json

try:
    import argparse
    parser = argparse.ArgumentParser(parents=[tools.argparser])
    parser.add_argument('--sheetapi', action='store_true')
    parser.add_argument('--gdriveupload', action='store_true')
    parser.add_argument('--gdrivedownload', action='store_true')
    parser.add_argument('--updatetable', action='store_true')
    parser.add_argument('--arclatestnoofentry', nargs=1, type=int, default=0 )
    parser.add_argument('--createtable', action='store_true')
    flags = parser.parse_args()
    
except ImportError:
    flags = None



ENTRYPERSHEET = 33000
SHEETSTARTNAME = "article"
SEPERATENAME = "ZZ"
VALUE_INPUT_OPTION = 'RAW' 
NOOFENTRYPERPAGE =20
NOOFPAGINATION = 6
EMPTYSTRINGVALUE = 'EMPTYSTRINGVALUE'
BATCHUPDATESIZE=5500

CHECKPOINT_DIR = './runs/1503856968/checkpoints'

cred = credentials.Certificate('/media/sf_xubuntu-01-share/tensorflowOrgExamplePython/firebase/friendlychat-d1a66-firebase-adminsdk-eq7ke-c3ae44c287.json' )
default_app = firebase_admin.initialize_app(cred, {
        'databaseURL' : 'https://friendlychat-d1a66.firebaseio.com',
   })

gong=GongAllTable('gong.db')
session=gong.init_all_table()
nowTime= datetime.now(timezone(timedelta(hours=8)))

SCOPES = 'https://www.googleapis.com/auth/spreadsheets'
CLIENT_SECRET_FILE = 'client_secret.json'
APPLICATION_NAME = 'FriendlyCharPythonUpdate'

def get_credentials():
    """Gets valid user credentials from storage.

    If nothing has been stored, or if the stored credentials are invalid,
    the OAuth2 flow is completed to obtain the new credentials.

    Returns:
        Credentials, the obtained credential.
    """
    credential_dir = os.path.join('/media', 'sf_xubuntu-01-share/tensorflowOrgExamplePython/scrapy-tutorial/gong_01/credentials')
    if not os.path.exists(credential_dir):
        os.makedirs(credential_dir)
    credential_path = os.path.join(credential_dir,
    #                               'client_secret.json')
                                   'sheets.googleapis.com-python-quickstart.json')

    #home_dir = os.path.expanduser('~')
    #credential_dir = os.path.join(home_dir, '.credentials')
    #if not os.path.exists(credential_dir):
    #    os.makedirs(credential_dir)
    #credential_path = os.path.join(credential_dir,
    #                               'sheets.googleapis.com-python-quickstart.json')


    print ('credential_path 1 = ', credential_path)
    store = Storage(credential_path)
    print ('credential_path 2 = ', credential_path)
    credentials = store.get()
    print ('credential_path 3 = ', credential_path)

    if not credentials or credentials.invalid:
        print ('credential_path 4 = ', credential_path)
        flow = client.flow_from_clientsecrets(CLIENT_SECRET_FILE, SCOPES)
        print ('credential_path 5 = ', credential_path)
        flow.user_agent = APPLICATION_NAME

        #if flags:
        credentials = tools.run_flow(flow, store, flags)
        #else: # Needed only for compatibility with Python 2.6
        #    credentials = tools.run(flow, store)

        print('Storing credentials to ' + credential_path)

    return credentials



def get_credentials_gdrive ():
    """Gets valid user credentials from storage.

    If nothing has been stored, or if the stored credentials are invalid,
    the OAuth2 flow is completed to obtain the new credentials.

    Returns:
        Credentials, the obtained credential.
    """
    SCOPES = 'https://www.googleapis.com/auth/drive'
    CLIENT_SECRET_FILE = 'client_secret.json'
    APPLICATION_NAME = 'FriendlyCharPythonUpdate_GDRIVE'

    credential_dir = os.path.join('/media', 'sf_xubuntu-01-share/tensorflowOrgExamplePython/scrapy-tutorial/gong_01/credentials')
    if not os.path.exists(credential_dir):
        os.makedirs(credential_dir)
    credential_path = os.path.join(credential_dir,
    #                               'client_secret.json')
                                   'gdrive.googleapis.com-python-quickstart.json')

    #home_dir = os.path.expanduser('~')
    #credential_dir = os.path.join(home_dir, '.credentials')
    #if not os.path.exists(credential_dir):
    #    os.makedirs(credential_dir)
    #credential_path = os.path.join(credential_dir,
    #                               'sheets.googleapis.com-python-quickstart.json')


    print ('credential_path 1 = ', credential_path)
    store = Storage(credential_path)
    print ('credential_path 2 = ', credential_path)
    credentials = store.get()
    print ('credential_path 3 = ', credential_path)

    if not credentials or credentials.invalid:
        print ('credential_path 4 = ', credential_path)
        flow = client.flow_from_clientsecrets(CLIENT_SECRET_FILE, SCOPES)
        print ('credential_path 5 = ', credential_path)
        flow.user_agent = APPLICATION_NAME

        #if flags:
        credentials = tools.run_flow(flow, store, flags)
        #else: # Needed only for compatibility with Python 2.6
        #    credentials = tools.run(flow, store)

        print('Storing credentials to ' + credential_path)

    return credentials








def updatecategorytable () :
  categoryresult = gong.getCategoryDict()
  noofentry = len(categoryresult)
  categorytable_ref = db.reference().child('categorytable')
  result = categorytable_ref.get()
  if result is None :
    #create the table
    print (' noofentry = ', noofentry)
    categorytable_ref.set({ 'noofentry' : noofentry , 'lastupdatetime' : int(nowTime.timestamp())})
    categorytableNoofEntry_ref = categorytable_ref.child('noofentry')
    categorytableLastUpdate_ref = categorytable_ref.child('lastupdatetime')
    categorytableEntry_ref = categorytable_ref.child('entry')
    for entry in categoryresult :
      print (' entry= ' , entry)
      categorytableEntry_ref.child(str(entry.id)).set({ 'id' : entry.id , 'chi_name' : entry.chi_name , 'eng_name' : entry.eng_name } )
 
  else :
    categorytableRntry_ref = categorytable_ref.child('entry')
    categorytableNoofEntry_ref = categorytable_ref.child('noofentry')
    categorytableLastUpdate_ref = categorytable_ref.child('lastupdatetime')
    if ( noofentry != categorytableNoofEntry_ref.get() ) or ( int(nowTime.timestamp())  < categorytableLastUpdate_ref.get() ) :
      print(' need to update ')
      categorytable_ref.update({ 'noofentry' : noofentry , 'lastupdatetime' : int(nowTime.timestamp())})
      categorytableEntry_ref = categorytable_ref.child('entry')
      for entry in categoryresult :
        print (' entry= ' , entry)
        if categorytable_ref.child('entry'+'/'+str(entry.id)).get() is None :
          categorytableEntry_ref.child(str(entry.id)).set({ 'id' : entry.id , 'chi_name' : entry.chi_name , 'eng_name' : entry.eng_name } )
        else :
          categorytableEntry_ref.child(str(entry.id)).update({ 'id' : entry.id , 'chi_name' : entry.chi_name , 'eng_name' : entry.eng_name } )

    else :
      print(' nothing to update in categorytable ')
  


def updatedomaintable () :
  domainresult = gong.getDomainDict()
  noofentry = len(domainresult)
  domaintable_ref = db.reference().child('domaintable')
  result = domaintable_ref.get()
  if result is None :
    #create the table
    print (' noofentry = ', noofentry)
    domaintable_ref.set({ 'noofentry' : noofentry , 'lastupdatetime' : int(nowTime.timestamp())})
    domaintableNoofEntry_ref = domaintable_ref.child('noofentry')
    domaintableLastUpdate_ref = domaintable_ref.child('lastupdatetime')
    domaintableEntry_ref = domaintable_ref.child('entry')
    for entry in domainresult :
      print (' entry= ' , entry)
      domaintableEntry_ref.child(str(entry.id)).set({ 'id' : entry.id , 'baseurl' : entry.baseurl , 'chi_name' : entry.chi_name , 'eng_name' : entry.eng_name } )
  else :
    domaintableRntry_ref = domaintable_ref.child('entry')
    domaintableNoofEntry_ref = domaintable_ref.child('noofentry')
    domaintableLastUpdate_ref = domaintable_ref.child('lastupdatetime')
    if ( noofentry != domaintableNoofEntry_ref.get() ) or ( int(nowTime.timestamp())  < domaintableLastUpdate_ref.get() ) :
      print(' need to update ')
      domaintable_ref.update({ 'noofentry' : noofentry , 'lastupdatetime' : int(nowTime.timestamp())})
      domaintableEntry_ref = domaintable_ref.child('entry')
      for entry in domainresult :
        print (' entry= ' , entry)
        if domaintable_ref.child('entry'+'/'+str(entry.id)).get() is None :
          domaintableEntry_ref.child(str(entry.id)).set({ 'id' : entry.id , 'baseurl' : entry.baseurl , 'chi_name' : entry.chi_name , 'eng_name' : entry.eng_name } )
        else :
          domaintableEntry_ref.child(str(entry.id)).update({ 'id' : entry.id ,  'baseurl' : entry.baseurl , 'chi_name' : entry.chi_name , 'eng_name' : entry.eng_name } )
    else :
      print(' nothing to update in domaintable ')
  

def updatefirstsubdomaintable () :
  firstsubdomainresult = gong.getFirstSubDomainDict()
  noofentry = len(firstsubdomainresult)
  firstsubdomaintable_ref = db.reference().child('firstsubdomaintable')
  result = firstsubdomaintable_ref.get()
  if result is None :
    #create the table
    print (' noofentry = ', noofentry)
    firstsubdomaintable_ref.set({ 'noofentry' : noofentry , 'lastupdatetime' : int(nowTime.timestamp())})
    firstsubdomaintableNoofEntry_ref = firstsubdomaintable_ref.child('noofentry')
    firstsubdomaintableLastUpdate_ref = firstsubdomaintable_ref.child('lastupdatetime')
    firstsubdomaintableEntry_ref = firstsubdomaintable_ref.child('entry')
    for entry in firstsubdomainresult :
      print (' entry= ' , entry)
      firstsubdomaintableEntry_ref.child(str(entry.id)).set({ 'id' : entry.id ,
            'domaintable_id' : entry.domaintable_id, 
            'categorytable_id' : entry.categorytable_id, 
            'latestupdatetime' : entry.latestupdatetime.replace(tzinfo=timezone(timedelta(hours=8))).timestamp(), 
            'latestupdateurl' : entry.latestupdateurl ,
            'sourceiconurl' : entry.sourceiconurl 
      } )
  else :
    firstsubdomaintableRntry_ref = firstsubdomaintable_ref.child('entry')
    firstsubdomaintableNoofEntry_ref = firstsubdomaintable_ref.child('noofentry')
    firstsubdomaintableLastUpdate_ref = firstsubdomaintable_ref.child('lastupdatetime')
    if ( noofentry != firstsubdomaintableNoofEntry_ref.get() ) or ( int(nowTime.timestamp())  < firstsubdomaintableLastUpdate_ref.get() ) :
      print(' need to update ')
      firstsubdomaintable_ref.update({ 'noofentry' : noofentry , 'lastupdatetime' : int(nowTime.timestamp())})
      firstsubdomaintableEntry_ref = firstsubdomaintable_ref.child('entry')
      for entry in firstsubdomainresult :
        print (' entry= ' , entry)
        if firstsubdomaintable_ref.child('entry'+'/'+str(entry.id)).get() is None :
          firstsubdomaintableEntry_ref.child(str(entry.id)).set({ 'id' : entry.id ,
            'domaintable_id' : entry.domaintable_id, 
            'categorytable_id' : entry.categorytable_id, 
            'latestupdatetime' : entry.latestupdatetime.replace(tzinfo=timezone(timedelta(hours=8))).timestamp(), 
            'latestupdateurl' : entry.latestupdateurl ,
            'sourceiconurl' : entry.sourceiconurl 
          } )
        else :
          firstsubdomaintableEntry_ref.child(str(entry.id)).update({ 'id' : entry.id ,
            'domaintable_id' : entry.domaintable_id, 
            'categorytable_id' : entry.categorytable_id, 
            'latestupdatetime' : entry.latestupdatetime.replace(tzinfo=timezone(timedelta(hours=8))).timestamp(), 
            'latestupdateurl' : entry.latestupdateurl ,
            'sourceiconurl' : entry.sourceiconurl 
          } )

    else :
      print(' nothing to update in firstsubdomaintable ')
  


def updatearticletable () :
  articleresult = gong.getArticleDict()
  noofentry = len(articleresult)
  articletable_ref = db.reference().child('articletable')
  result = articletable_ref.get()
  if result is None :
    #create the table
    print (' noofentry = ', noofentry)
    articletable_ref.set({ 'noofentry' : noofentry , 'lastupdatetime' : int(nowTime.timestamp())})
    articletableNoofEntry_ref = articletable_ref.child('noofentry')
    articletableLastUpdate_ref = articletable_ref.child('lastupdatetime')
    articletableEntry_ref = articletable_ref.child('entry')
    #testcount=0
    for entry in articleresult :
      #testcount += 1
      #if testcount >10 :
      #  break
      #print (' entry= ' , entry)
      articletableEntry_ref.child(str(entry.id)).set({ 'id' : entry.id ,
            'firstsubdomaintable_id' : entry.firstsubdomaintable_id, 
            'finalurl' : entry.finalurl, 
            'timestampondoc' : entry.timestampondoc.replace(tzinfo=timezone(timedelta(hours=8))).timestamp(), 
            'timestamponretrieve' : entry.timestamponretrieve.replace(tzinfo=timezone(timedelta(hours=8))).timestamp(), 
            'title' : entry.title ,
            'content' : entry.content ,
            'imageurl' : entry.imageurl if ((entry.imageurl is not None) and ( len(entry.imageurl) > 0) ) else EMPTYSTRINGVALUE ,
            'similaritieslist' : entry.similaritieslist if (( entry.similaritieslist is not None) and ( len(entry.similaritieslist) > 0 ) ) else EMPTYSTRINGVALUE,
            'similaritiescount' : entry.similaritiescount if (entry.similaritiescount is not None) else 0 
      } )
  else :
    articletableRntry_ref = articletable_ref.child('entry')
    articletableNoofEntry_ref = articletable_ref.child('noofentry')
    articletableLastUpdate_ref = articletable_ref.child('lastupdatetime')
    if ( noofentry > articletableNoofEntry_ref.get() ) :
      #print(' need to update ')
      articletable_ref.update({ 'noofentry' : noofentry , 'lastupdatetime' : int(nowTime.timestamp())})
      articletableEntry_ref = articletable_ref.child('entry')
      for entry in articleresult :
        #print (' entry= ' , entry)
        if articletable_ref.child('entry'+'/'+str(entry.id)).get() is None :
          #new entry
          articletableEntry_ref.child(str(entry.id)).set({ 'id' : entry.id ,
            'firstsubdomaintable_id' : entry.firstsubdomaintable_id, 
            'finalurl' : entry.finalurl, 
            'timestampondoc' : entry.timestampondoc.replace(tzinfo=timezone(timedelta(hours=8))).timestamp(), 
            'timestamponretrieve' : entry.timestamponretrieve.replace(tzinfo=timezone(timedelta(hours=8))).timestamp(), 
            'title' : entry.title ,
            'content' : entry.content ,
            'imageurl' : entry.imageurl if ((entry.imageurl is not None) and ( len(entry.imageurl) > 0) ) else EMPTYSTRINGVALUE ,
            'similaritieslist' : entry.similaritieslist if (( entry.similaritieslist is not None) and ( len(entry.similaritieslist) > 0 ) ) else EMPTYSTRINGVALUE,
            'similaritiescount' : entry.similaritiescount if (entry.similaritiescount is not None) else 0 
          } )
        elif entry.updatetofirebase == 1  :
          #update entry
          articletableEntry_ref.child(str(entry.id)).update({ 'id' : entry.id ,
            'firstsubdomaintable_id' : entry.firstsubdomaintable_id, 
            'finalurl' : entry.finalurl, 
            'timestampondoc' : entry.timestampondoc.replace(tzinfo=timezone(timedelta(hours=8))).timestamp(), 
            'timestamponretrieve' : entry.timestamponretrieve.replace(tzinfo=timezone(timedelta(hours=8))).timestamp(), 
            'title' : entry.title ,
            'content' : entry.content ,
            'imageurl' : entry.imageurl if ((entry.imageurl is not None) and ( len(entry.imageurl) > 0) ) else EMPTYSTRINGVALUE ,
            'similaritieslist' : entry.similaritieslist if (( entry.similaritieslist is not None) and ( len(entry.similaritieslist) > 0 ) ) else EMPTYSTRINGVALUE,
            'similaritiescount' : entry.similaritiescount if (entry.similaritiescount is not None) else 0 
          } )

    else :
      print(' nothing to update in articletable ')
  


def updatelatestnewstable () :
  articleresult = gong.getArticleDict()
  firstsubdomainresult = gong.getFirstSubDomainDict()
  noofentry = 0
  latestnewstable_ref = db.reference().child('latestnewstable')
  result = latestnewstable_ref.get()
  if result is None :
    
    #create the table
    print (' noofentry = ', noofentry)
    latestnewstable_ref.update({ 'lastupdatetime' : int(nowTime.timestamp())})
    latestnewstableLastUpdate_ref = latestnewstable_ref.child('lastupdatetime')
    latestnewstableEntry_ref = latestnewstable_ref.child('entry')
    #testcount=0
    print (' articleresult length = ', len(articleresult))
    articleresult.reverse()
    testcount =0
    for entry in articleresult :
      testcount += 1
      if testcount >200 :
        break
      #print (' entry= ' , entry)
      print ('--------- testcount= ' , testcount)
      print ('--------- categorytable_id= ' , firstsubdomainresult[entry.firstsubdomaintable_id - 1].categorytable_id  )
      print ('--------- entry.firstsubdomaintable_id= ' , entry.firstsubdomaintable_id  )
      print ('--------- entry.id= ' , entry.id  )
      if (firstsubdomainresult[entry.firstsubdomaintable_id - 1].categorytable_id == 3) :
        noofentry += 1
        print (' ========================= noofentry = ', noofentry)
        latestnewstableNoofEntry_ref = latestnewstable_ref.child('noofentry')
        latestnewstable_ref.update({ 'noofentry' : noofentry })
        latestnewsdatestamp = entry.timestampondoc.replace(hour=0,minute=0,second=0,microsecond=0).timestamp()  
        latestnewstableEntry_ref.child(str(int(latestnewsdatestamp))) \
          .child("+".join([str(int(entry.timestampondoc.replace(tzinfo=timezone(timedelta(hours=8))).timestamp())), entry.id]))\
          .update({ 'id' : entry.id ,
            'firstsubdomaintable_id' : entry.firstsubdomaintable_id, 
            'finalurl' : entry.finalurl, 
            'title' : entry.title ,
            'imageurl' : entry.imageurl if ((entry.imageurl is not None) and ( len(entry.imageurl) > 0) ) else EMPTYSTRINGVALUE ,
            'similaritiescount' : entry.similaritiescount if (entry.similaritiescount is not None) else 0 
          } )
        if entry.similaritiescount > 0 :
          for similarentryid in entry.similaritieslist.strip().split() :
            similarentry = gong.getIndArticleEntry(similarentryid)
            latestnewstableEntry_ref.child(str(int(latestnewsdatestamp))) \
              .child(".".join([str(int(entry.timestampondoc.replace(tzinfo=timezone(timedelta(hours=8))).timestamp())), entry.id ]))\
              .child("entry").child(".".join([str(int(similarentry.timestampondoc.replace(tzinfo=timezone(timedelta(hours=8))).timestamp())), similarentry.id]))\
              .update({ 'id' : similarentry.id ,
                     'firstsubdomaintable_id' : similarentry.firstsubdomaintable_id, 
                     'finalurl' : similarentry.finalurl, 
                     'title' : similarentry.title ,
                     'imageurl' : similarentry.imageurl if ((similarentry.imageurl is not None) and ( len(similarentry.imageurl) > 0) ) else EMPTYSTRINGVALUE ,
                } )




def updatelatestnewstableTwo () :
  articleresult = gong.getArticleDict()
  firstsubdomainresult = gong.getFirstSubDomainDict()
  noofentry = 0
  latestnewstable_ref = db.reference().child('latestnewstable')
  result = latestnewstable_ref.get()
  if result is not None :
    
    #create the table
    print (' noofentry = ', noofentry)
    #testcount=0
    print (' articleresult length = ', len(articleresult))
    articleresult.reverse()
    testcount =0
    noofentryperpage =20
    noofpagination = 6
    startpagerange = 1
    stoppagerange = noofentryperpage
    for entry in articleresult :
      testcount += 1
      if testcount >200 :
        break
      #print (' entry= ' , entry)
      print ('--------- testcount= ' , testcount)
      print ('--------- categorytable_id= ' , firstsubdomainresult[entry.firstsubdomaintable_id - 1].categorytable_id  )
      print ('--------- entry.firstsubdomaintable_id= ' , entry.firstsubdomaintable_id  )
      print ('--------- entry.id= ' , entry.id  )
      if (firstsubdomainresult[entry.firstsubdomaintable_id - 1].categorytable_id == 3) :
        noofentry += 1
        print (' ========================= noofentry = ', noofentry)




        #paginationumber start from 0
        latestnewspagination_ref = latestnewstable_ref.child("pagination")
        paginationnumber = int((noofentry-1) / noofentryperpage) 
        sectionname = str(int(startpagerange + (paginationnumber * noofentryperpage)) ) + \
                      "to" + \
                      str(int(stoppagerange + (paginationnumber * noofentryperpage)) )
        latestnewspaginationsec_ref = latestnewspagination_ref.child(sectionname)
        latestnewspaginationsec_ref.update({ "noofentry" : ((noofentry-1)  % noofentryperpage ) +1  })
        latestnewspaginationsec_ref.update({ 'lastupdatetime' : int(nowTime.timestamp())})
        paginationsecentry_ref = latestnewspaginationsec_ref.child("entry")
        paginationsecentry_ref.child('Z'.join([str(int(entry.timestampondoc.replace(tzinfo=timezone(timedelta(hours=8))).timestamp())), str(entry.id).zfill(10) ]))\
          .update({ 'id' : entry.id ,
            'firstsubdomaintable_id' : entry.firstsubdomaintable_id, 
            'finalurl' : entry.finalurl, 
            'title' : entry.title ,
            'imageurl' : entry.imageurl if ((entry.imageurl is not None) and ( len(entry.imageurl) > 0) ) else EMPTYSTRINGVALUE ,
            'similaritiescount' : entry.similaritiescount if (entry.similaritiescount is not None) else 0 
          } )
        if entry.similaritiescount > 0 :
          for similarentryid in entry.similaritieslist.strip().split() :
            similarentry = gong.getIndArticleEntry(similarentryid)
            paginationsecentry_ref.child('Z'.join([str(int(entry.timestampondoc.replace(tzinfo=timezone(timedelta(hours=8))).timestamp())), str(entry.id).zfill(10) ]))\
              .child("entry").child('Z'.join([str(int(similarentry.timestampondoc.replace(tzinfo=timezone(timedelta(hours=8))).timestamp())), str(similarentry.id).zfill(10) ]))\
              .update({ 'id' : similarentry.id ,
                     'firstsubdomaintable_id' : similarentry.firstsubdomaintable_id, 
                     'finalurl' : similarentry.finalurl, 
                     'title' : similarentry.title ,
                     'imageurl' : similarentry.imageurl if ((similarentry.imageurl is not None) and ( len(similarentry.imageurl) > 0) ) else EMPTYSTRINGVALUE ,
                } )




        #archive  0
        latestnewsarchive_ref = latestnewstable_ref.child("archive")
        latestnewsarchive_ref.update({ 'lastupdatetime' : int(nowTime.timestamp())})
        latestnewsarchive_ref.update({ 'noofentry' : noofentry })


        latestnewsarchiveentry_ref = latestnewsarchive_ref.child("entry")
        latestnewsarchiveentry_ref.child('Z'.join([str(int(entry.timestampondoc.replace(tzinfo=timezone(timedelta(hours=8))).timestamp())), str(entry.id).zfill(10) ]))\
          .update({ 
            'firstsubdomaintable_id' : entry.firstsubdomaintable_id, 
            'title' : entry.title ,
            'similaritiescount' : entry.similaritiescount if (entry.similaritiescount is not None) else 0 
          } )
        if entry.similaritiescount > 0 :
          for similarentryid in entry.similaritieslist.strip().split() :
            similarentry = gong.getIndArticleEntry(similarentryid)
            latestnewsarchiveentry_ref.child('Z'.join([str(int(entry.timestampondoc.replace(tzinfo=timezone(timedelta(hours=8))).timestamp())), str(entry.id).zfill(10) ]))\
              .child("entry").child('Z'.join([str(int(similarentry.timestampondoc.replace(tzinfo=timezone(timedelta(hours=8))).timestamp())), str(similarentry.id).zfill(10) ]))\
              .update({ 
                     'firstsubdomaintable_id' : similarentry.firstsubdomaintable_id, 
                     'title' : similarentry.title ,
                } )



def updatearticlelookuptable () :
  articlelookuptable_ref = db.reference().child('articlelookuptable')
  #result = domaintable_ref.get()
  result = 'hello'
  #create the table
  articlelookuptable_ref.update({ 'noofentry' : 0 , 'lastupdatetime' : int(nowTime.timestamp())})


#session.query(hello).filter(articletable.id.in_([ f.id for f in friends ] ).all

def siftOlderArticle( fulllistarticle , rangeTime=None) :
  siftResultList = [] 
  if rangeTime is None:
    #just sift thur the list for now
    for index, indArticle in enumerate(fulllistarticle) :
      if ( hasattr(indArticle, 'sithout')) or  \
         ( indArticle.similaritiescount is None) or \
         ( indArticle.similaritiescount == 0) or \
         ( index+1 == len(fulllistarticle) ) :
        #print ("does not need to sift indArticle.id=",indArticle.id)
        continue
              
      #print (" need to sift indArticle.id=",indArticle.id, 
      #      ",similaritiescount=", indArticle.similaritiescount)
      for checkArticle in fulllistarticle[index+1:] :
        if str(checkArticle.id) in indArticle.similaritieslist.strip().split() :
          checkArticle.sithout = True      
          
    for indArticle in fulllistarticle :
      if hasattr(indArticle, 'sithout') :
        continue
      siftResultList.append(indArticle)

    print ("len(siftresultlist)=",len(siftResultList),
           ", len(fulllistarticle)=", len(fulllistarticle))
    return siftResultList




def downloadgongdbAtGDrive () :
    credentials = get_credentials_gdrive()
    http = credentials.authorize(httplib2.Http())
    service = discovery.build('drive', 'v3', http=http)
    gongdb_fileid = '0B94TCc20s2zmUGx1WkFGbnN6TWc'
    request =  service.files().get_media(fileId=gongdb_fileid)
    #fh = io.BytesIO()
    fh = io.FileIO('gong.db','wb')
    downloader = MediaIoBaseDownload ( fh, request)
    done = False
    while done is False :
       status, done = downloader.next_chunk()
       print ("Download %d%%." % int(status.progress() * 100))


def updategongdbAtGDrive () :
    credentials = get_credentials_gdrive()
    http = credentials.authorize(httplib2.Http())
    service = discovery.build('drive', 'v3', http=http)
    file_metadata = {'name': 'gong.db'}
    media = MediaFileUpload('gong.db',
                        mimetype='application/x-sqlite3')
    gongdb_fileid = '0B94TCc20s2zmUGx1WkFGbnN6TWc'
    file =  service.files().update(fileId=gongdb_fileid,
                                    body=file_metadata,
                                    media_body=media,
                                    fields='id').execute()
    print ('File ID: %s' % file.get('id'))

def creategongdbAtGDrive () :
    credentials = get_credentials_gdrive()
    http = credentials.authorize(httplib2.Http())
    service = discovery.build('drive', 'v3', http=http)
    file_metadata = {'name': 'gong.db'}
    media = MediaFileUpload('gong.db',
                        mimetype='application/x-sqlite3')
    file =  service.files().create(body=file_metadata,
                                    media_body=media,
                                    fields='id').execute()
    print ('File ID: %s' % file.get('id'))


def listAtGDrive () :
    credentials = get_credentials_gdrive()
    http = credentials.authorize(httplib2.Http())
    service = discovery.build('drive', 'v3', http=http)

    results = service.files().list(
        pageSize=100,fields="nextPageToken, files(id, name)").execute()
    items = results.get('files', [])
    if not items:
        print('No files found.')
    else:
        print('Files:')
        for item in items:
            print('{0} ({1})'.format(item['name'], item['id']))





def getSheetEntries(tableName, archiveName, numToRetrieve ) :
  class ArticleInfo(object):
    pass


  #first get how many 
  table_ref = db.reference().child(tableName)
  tableNoofEntry_ref = table_ref.child(archiveName).child('noofentry')
  tableentry_ref = table_ref.child(archiveName).child('entry')
  noofentry = tableNoofEntry_ref.get()
  remainNumToRetrieve = numToRetrieve

  #total_articlelisttostore = len(articlelisttostore) + noofentry #how many entry will add

  if ( numToRetrieve > 0 ) :
    credentials = get_credentials()
    http = credentials.authorize(httplib2.Http())
    discoveryUrl = ('https://sheets.googleapis.com/$discovery/rest?'
                    'version=v4')
    service = discovery.build('sheets', 'v4', http=http,
                              discoveryServiceUrl=discoveryUrl)

    #first find which sheet should start update  
    startsheetid = 1+ (int(noofentry/ENTRYPERSHEET) * ENTRYPERSHEET) 
    endsheetid = ENTRYPERSHEET + (int(noofentry/ENTRYPERSHEET) * ENTRYPERSHEET) 
    sheetname = str(int(startsheetid)).zfill(10) + SEPERATENAME + str(int(endsheetid)).zfill(10)
    lookupsheetID = tableentry_ref.child(sheetname.strip()).get()
    currententryidPos = noofentry #point to the element has just used
    currentSheetPos = int( currententryidPos % ENTRYPERSHEET) #point to the element is going to use
    updatelistPos =0 #point to the element is going to use
    print ('begin -> startsheetid =',startsheetid,',endsheetid=',
            endsheetid,',sheetname=',sheetname,
            'lookupsheetID=',lookupsheetID,
            'currententryidPos=',currententryidPos,
            'currentSheetPos=',currentSheetPos,
            'updatelistPos=',updatelistPos,
            )
   
    #start the work
    #result = gong.getArticleTableRange(0,4659)
    #result = gong.getArticleTableRange(noofentry)
    #result = articlelisttostore
    resultList = []
    while remainNumToRetrieve > 0 :
      if remainNumToRetrieve <= currentSheetPos :
        #this is last sheet
        read_range_name = 'Sheet1!A' +  \
          str(1 + currentSheetPos - remainNumToRetrieve) + \
          ':H' + \
          str( currentSheetPos )
        result = service.spreadsheets().values().get(
                    spreadsheetId=lookupsheetID, 
                    range=read_range_name
                    ).execute()
        values = result.get('values', [])

        if not values:
          print (" ----> ????? remainNumToRetrieve <= currentSheetPos no data found ???? ")
        else :
          values.reverse() 
          for row in values:
            entry = ArticleInfo()
            entry.id = int(row[0])
            entry.firstsubdomaintable_id= int(row[1])
            entry.finalurl= row[2]
            entry.imageurl= row[3]
            entry.similaritiescount= int(row[4])
            entry.timestampondoc= datetime.fromtimestamp(int(row[5])).replace(tzinfo=timezone(timedelta(hours=8)))
            entry.title= row[6]
            entry.entryjsonStr = row[7]
            oneentry = gong.getIndArticleEntry(entry.id)
            entry.similaritieslist = oneentry.similaritieslist
            resultList.append(entry)
        print ( "remainNumToRetrieve <= currentSheetPos len(resultlist)=",len(resultList))
        break           
      elif (remainNumToRetrieve >= currentSheetPos) :
        read_range_name = 'Sheet1!A' +  \
          str(1) + \
          ':H' + \
          str( currentSheetPos )
        result = service.spreadsheets().values().get(
                    spreadsheetId=lookupsheetID, 
                    range=read_range_name
                    ).execute()
        values = result.get('values', [])

        if not values:
          print (" ----> ????? remainNumToRetrieve > currentSheetPos no data found ???? ")
        else :
          values.reverse() 
          for row in values:
            entry = ArticleInfo()
            entry.id = int(row[0])
            entry.firstsubdomaintable_id= int(row[1])
            entry.finalurl= row[2]
            entry.imageurl= row[3]
            entry.similaritiescount= int(row[4])
            entry.timestampondoc= datetime.fromtimestamp(int(row[5])).replace(tzinfo=timezone(timedelta(hours=8)))
            entry.title= row[6]
            entry.entryjsonStr = row[7]
            oneentry = gong.getIndArticleEntry(entry.id)
            entry.similaritieslist = oneentry.similaritieslist
            resultList.append(entry)
        remainNumToRetrieve -= currentSheetPos
        
        print ( "remainNumToRetrieve <= currentSheetPos len(resultlist)=",len(resultList))
        break           
      else : 
        print ('xxxxxx  ->  else problem remainNumToRetrieve > 0 ')
    return resultList 





   

def updateSheetArchivetable (tableName, archiveName, articlelisttostore) :

  print ("updateSheetArchivetable tableName,=",tableName,
      ",archiveName=",archiveName,
      ",len(articlelisttostore)=", len(articlelisttostore) )
  #first get how many 
  table_ref = db.reference().child(tableName)
  tableNoofEntry_ref = table_ref.child(archiveName).child('noofentry')
  tableentry_ref = table_ref.child(archiveName).child('entry')
  noofentry = tableNoofEntry_ref.get()
  total_articlelisttostore = len(articlelisttostore) + noofentry #how many entry will add
  print ("updateSheetArchivetable total_articlelisttostore=",
     total_articlelisttostore )
  if ( total_articlelisttostore > 0 ) :
    credentials = get_credentials()
    http = credentials.authorize(httplib2.Http())
    discoveryUrl = ('https://sheets.googleapis.com/$discovery/rest?'
                    'version=v4')
    service = discovery.build('sheets', 'v4', http=http,
                              discoveryServiceUrl=discoveryUrl)

    #first find which sheet should start update  
    startsheetid = 1+ (int(noofentry/ENTRYPERSHEET) * ENTRYPERSHEET) 
    endsheetid = ENTRYPERSHEET + (int(noofentry/ENTRYPERSHEET) * ENTRYPERSHEET) 
    sheetname = str(int(startsheetid)).zfill(10) + SEPERATENAME + str(int(endsheetid)).zfill(10)
    lookupsheetID = tableentry_ref.child(sheetname.strip()).get()
    currententryidPos = noofentry #point to the element has just used
    currentSheetPos = int(1+ (currententryidPos % ENTRYPERSHEET)) #point to the element is going to use
    updatelistPos =0 #point to the element is going to use
    print ('begin -> startsheetid =',startsheetid,',endsheetid=',
            endsheetid,',sheetname=',sheetname,
            'lookupsheetID=',lookupsheetID,
            'currententryidPos=',currententryidPos,
            'currentSheetPos=',currentSheetPos,
            'updatelistPos=',updatelistPos,
            )
   
    #start the work
    result = articlelisttostore
    updateList = []
    for entry in result :
      #A1:J1
      entryValue = [ entry.id, entry.firstsubdomaintable_id,
                       entry.finalurl,
                       entry.imageurl if ((entry.imageurl is not None) and ( len(entry.imageurl) > 0) ) else EMPTYSTRINGVALUE ,
                       entry.similaritiescount if (entry.similaritiescount is not None) else 0 ,
                       entry.timestampondoc.replace(tzinfo=timezone(timedelta(hours=8))).timestamp(),
                       entry.title,
                       entry.entryjsonStr if ((entry.entryjsonStr is not None) and (len(entry.entryjsonStr) > 0)) else EMPTYSTRINGVALUE ]
      updateList.append(entryValue)
    
    while currententryidPos < total_articlelisttostore :
      print (" currententryidPos=", currententryidPos,
        ", total_articlelisttostore=" , total_articlelisttostore)
      if (endsheetid  >= total_articlelisttostore ) :
        batchcount =0
        numEntrytoUpdate = total_articlelisttostore - \
          currententryidPos
        while ( numEntrytoUpdate > BATCHUPDATESIZE ) :
          #last sheetID to update
          write_range_name = 'Sheet1!A' +  \
              str(currentSheetPos) + \
              ':H' + \
              str( currentSheetPos + BATCHUPDATESIZE -1) 
          body = { 'values' : updateList[ \
                             updatelistPos: updatelistPos + \
                             BATCHUPDATESIZE ] }
          print ('before append -> ',
            'lookupsheetID=',lookupsheetID,
            'currententryidPos=',currententryidPos,
            'currentSheetPos=',currentSheetPos,
            'currentSheetPos+BATCHUPDATESIZE=',currentSheetPos+BATCHUPDATESIZE,
            'updatelistPos=',updatelistPos,
            'updatelistPos+BATCHUPDATESIZE=',updatelistPos+BATCHUPDATESIZE,
            ',write_range=',write_range_name
            )
   
          result = service.spreadsheets().values().append(
                    spreadsheetId=lookupsheetID, 
                    range=write_range_name,
                    valueInputOption=VALUE_INPUT_OPTION, 
                    body=body).execute()
          print ('endsheetid  >= total_articlelisttostore result=',
                result)
          numEntrytoUpdate -= BATCHUPDATESIZE
          currentSheetPos += BATCHUPDATESIZE
          updatelistPos += BATCHUPDATESIZE
          print ('numEntrytoUpdate=',numEntrytoUpdate,
                 'currentSheetPos=',currentSheetPos,
                 'updatelistPos=',updatelistPos)


        #last sheetID to update
        write_range_name = 'Sheet1!A' +  \
          str(currentSheetPos) + \
          ':H' + \
          str( currentSheetPos + (total_articlelisttostore - \
               currententryidPos ) )  
        body = { 'values' : updateList[ \
                             updatelistPos: updatelistPos + \
                              (total_articlelisttostore - \
                               currententryidPos ) ] }
        result = service.spreadsheets().values().append(
                    spreadsheetId=lookupsheetID, 
                    range=write_range_name,
                    valueInputOption=VALUE_INPUT_OPTION, 
                    body=body).execute()
        print ('endsheetid  >= total_articlelisttostore result=', 
                result)
        break
      elif (total_articlelisttostore > endsheetid) :
        numEntrytoUpdate = ENTRYPERSHEET - currentSheetPos + 1
        currententryidPos += numEntrytoUpdate
        while (numEntrytoUpdate > BATCHUPDATESIZE ):
          write_range_name = 'Sheet1!A' +  \
              str(currentSheetPos) + \
              ':H' + \
              str( currentSheetPos + BATCHUPDATESIZE -1 )
          body = { 'values' : updateList[ \
                             updatelistPos: updatelistPos + \
                              BATCHUPDATESIZE ] }
          result = service.spreadsheets().values().append(
                    spreadsheetId=lookupsheetID,
                    range=write_range_name,
                    valueInputOption=VALUE_INPUT_OPTION,
                    body=body).execute()
          print ('total_articlelisttostore > endsheetid result=',
                result)

          updatelistPos += BATCHUPDATESIZE
          currentSheetPos += BATCHUPDATESIZE
          numEntrytoUpdate -= BATCHUPDATESIZE

          print ('doing -> startsheetid =',startsheetid,',endsheetid=',
            endsheetid,',sheetname=',sheetname,
            'lookupsheetID=',lookupsheetID,
            'currententryidPos=',currententryidPos,
            'currentSheetPos=',currentSheetPos,
            'updatelistPos=',updatelistPos,
            )


        write_range_name = 'Sheet1!A' +  \
          str(currentSheetPos) + \
          ':H' + \
          str( ENTRYPERSHEET )
        body = { 'values' : updateList[ \
                             updatelistPos: updatelistPos + \
                              (ENTRYPERSHEET - \
                               currentSheetPos + 1 ) ] }
        result = service.spreadsheets().values().append(
                    spreadsheetId=lookupsheetID,
                    range=write_range_name,
                    valueInputOption=VALUE_INPUT_OPTION,
                    body=body).execute()
        print ('total_articlelisttostore > endsheetid result=',
                result)
        updatelistPos += ENTRYPERSHEET - currentSheetPos + 1

        currentSheetPos = 1
        startsheetid = int(1+ (int(currententryidPos/ENTRYPERSHEET) * \
                       ENTRYPERSHEET))
        endsheetid = int(ENTRYPERSHEET + \
                       (int(currententryidPos/ENTRYPERSHEET) * \
                         ENTRYPERSHEET) )
        sheetname =  str(startsheetid).zfill(10) + \
                     SEPERATENAME + \
                     str(endsheetid).zfill(10)
        lookupsheetID = tableentry_ref.child(sheetname.strip()).get()
        print ('doing -> startsheetid =',startsheetid,',endsheetid=',
            endsheetid,',sheetname=',sheetname,
            'lookupsheetID=',lookupsheetID,
            'currententryidPos=',currententryidPos,
            'currentSheetPos=',currentSheetPos,
            'updatelistPos=',updatelistPos,
            )

      else : 
        print ('xxxxxx  ->  else problem!!! ')

    noofentry = total_articlelisttostore
    table_ref.child(archiveName).update({ 'noofentry' : noofentry , 'lastupdatetime' : int(nowTime.timestamp())})
    #table_ref.update({ 'noofentry' : 0 , 'lastupdatetime' : int(nowTime.timestamp())})
     



def updateSheetarticlelookuptable () :
  #first get how many 
  total_articleFromdatabase = gong.getArticleTableCount()
  articlelookuptable_ref = db.reference().child('articlelookuptable')
  articlelookuptableNoofEntry_ref = articlelookuptable_ref.child('noofentry')
  articlelookuptableentry_ref = articlelookuptable_ref.child('entry')
  noofentry = articlelookuptableNoofEntry_ref.get()
  if ( total_articleFromdatabase > noofentry ) :
    credentials = get_credentials()
    http = credentials.authorize(httplib2.Http())
    discoveryUrl = ('https://sheets.googleapis.com/$discovery/rest?'
                    'version=v4')
    service = discovery.build('sheets', 'v4', http=http,
                              discoveryServiceUrl=discoveryUrl)

    #first find which sheet should start update  
    startsheetid = 1+ (int(noofentry/ENTRYPERSHEET) * ENTRYPERSHEET) 
    endsheetid = ENTRYPERSHEET + (int(noofentry/ENTRYPERSHEET) * ENTRYPERSHEET) 
    sheetname = str(int(startsheetid)).zfill(10) + SEPERATENAME + str(int(endsheetid)).zfill(10)
    lookupsheetID = articlelookuptableentry_ref.child(sheetname.strip()).get()
    currententryidPos = noofentry #point to the element has just used
    currentSheetPos = int(1+ (currententryidPos % ENTRYPERSHEET)) #point to the element is going to use
    updatelistPos =0 #point to the element is going to use
    print ('begin -> startsheetid =',startsheetid,',endsheetid=',
            endsheetid,',sheetname=',sheetname,
            'lookupsheetID=',lookupsheetID,
            'currententryidPos=',currententryidPos,
            'currentSheetPos=',currentSheetPos,
            'updatelistPos=',updatelistPos,
            )
   
    #start the work
    #result = gong.getArticleTableRange(0,4659)
    result = gong.getArticleTableRange(noofentry)
    updateList = []
    for entry in result :
      #A1:J1
      entryValue = [ entry.id, entry.firstsubdomaintable_id,
                       entry.finalurl,
                       entry.timestampondoc.replace(tzinfo=timezone(timedelta(hours=8))).timestamp(),
                       entry.timestamponretrieve.replace(tzinfo=timezone(timedelta(hours=8))).timestamp(),
                       entry.title,
                       entry.content if len(entry.content) < 50000 else entry.content[:49998],
                       entry.imageurl if ((entry.imageurl is not None) and ( len(entry.imageurl) > 0) ) else EMPTYSTRINGVALUE ,
                       entry.similaritieslist if ((entry.similaritieslist is not None) and ( len(entry.similaritieslist) > 0) ) else EMPTYSTRINGVALUE, 
                       entry.similaritiescount if (entry.similaritiescount is not None) else 0 ]
      updateList.append(entryValue)
    
    while currententryidPos < total_articleFromdatabase :
      if (endsheetid  >= total_articleFromdatabase ) :
        batchcount =0
        numEntrytoUpdate = total_articleFromdatabase - \
          currententryidPos
        while ( numEntrytoUpdate > BATCHUPDATESIZE ) :
          #last sheetID to update
          write_range_name = 'Sheet1!A' +  \
            str(currentSheetPos) + \
            ':J' + \
            str( currentSheetPos + BATCHUPDATESIZE -1)
          body = { 'values' : updateList[ \
                             updatelistPos: updatelistPos + BATCHUPDATESIZE ] }
          #result = service.spreadsheets().values().update(
          result = service.spreadsheets().values().append(
                    spreadsheetId=lookupsheetID,
                    range=write_range_name,
                    valueInputOption=VALUE_INPUT_OPTION,
                    body=body).execute()
          print ('endsheetid  >= total_articleFromdatabase result=',
                result)
          numEntrytoUpdate -= BATCHUPDATESIZE
          currentSheetPos += BATCHUPDATESIZE
          updatelistPos += BATCHUPDATESIZE
          print ('numEntrytoUpdate=',numEntrytoUpdate,
                 'currentSheetPos=',currentSheetPos,
                 'updatelistPos=',updatelistPos)


        write_range_name = 'Sheet1!A' +  \
            str(currentSheetPos) + \
            ':J' + \
            str( currentSheetPos + (total_articleFromdatabase - \
               currententryidPos ) )
        body = { 'values' : updateList[ \
                             updatelistPos: updatelistPos + \
                              (total_articleFromdatabase - \
                               currententryidPos ) ] }
        result = service.spreadsheets().values().append(
                    spreadsheetId=lookupsheetID,
                    range=write_range_name,
                    valueInputOption=VALUE_INPUT_OPTION,
                    body=body).execute()
        print ('endsheetid  >= total_articleFromdatabase final result=',
                result)
        print ('numEntrytoUpdate=',numEntrytoUpdate,
                 'currentSheetPos=',currentSheetPos,
                 'updatelistPos=',updatelistPos)
        break

      elif (total_articleFromdatabase > endsheetid) :
        batchcount =0
        numEntrytoUpdate = ENTRYPERSHEET - currentSheetPos + 1
        currententryidPos += numEntrytoUpdate
        while (numEntrytoUpdate > BATCHUPDATESIZE ): 
      
          write_range_name = 'Sheet1!A' +  \
              str(currentSheetPos) + \
              ':J' + \
              str( currentSheetPos + BATCHUPDATESIZE -1 ) 
          body = { 'values' : updateList[ \
                             updatelistPos: updatelistPos + \
                              BATCHUPDATESIZE ] }
          result = service.spreadsheets().values().append(
                    spreadsheetId=lookupsheetID, 
                    range=write_range_name,
                    valueInputOption=VALUE_INPUT_OPTION, 
                    body=body).execute()
          print ('total_articleFromdatabase > endsheetid result=', 
                result)

          updatelistPos += BATCHUPDATESIZE 
          currentSheetPos += BATCHUPDATESIZE
          numEntrytoUpdate -= BATCHUPDATESIZE 
          
          print ('doing while loop total_articleFromdatabase > endsheetid  -> startsheetid =',startsheetid,',endsheetid=',
            endsheetid,',sheetname=',sheetname,
            'lookupsheetID=',lookupsheetID,
            'currententryidPos=',currententryidPos,
            'currentSheetPos=',currentSheetPos,
            'updatelistPos=',updatelistPos,
            )
       
        write_range_name = 'Sheet1!A' +  \
          str(currentSheetPos) + \
          ':J' + \
          str( ENTRYPERSHEET ) 
        body = { 'values' : updateList[ \
                             updatelistPos: updatelistPos + \
                              (ENTRYPERSHEET - \
                               currentSheetPos + 1) ] }
        result = service.spreadsheets().values().append(
                    spreadsheetId=lookupsheetID, 
                    range=write_range_name,
                    valueInputOption=VALUE_INPUT_OPTION, 
                    body=body).execute()
        print ('total_articleFromdatabase > endsheetid result=', 
                result)
        updatelistPos += ENTRYPERSHEET - currentSheetPos + 1
        
        currentSheetPos = 1
        startsheetid = int(1+ (int(currententryidPos/ENTRYPERSHEET) * \
                       ENTRYPERSHEET)) 
        endsheetid = int(ENTRYPERSHEET + \
                       (int(currententryidPos/ENTRYPERSHEET) * \
                         ENTRYPERSHEET) )
        sheetname =  str(startsheetid).zfill(10) + \
                     SEPERATENAME + \
                     str(endsheetid).zfill(10)
        lookupsheetID = articlelookuptableentry_ref.child(sheetname.strip()).get()
        print ('doing total_articleFromdatabase > endsheetid  `-> startsheetid =',startsheetid,',endsheetid=',
            endsheetid,',sheetname=',sheetname,
            'lookupsheetID=',lookupsheetID,
            'currententryidPos=',currententryidPos,
            'currentSheetPos=',currentSheetPos,
            'updatelistPos=',updatelistPos,
            )
   

      else : 
        print ('xxxxxx  ->  else problem!!! ')

    noofentry = total_articleFromdatabase
    articlelookuptable_ref.update({ 'noofentry' : noofentry , 'lastupdatetime' : int(nowTime.timestamp())})
    #articlelookuptable_ref.update({ 'noofentry' : 0 , 'lastupdatetime' : int(nowTime.timestamp())})
     


def updatetableThree (checkinInfo) :
  table_ref = db.reference().child(checkinInfo['firebasetable_name'])
  tableNoofEntry_ref = table_ref.child('noofentry')
  totalFromFirebase = tableNoofEntry_ref.get()

  newTotalFromDatabase = gong.getSumOfArticleWithCategory(checkinInfo['category_name'])

  articleresult = gong.getArticleWithCategoryAndOffset( checkinInfo['category_name'], 
                  totalFromFirebase )
  firstsubdomainresult = gong.getFirstSubDomainDict()
  noofentry = 0
  result = table_ref.get()
  resultlist = []
  print (" updatetable 0 len(articleresult)=", len(articleresult)) 
  for entry in articleresult :
    prep_list=[]
    prep_dict={}
    if (entry.similaritiescount is not None) and (entry.similaritiescount >0 ) :
      for sim_id in entry.similaritieslist.split() :
        sim_id_entry = gong.getIndArticleEntry(sim_id)
        addToListEntry = {}
        addToListEntry['id'] = sim_id_entry.id
        addToListEntry['firstsubdomaintable_id'] = sim_id_entry.firstsubdomaintable_id
        addToListEntry['finalurl'] = sim_id_entry.finalurl
        addToListEntry['imageurl'] = sim_id_entry.imageurl
        addToListEntry['timestampondoc'] = int(sim_id_entry.timestampondoc.replace(tzinfo=timezone(timedelta(hours=8))).timestamp())
        addToListEntry['title'] = sim_id_entry.title
        timestampondocandid = 'Z'.join([str(int(sim_id_entry.timestampondoc.replace(tzinfo=timezone(timedelta(hours=8))).timestamp())), str(sim_id_entry.id).zfill(10) ])
        addToListEntry['timestampondocandid'] = timestampondocandid


        #prep_list.append({ timestampondocandid : addToListEntry })
        prep_dict[timestampondocandid] = addToListEntry  

        
        #if len(json.dumps(prep_list)) > 50000 :
        if len(json.dumps(prep_dict)) > 50000 :
           #print ("wow... too big for json cell entry.id=", entry.id , " sim_id_entry.id=", sim_id_entry.id, "len(prep_list)=",len(prep_list), ",entry.similaritiescount=", entry.similaritiescount) 
           #prep_list = prep_list[:-1]
           print ("wow... too big for json cell entry.id=", entry.id , " sim_id_entry.id=", sim_id_entry.id, "len(prep_dict)=",len(prep_dict), ",entry.similaritiescount=", entry.similaritiescount) 
           del prep_dict[timestampondocandid]
           break 
    
      #entry.entryjsonStr = json.dumps(prep_list)
      #entry.similaritiescount = len(prep_list)
      orderDict = OrderedDict(sorted(prep_dict.items()))
      entry.entryjsonStr = json.dumps(orderDict)
      entry.similaritiescount = len(orderDict)
    else :
      entry.entryjsonStr = EMPTYSTRINGVALUE


  #do the tensorflow part
  vocab_path = os.path.join(CHECKPOINT_DIR , "..", "vocab")
  vocab_processor = learn.preprocessing.VocabularyProcessor.restore(vocab_path)
  entityListDict = gong.getEntityDictEmptyList()
  checkpoint_file = tf.train.latest_checkpoint(CHECKPOINT_DIR)
  graph = tf.Graph()
  with graph.as_default():
    session_conf = tf.ConfigProto(
      allow_soft_placement=True,
      log_device_placement=False )
    sess = tf.Session( config=session_conf)
    with sess.as_default():
        # Load the saved meta graph and restore variables
        saver = tf.train.import_meta_graph("{}.meta".format(checkpoint_file))
        saver.restore(sess, checkpoint_file)

        # Get the placeholders from the graph by name
        input_x = graph.get_operation_by_name("input_x").outputs[0]
        # input_y = graph.get_operation_by_name("input_y").outputs[0]
        dropout_keep_prob = graph.get_operation_by_name("dropout_keep_prob").outputs[0]
        # Tensors we want to evaluate
        predictions = graph.get_operation_by_name("output/predictions").outputs[0]
        
        for entry in articleresult :
          for key in entityListDict :
            tokenSenList = gong.getTokenSenCaseList( entry.id ) 
            if (tokenSenList is None) or (len(tokenSenList) ==0) :
              print ("error error tokenSenList ==0 or none entry.id=", entry.id)
              break 
      
            transformTokenArray = np.array(list(vocab_processor.transform(tokenSenList)))
            # Generate batches for one epoch
            batches = data_helpers.batch_iter(list(transformTokenArray), 
                        64, 1, shuffle=False)
            # Collect the predictions here
            all_predictions = []
            for x_test_batch in batches:
              batch_predictions = sess.run(predictions, {input_x: x_test_batch, dropout_keep_prob: 1.0})
              all_predictions = np.concatenate([all_predictions, batch_predictions])
            all_predictions_list = [ int(x) for x in all_predictions.tolist()]
            #print (" all_predictions_list=", all_predictions_list)
            entityName = key.split('ZZ')[0].strip('0')
            entityID = key.split('ZZ')[1].strip('0')
            foundthecase=False
            for checkCase in  entityListDict[key]['checkrelatedcaseList']  :
              for i, checkValue in enumerate(all_predictions_list) :
                #if there is a case , check name then
                #print (" i=",i," checkValue=",checkValue,",checkCase=",checkCase, ", checkValue==checkCase", checkValue ==checkCase )
                if ( ( checkValue == checkCase ) and ( entry.content.find(entityName) > -1 ) )  :
                  entityListDict[key]['relatedarticleList'].append(entry) 
                  foundthecase=True 
                  break
              if (foundthecase) :
                break
              
  #let put the list to drive 
  #first put the list to entity
  for key in entityListDict :
    print (" for loop entityListDict key=",key)
    updateSheetArchivetable ('entitytable',
             key, 
             entityListDict[key]['relatedarticleList']) 
  
  #exit for now 
  #if len(articleresult) >= 0 :
  #  print (" exit for now")
  #  return 
  #return

  #now put the list to archive 
  print (" updatetable 1") 
  if len(articleresult) > 0 :
    print (" updatetable 1.1") 
    updateSheetArchivetable (checkinInfo['firebasetable_name'],
             checkinInfo['archivename'], 
             articleresult) 
  print (" updatetable 2") 
  print (" updatetable 2 articleresult[0].id=", 
       articleresult[0].id ,
       "articleresult[-1].id=", 
       articleresult[-1].id)

  siftResultList = siftOlderArticle( articleresult ) 
  print (" updatetable 3 siftResultList[0].id=", 
       siftResultList[0].id ,
       "siftResultList[-1].id=", 
       siftResultList[-1].id)

  siftListlen = len(siftResultList)
  
  if siftListlen < (NOOFENTRYPERPAGE * NOOFPAGINATION) :
    #addback entry if needed for pagination 
    print (" updatetable 4") 
    getBackList = getSheetEntries( checkinInfo['firebasetable_name'],
             checkinInfo['pagearchivetable_name'],
             (NOOFENTRYPERPAGE * NOOFPAGINATION) - siftListlen,
             ) 
    if (len(getBackList) > 0 ) :
      print (" updatetable 4.1=", len(getBackList)) 
      for x in getBackList :
        #add back to a full list to update pagination table
        siftResultList.append(x)



  #update database
  print (" updatetable 5 ") 
  if len(siftResultList) > 0 :
    print (" updatetable 5.1 ") 
    updateSheetArchivetable (checkinInfo['firebasetable_name'],
             checkinInfo['pagearchivetable_name'],
             siftResultList) 
  print (" updatetable 6") 
  

 
  if len(siftResultList) > 0 :
    print (" updatetable 8") 
    pagination_ref = table_ref.child(checkinInfo['paginationtable_name'])
    pagination_ref.delete()
    startpagerange = 1
    stoppagerange = NOOFENTRYPERPAGE
    pagination_ref = table_ref.child(checkinInfo['paginationtable_name'])
    noofentry=0
    print (" updatetable 8.1 siftResultList[0].id=", 
       siftResultList[0].id ,
       "siftResultList[-1].id=", 
       siftResultList[-1].id)
    siftResultList.reverse()
    print (" updatetable 8.2 siftResultList[0].id=", 
       siftResultList[0].id ,
       "siftResultList[-1].id=", 
       siftResultList[-1].id)
    for entry in siftResultList[:(NOOFENTRYPERPAGE * NOOFPAGINATION)] :
      print ('--------- entry.id= ' , entry.id  )
      noofentry += 1
      print (' ========================= noofentry = ', noofentry)

      #paginationumber start from 0
      paginationnumber = int((noofentry-1) / NOOFENTRYPERPAGE) 
      sectionname = str(int(startpagerange + \
                      (paginationnumber * NOOFENTRYPERPAGE)) ) + \
                      "to" + \
                      str(int(stoppagerange + \
                        (paginationnumber * NOOFENTRYPERPAGE)) )
      paginationsec_ref = pagination_ref.child(sectionname)
      paginationsec_ref.update({ "noofentry" : ((noofentry-1)  % NOOFENTRYPERPAGE ) +1  })
      paginationsec_ref.update({ 'lastupdatetime' : int(nowTime.timestamp())})
      paginationsecentry_ref = paginationsec_ref.child("entry")
      paginationsecentry_ref.child('Z'.join(  
            [str(int(entry.timestampondoc.replace( \
                tzinfo=timezone(timedelta(hours=8))).timestamp())),
            str(entry.id).zfill(10) ]))\
            .update({ 'id' : entry.id ,
            'firstsubdomaintable_id' : entry.firstsubdomaintable_id, 
            'finalurl' : entry.finalurl, 
            'title' : entry.title ,
            'imageurl' : entry.imageurl if ((entry.imageurl is not None) and ( len(entry.imageurl) > 0) ) else EMPTYSTRINGVALUE ,
            'similaritiescount' : entry.similaritiescount if (entry.similaritiescount is not None) else 0 
            } )
      if (entry.similaritiescount is not None) and (entry.similaritiescount > 0) :
        for similarentryid in entry.similaritieslist.strip().split() :
          similarentry = gong.getIndArticleEntry(similarentryid)
          paginationsecentry_ref.child('Z'.join([str(int(entry.timestampondoc.replace(tzinfo=timezone(timedelta(hours=8))).timestamp())), str(entry.id).zfill(10) ]))\
              .child("entry").child('Z'.join([str(int(similarentry.timestampondoc.replace(tzinfo=timezone(timedelta(hours=8))).timestamp())), str(similarentry.id).zfill(10) ]))\
              .update({ 'id' : similarentry.id ,
                     'firstsubdomaintable_id' : similarentry.firstsubdomaintable_id, 
                     'finalurl' : similarentry.finalurl, 
                     'title' : similarentry.title ,
                     'imageurl' : similarentry.imageurl if ((similarentry.imageurl is not None) and ( len(similarentry.imageurl) > 0) ) else EMPTYSTRINGVALUE ,
                } )

  table_ref.update({ 'noofentry' : newTotalFromDatabase , 'lastupdatetime' : int(nowTime.timestamp())})


def main():
  checktime = datetime.now(timezone(timedelta(hours=8)))
  print ('checktime firebase-update-2 start', checktime)
  #updatecategorytable()
  #updatedomaintable()
  #updatefirstsubdomaintable()
  #updatearticletable()
  #updatelatestnewstable() 
  #updatelatestnewstableTwo() 
  #updatearticlelookuptable()
  if flags.sheetapi :
    print ("hello sheetapi")
    #articlelookuptable_ref = db.reference().child('articlelookuptable')
    #articlelookuptableNoofEntry_ref = articlelookuptable_ref.child('noofentry')
    #articlelookuptableentry_ref = db.reference().child('entry')
    #noofentry = articlelookuptableNoofEntry_ref.get()
    #print ('entry',articlelookuptableentry_ref.get())
    #print ('whole',articlelookuptable_ref.get())
    updateSheetarticlelookuptable ()


  if flags.gdriveupload :
    #listAtGDrive ()
    #creategongdbAtGDrive ()
    updategongdbAtGDrive () 

  if flags.gdrivedownload :
    #listAtGDrive ()
    #creategongdbAtGDrive ()
    downloadgongdbAtGDrive () 


  if flags.updatetable :
    checkinDict = { 'archivename' : 'archivelatestnews',
     'category_name' : 'latestnews',
     'firebasetable_name' : 'latestnewstable',
     'pagearchivetable_name' : 'pagearchivelatestnews',
     'paginationtable_name' : 'pagination'
     }
    updatetableThree (checkinDict) 

  if ( type(flags.arclatestnoofentry) is list ) :
    print ("arclatestnoofentry = ", flags.arclatestnoofentry)
    if flags.arclatestnoofentry[0] > 1 :
      checkinDict = { 'archivename' : 'archivelatestnews',
         'category_name' : 'latestnews',
         'firebasetable_name' : 'latestnewstable',
         'pagearchivetable_name' : 'pagearchivelatestnews',
         'paginationtable_name' : 'pagination'
         }
      table_ref = db.reference().child(checkinDict['firebasetable_name'])
      tableFirstNoofEntry_ref = table_ref.child('noofentry')
      tableSecondNoofEntry_ref = table_ref.child(checkinDict['archivename']).child('noofentry')
      print ("firstlevel  before noofentry", tableFirstNoofEntry_ref.get())
      print ("secondlevel  before noofentry", tableSecondNoofEntry_ref.get())
      tableSecond_ref = table_ref.child(checkinDict['archivename'])
      table_ref.update({ 'noofentry' : flags.arclatestnoofentry[0] , 'lastupdatetime' : int(nowTime.timestamp())})
      tableSecond_ref.update({ 'noofentry' : flags.arclatestnoofentry[0] , 'lastupdatetime' : int(nowTime.timestamp())})
      print ("firstlevel after noofentry", tableFirstNoofEntry_ref.get())
      print ("secondlevel after noofentry", tableSecondNoofEntry_ref.get())

  if flags.createtable :
    print ("creating table")
    table_ref = db.reference().child('entitytable').child('hello')
    table_ref.set({ 'noofentry' : 3 , 'lastupdatetime' : int(nowTime.timestamp())})
    

  checktime = datetime.now(timezone(timedelta(hours=8)))
  print ('checktime firebase-update-2 end', checktime)
      
     


if __name__ == '__main__':
  main()



