#! /usr/bin/env python

import tensorflow as tf
import numpy as np
import os
import time
import datetime
import data_helpers
from text_cnn import TextCNN
from tensorflow.contrib import learn
import csv
from datetime import datetime, timedelta,timezone


# Parameters
# ==================================================

# Data Parameters
tf.flags.DEFINE_string("positive_data_file", "./data/rt-polaritydata/rt-polarity.pos", "Data source for the positive data.")
tf.flags.DEFINE_string("negative_data_file", "./data/rt-polaritydata/rt-polarity.neg", "Data source for the positive data.")

# Eval Parameters
tf.flags.DEFINE_integer("batch_size", 64, "Batch Size (default: 64)")
tf.flags.DEFINE_string("checkpoint_dir", "./runs/1498762899/checkpoints", "Checkpoint directory from training run")
tf.flags.DEFINE_boolean("eval_train", False, "Evaluate on all training data")
tf.flags.DEFINE_boolean("eval_sql", False, "Evaluate on all training data")

# Misc Parameters
tf.flags.DEFINE_boolean("allow_soft_placement", True, "Allow device soft device placement")
tf.flags.DEFINE_boolean("log_device_placement", False, "Log placement of ops on devices")




FLAGS = tf.flags.FLAGS
FLAGS._parse_flags()
print("\nParameters:")
for attr, value in sorted(FLAGS.__flags.items()):
    print("{}={}".format(attr.upper(), value))
print("")



tuple_train, label_train, tuple_dev, label_dev = data_helpers.load_data_and_labels(0 , breakornot=True, needtraintype=False )

test_tuple = tuple_train + tuple_dev
test_label = np.concatenate( [label_train , label_dev], 0)




# CHANGE THIS: Load data. Load your own data here
if FLAGS.eval_train:
    x_raw, y_test = data_helpers.load_data_and_labels(FLAGS.positive_data_file, FLAGS.negative_data_file)
    y_test = np.argmax(y_test, axis=1)
elif FLAGS.eval_sql :
    x_raw = [   x[3]  for x in test_tuple ]

else:
    x_raw = ['羅 景 楊 馬恩國 大狀 代表 向區 慶祥 法官 質疑 上區 官駁 回補交 保證金 命令 否 「 非正審 上訴 無須 上訴 許可 」 情況' , 
             '行政 議成員前 金管局 總裁 任志剛 網誌 表示 相信 內地 不 急 完全 開放 資本 帳 希望 香港 可以 把握 機 內地 金融 完全 開放 前 取得 一定 市場 份額成 國家 不可 缺 國際金融中心',
             '區官 反駁 指 「 如果 法庭 兩個 才 蓋 章羅否 可以 兩個 甚麼 不 做 」',
             '他 表示 自己 原本 打算 排隊 玩 鮑魚 遊戲 關 遊戲 已經額 滿 唯轉移 目標',
             '教聯 副主席 蔡若蓮 被 傳 出任 教育局 副局長 個 團體 包括 港語學 教育 實驗 學社 香港 眾志 香港 專上 學生 聯開 記者 表示 反對',
             '旗下 成員 包括 三聯書店 中華書局 商務印書館 萬里 機構 等 出版社 聯合出版集團 公布 截今 集團 今屆 書展 最 暢銷 綜合 圖書 頭位 分別 藝人 李家 鼎鼎 爺 廚房 桌球 運動員 傅家俊 人生 以草 繪本 貓 一般 隊友 分別 售出 超過 約冊 約 冊冊',
             '中國聯通 上交所',
             '旗下 成員 包括',
             '西貢 大浪西灣 男子 遇溺',
             '法庭 記者 ： 梁銘 姿',
             '求情 指 他 退役 俄國 砲 兵當 抵港 購物 利刀 作 紀念品 法官 獲不接納',
             '她 又 明白 立法 正休 議員 放暑假 議員 們 若 願意 開討論 「 一地兩檢 」 方案 政府 定 配合',
             '吹緩 東東 南風',
             '他 指出 整體 血液 屬 安全 水平'
            ]
    y_test = [7, 1, 1, 1, 7, 7, 7,7,7,7,2, 1,7,1 ]





# Map data into vocabulary
vocab_path = os.path.join(FLAGS.checkpoint_dir, "..", "vocab")
vocab_processor = learn.preprocessing.VocabularyProcessor.restore(vocab_path)
x_test = np.array(list(vocab_processor.transform(x_raw)))

print("\nEvaluating...\n")

# Evaluation
# ==================================================
checkpoint_file = tf.train.latest_checkpoint(FLAGS.checkpoint_dir)
graph = tf.Graph()
with graph.as_default():
    session_conf = tf.ConfigProto(
      allow_soft_placement=FLAGS.allow_soft_placement,
      log_device_placement=FLAGS.log_device_placement)
    sess = tf.Session(config=session_conf)
    with sess.as_default():
        # Load the saved meta graph and restore variables
        saver = tf.train.import_meta_graph("{}.meta".format(checkpoint_file))
        saver.restore(sess, checkpoint_file)

        # Get the placeholders from the graph by name
        input_x = graph.get_operation_by_name("input_x").outputs[0]
        # input_y = graph.get_operation_by_name("input_y").outputs[0]
        dropout_keep_prob = graph.get_operation_by_name("dropout_keep_prob").outputs[0]

        # Tensors we want to evaluate
        predictions = graph.get_operation_by_name("output/predictions").outputs[0]

        # Generate batches for one epoch
        batches = data_helpers.batch_iter(list(x_test), FLAGS.batch_size, 1, shuffle=False)

        # Collect the predictions here
        all_predictions = []

        for x_test_batch in batches:
            batch_predictions = sess.run(predictions, {input_x: x_test_batch, dropout_keep_prob: 1.0})
            all_predictions = np.concatenate([all_predictions, batch_predictions])

# Print accuracy if y_test is defined
if FLAGS.eval_sql :
    print ('--------  eval.py flags.eval_sql all_predictions=', all_predictions, " end")
    correct_predictions = float(sum(all_predictions == test_label))
    print("Total number of test examples: {}".format(len(test_label)))
    print("Accuracy: {:g}".format(correct_predictions/float(len(test_label))))
elif y_test is not None:
    print ('--------  eval.py y_test all_predictions=', all_predictions, " end")
    print ('--------  eval.py y_test all_predictions=', [ int(x) for x in all_predictions.tolist()], " end")
    print ('--------  eval.py y_test y_test=', y_test, " end")
    correct_predictions = float(sum(all_predictions == y_test))
    print("Total number of test examples: {}".format(len(y_test)))
    print("Accuracy: {:g}".format(correct_predictions/float(len(y_test))))
else:
    print ('--------  eval.py else all_predictions=', all_predictions, " end")

# Save the evaluation to a csv
predictions_human_readable = np.column_stack((np.array(x_raw), all_predictions))
out_path = os.path.join(FLAGS.checkpoint_dir, "..", "prediction.csv")
print("Saving evaluation to {0}".format(out_path))
with open(out_path, 'w') as f:
    csv.writer(f).writerows(predictions_human_readable)
