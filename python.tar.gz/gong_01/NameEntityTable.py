
import sqlalchemy
from sqlalchemy.orm import relationship, aliased
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import Column, Integer, String, Text, Table
from sqlalchemy import ForeignKey
from CommonBase import Base
#from SentenceTable import SentenceTable


#Base=declarative_base()


class NameEntityTable(Base):
  __tablename__ = 'nameentitytable'

  id=Column(Integer, primary_key=True)
  name=Column(Text)
  urllink=Column(Text)


  def __repr__(self):
    return "<NameEntityTable(id='%d', name='%s', urllink='%s')>" % (self.id, self.name, self.urllink)

