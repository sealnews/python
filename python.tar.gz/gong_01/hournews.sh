#!/bin/sh

echo "----->starting crhk"
idnumber=`docker ps | awk '{ if (NR > 1) print $1 }'`
docker restart $idnumber
sleep 5
scrapy crawl gong_01 -a domaintorun=crhk -a newstypetorun=latestnews


echo "----->starting rthk"
idnumber=`docker ps | awk '{ if (NR > 1) print $1 }'`
docker restart $idnumber
sleep 5
scrapy crawl gong_01 -a domaintorun=rthk -a newstypetorun=latestnews

echo "----->starting orientaldaily_net"
idnumber=`docker ps | awk '{ if (NR > 1) print $1 }'`
docker restart $idnumber
sleep 5
scrapy crawl gong_01 -a domaintorun=orientaldaily_net -a newstypetorun=latestnews


echo "----->starting appledaily"
idnumber=`docker ps | awk '{ if (NR > 1) print $1 }'`
docker restart $idnumber
sleep 5
scrapy crawl gong_01 -a domaintorun=appledaily -a newstypetorun=latestnews



echo "----->starting singtao"
idnumber=`docker ps | awk '{ if (NR > 1) print $1 }'`
docker restart $idnumber
sleep 5
scrapy crawl gong_01 -a domaintorun=singtao -a newstypetorun=latestnews



echo "----->starting mingpao"
idnumber=`docker ps | awk '{ if (NR > 1) print $1 }'`
docker restart $idnumber
sleep 5
scrapy crawl gong_01 -a domaintorun=mingpao -a newstypetorun=latestnews



echo "----->starting standnews"
idnumber=`docker ps | awk '{ if (NR > 1) print $1 }'`
docker restart $idnumber
sleep 5
scrapy crawl gong_01 -a domaintorun=standnews -a newstypetorun=latestnews


echo "----->starting passiontimes"
idnumber=`docker ps | awk '{ if (NR > 1) print $1 }'`
docker restart $idnumber
sleep 5
scrapy crawl gong_01 -a domaintorun=passiontimes -a newstypetorun=latestnews


echo "----->starting post852"
idnumber=`docker ps | awk '{ if (NR > 1) print $1 }'`
docker restart $idnumber
sleep 5
scrapy crawl gong_01 -a domaintorun=post852 -a newstypetorun=latestnews


echo "----->starting hk01"
idnumber=`docker ps | awk '{ if (NR > 1) print $1 }'`
docker restart $idnumber
sleep 5
scrapy crawl gong_01 -a domaintorun=hk01 -a newstypetorun=latestnews


