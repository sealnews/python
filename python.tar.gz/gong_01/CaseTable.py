
import sqlalchemy
from sqlalchemy.orm import relationship
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import Column, Integer, String, Text, Table
from sqlalchemy import ForeignKey
from CommonBase import Base



#Base=declarative_base()


class CaseTable(Base):
  __tablename__ = 'casetable'

  id=Column(Integer, primary_key=True)
  active=Column(Text)
  passive=Column(Text)

  sentencetable_list=relationship( "SentenceTable", back_populates='casetable', cascade="all ,delete, delete-orphan")

  def __repr__(self):
    return "<CaseTable(id='%d', active='%s', passive='%s')>" % (self.id, self.active, self.passive)

