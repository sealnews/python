
import sqlalchemy
from sqlalchemy.orm import relationship
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import Column, Integer, String, Text, Table
from sqlalchemy import ForeignKey
from CommonBase import Base



#Base=declarative_base()


class CategoryTable(Base):
  __tablename__ = 'categorytable'

  id=Column(Integer, primary_key=True)
  chi_name=Column(Text)
  eng_name=Column(Text)
  
  firstsubdomaintable_list=relationship("FirstSubDomainTable", back_populates="categorytable" , cascade="all, delete, delete-orphan")

  def __repr__(self):
    return "<CategoryTable(id='%d', chi_name='%s', eng_name='%s')>" % (self.id, self.chi_name, self.eng_name)

