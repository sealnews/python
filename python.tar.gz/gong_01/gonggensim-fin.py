#! /usr/bin/env python
import sys
import gensim
from gensim import corpora
import time
import json
from datetime import datetime, timedelta,timezone
from gensim import corpora, models, similarities
from collections import defaultdict
import re
from gong_01_db import GongAllTable
import os
import operator
from pprint import pprint
import data_helpers
from oauth2client import tools


gong=GongAllTable('gong.db')
session=gong.init_all_table()
nowTime = datetime.now(timezone(timedelta(hours=8)))
print ("start time for gensim = ", nowTime )



gong.deleteTokenArticleTableId()





try:
    import argparse
    parser = argparse.ArgumentParser(parents=[tools.argparser])
    parser.add_argument('--updatetable', action='store_true')
    parser.add_argument('--daysrange', nargs=1, type=int, default=7)
    flags = parser.parse_args()

except ImportError:
    flags = None
print ("executing ..... " , sys.argv[0])
print ("daysrange=", flags.daysrange)
in_endTime = nowTime  
daysrange = flags.daysrange[0] if type(flags.daysrange) is list else flags.daysrange
print ("daysrange=", daysrange)
in_startTime = nowTime  - timedelta(days=daysrange)

#in_startTime = datetime(2017,11,7,0,0,0,0,tzinfo=timezone(timedelta(hours=8)))
#in_endTime = datetime(2017,11,14,0,0,0,0,tzinfo=timezone(timedelta(hours=8)))
startRangeTime = datetime(2017, 11, 7,0,0,0, tzinfo=timezone(timedelta(hours=8)))
endRangeTime = datetime(2017, 11, 14,0,0,0, tzinfo=timezone(timedelta(hours=8)))



in_domain_eng_name = 'hkej'
in_category_eng_name = 'financialnews'
hkejFinDailyNews = gong.getTokenDailyNewsArticle( in_startTime , in_endTime, in_domain_eng_name, in_category_eng_name )
hkejFinDailyTexts = [ indArticleTuple[1].split() for indArticleTuple in hkejFinDailyNews]
hkejdictionary = corpora.Dictionary(hkejFinDailyTexts)

in_domain_eng_name = 'hkej_now'
in_category_eng_name = 'latestfinnews'
hkejFinLatestNews = gong.getTokenDailyNewsArticle( in_startTime , in_endTime, in_domain_eng_name, in_category_eng_name )
hkejFinLatestTexts = [ indArticleTuple[1].split() for indArticleTuple in hkejFinLatestNews]
hkejdictionary.add_documents(hkejFinLatestTexts)




in_domain_eng_name = 'appledaily'
in_category_eng_name = 'financialnews'
appledailyFinDailyNews = gong.getTokenDailyNewsArticle( in_startTime , in_endTime, in_domain_eng_name, in_category_eng_name )
appledailyFinDailyTexts = [ indArticleTuple[1].split() for indArticleTuple in appledailyFinDailyNews]
hkejdictionary.add_documents(appledailyFinDailyTexts)



in_domain_eng_name = 'orientaldaily'
in_category_eng_name = 'financialnews'
orientaldailyFinDailyNews = gong.getTokenDailyNewsArticle( in_startTime , in_endTime, in_domain_eng_name, in_category_eng_name )
orientaldailyFinDailyTexts = [ indArticleTuple[1].split() for indArticleTuple in orientaldailyFinDailyNews]
hkejdictionary.add_documents(orientaldailyFinDailyTexts)



in_domain_eng_name = 'aastocks'
in_category_eng_name = 'financialnews'
aastocksFinDailyNews = gong.getTokenDailyNewsArticle( in_startTime , in_endTime, in_domain_eng_name, in_category_eng_name )
aastocksFinDailyTexts = [ indArticleTuple[1].split() for indArticleTuple in aastocksFinDailyNews]
hkejdictionary.add_documents(aastocksFinDailyTexts)


in_domain_eng_name = 'aastocks_now'
in_category_eng_name = 'latestfinnews'
aastocksFinLatestNews = gong.getTokenDailyNewsArticle( in_startTime , in_endTime, in_domain_eng_name, in_category_eng_name )
aastocksFinLatestTexts = [ indArticleTuple[1].split() for indArticleTuple in aastocksFinLatestNews]
hkejdictionary.add_documents(aastocksFinLatestTexts)







hkejdailycorpus_org = [ hkejdictionary.doc2bow(text, allow_update=True) for text in hkejFinDailyTexts ]
hkejdailycorpus = [ [ indCorpusTuple  for indCorpusTuple in indCorpus if indCorpusTuple[1] > 1 ] for indCorpus in hkejdailycorpus_org ]

hkejlatestcorpus_org = [ hkejdictionary.doc2bow(text, allow_update=True) for text in hkejFinLatestTexts ]
hkejlatestcorpus = [ [ indCorpusTuple  for indCorpusTuple in indCorpus if indCorpusTuple[1] > 1 ] for indCorpus in hkejlatestcorpus_org ]

appledailydailycorpus_org = [ hkejdictionary.doc2bow(text, allow_update=True) for text in appledailyFinDailyTexts ]
appledailydailycorpus = [ [ indCorpusTuple  for indCorpusTuple in indCorpus if indCorpusTuple[1] > 1 ] for indCorpus in appledailydailycorpus_org ]

orientaldailydailycorpus_org = [ hkejdictionary.doc2bow(text, allow_update=True) for text in orientaldailyFinDailyTexts ]
orientaldailydailycorpus = [ [ indCorpusTuple  for indCorpusTuple in indCorpus if indCorpusTuple[1] > 1 ] for indCorpus in orientaldailydailycorpus_org ]

aastocksdailycorpus_org = [ hkejdictionary.doc2bow(text, allow_update=True) for text in aastocksFinDailyTexts ]
aastocksdailycorpus = [ [ indCorpusTuple  for indCorpusTuple in indCorpus if indCorpusTuple[1] > 1 ] for indCorpus in aastocksdailycorpus_org ]

aastockslatestcorpus_org = [ hkejdictionary.doc2bow(text, allow_update=True) for text in aastocksFinLatestTexts ]
aastockslatestcorpus = [ [ indCorpusTuple  for indCorpusTuple in indCorpus if indCorpusTuple[1] > 1 ] for indCorpus in aastockslatestcorpus_org ]






newsArticleList = [ [hkejFinDailyNews , hkejdailycorpus_org]  ,
                    [hkejFinLatestNews, hkejlatestcorpus_org],
                    [appledailyFinDailyNews, appledailydailycorpus_org ],
                    [orientaldailyFinDailyNews, orientaldailydailycorpus_org]  ,
                    [aastocksFinLatestNews, aastockslatestcorpus_org]  ,
                    [aastocksFinDailyNews, aastocksdailycorpus_org]  ,
                  ]








def updateArticleSimiliarities ( in_dictionary, in_newsArticleList , in_similaritesRatio, in_gong , in_starttime, in_endtime ):
  for indexArtList , indnewsArticle in enumerate(in_newsArticleList) :
    #indnewsArticle[1] is the corpus of the corresponding articlelist
    print ('--> updateArticleSimiliarities 1 len of len(indnewsArticle)=%d, indexArtList=%d' %(len(indnewsArticle[1]), indexArtList) )
    #print ('--> updateArticleSimiliarities 1 len of len(indnewsArticle)=%d, indexArtList=' %(len(indnewsArticle[1])) )
    similaritiesIndex = similarities.MatrixSimilarity(indnewsArticle[1], num_features = len(in_dictionary.items()))
    #similaritiesIndex = similarities.SparseMatrixSimilarity(indnewsArticle[1])
    #print ('updateArticleSimiliarities 2 ' )
    for crosscheckindexArtList , indcrosscheckRestPairofNewsArticle in enumerate(in_newsArticleList) :
      #print ('updateArticleSimiliarities 4 crosscheckindexArtList=%d' % crosscheckindexArtList )
      for indcorpusindex , indArticleCorpus in enumerate(indcrosscheckRestPairofNewsArticle[1] ) :
        #print ('updateArticleSimiliarities 5 len= ', len(indArticleCorpus) )
        indArticleCorpusSimValue = similaritiesIndex[indArticleCorpus]
        #print ('updateArticleSimiliarities 6 ' )
        sortedindArticleCorpusSimValue = sorted(list(enumerate(indArticleCorpusSimValue)) ,  key=lambda tu : -abs(tu[1]))
        #sortedindArticleCorpusSimValue[0] of tuple (indextoNewsArticleList, score) has the highest score
        if sortedindArticleCorpusSimValue[0][1] > in_similaritesRatio :
          #print ('updateArticleSimiliarities 7 ratio = ' , sortedindArticleCorpusSimValue[0][1])
          #set the related list
          #indcrosscheckRestPairofNewsArticle[0] list of NewsArticle
          #indnewsArticle[0] list of NewsArticle
          if indcrosscheckRestPairofNewsArticle[0][indcorpusindex][0] != indnewsArticle[0][sortedindArticleCorpusSimValue[0][0]][0] :
            articleTableIndexPair = [ indcrosscheckRestPairofNewsArticle[0][indcorpusindex][0] ,  indnewsArticle[0][sortedindArticleCorpusSimValue[0][0]][0] ]
            in_gong.setArticleSimilaritieslist(articleTableIndexPair )
            #print ('updateArticleSimiliarities 8 ' )



#startRangeTime = datetime(2017, 10, 8,0,0,0, tzinfo=timezone(timedelta(hours=8)))
#endRangeTime = datetime(2017, 11, 9,0,0,0, tzinfo=timezone(timedelta(hours=8)))
similaritesRatio = 0.35
updateArticleSimiliarities ( hkejdictionary, newsArticleList , similaritesRatio, gong , startRangeTime, endRangeTime )

print ("end time for gensim = ", datetime.now(timezone(timedelta(hours=8))) )












