#! /usr/bin/env python

from datetime import datetime, timedelta, timezone
import firebase_admin
from firebase_admin import credentials
from firebase_admin import db
from pprint import pprint
from gong_01_db import GongAllTable



EMPTYSTRINGVALUE = 'EMPTYSTRINGVALUE'
cred = credentials.Certificate('/media/sf_xubuntu-01-share/tensorflowOrgExamplePython/firebase/friendlychat-d1a66-firebase-adminsdk-eq7ke-c3ae44c287.json' )
default_app = firebase_admin.initialize_app(cred, {
        'databaseURL' : 'https://friendlychat-d1a66.firebaseio.com',
   })

gong=GongAllTable('gong.db')
session=gong.init_all_table()
nowTime= datetime.now(timezone(timedelta(hours=8)))


def updatecategorytable () :
  categoryresult = gong.getCategoryDict()
  noofentry = len(categoryresult)
  categorytable_ref = db.reference().child('categorytable')
  result = categorytable_ref.get()
  if result is None :
    #create the table
    print (' noofentry = ', noofentry)
    categorytable_ref.set({ 'noofentry' : noofentry , 'lastupdatetime' : int(nowTime.timestamp())})
    categorytableNoofEntry_ref = categorytable_ref.child('noofentry')
    categorytableLastUpdate_ref = categorytable_ref.child('lastupdatetime')
    categorytableEntry_ref = categorytable_ref.child('entry')
    for entry in categoryresult :
      print (' entry= ' , entry)
      categorytableEntry_ref.child(str(entry.id)).set({ 'id' : entry.id , 'chi_name' : entry.chi_name , 'eng_name' : entry.eng_name } )
 
  else :
    categorytableRntry_ref = categorytable_ref.child('entry')
    categorytableNoofEntry_ref = categorytable_ref.child('noofentry')
    categorytableLastUpdate_ref = categorytable_ref.child('lastupdatetime')
    if ( noofentry != categorytableNoofEntry_ref.get() ) or ( int(nowTime.timestamp())  < categorytableLastUpdate_ref.get() ) :
      print(' need to update ')
      categorytable_ref.update({ 'noofentry' : noofentry , 'lastupdatetime' : int(nowTime.timestamp())})
      categorytableEntry_ref = categorytable_ref.child('entry')
      for entry in categoryresult :
        print (' entry= ' , entry)
        if categorytable_ref.child('entry'+'/'+str(entry.id)).get() is None :
          categorytableEntry_ref.child(str(entry.id)).set({ 'id' : entry.id , 'chi_name' : entry.chi_name , 'eng_name' : entry.eng_name } )
        else :
          categorytableEntry_ref.child(str(entry.id)).update({ 'id' : entry.id , 'chi_name' : entry.chi_name , 'eng_name' : entry.eng_name } )

    else :
      print(' nothing to update in categorytable ')
  


def updatedomaintable () :
  domainresult = gong.getDomainDict()
  noofentry = len(domainresult)
  domaintable_ref = db.reference().child('domaintable')
  result = domaintable_ref.get()
  if result is None :
    #create the table
    print (' noofentry = ', noofentry)
    domaintable_ref.set({ 'noofentry' : noofentry , 'lastupdatetime' : int(nowTime.timestamp())})
    domaintableNoofEntry_ref = domaintable_ref.child('noofentry')
    domaintableLastUpdate_ref = domaintable_ref.child('lastupdatetime')
    domaintableEntry_ref = domaintable_ref.child('entry')
    for entry in domainresult :
      print (' entry= ' , entry)
      domaintableEntry_ref.child(str(entry.id)).set({ 'id' : entry.id , 'baseurl' : entry.baseurl , 'chi_name' : entry.chi_name , 'eng_name' : entry.eng_name } )
  else :
    domaintableRntry_ref = domaintable_ref.child('entry')
    domaintableNoofEntry_ref = domaintable_ref.child('noofentry')
    domaintableLastUpdate_ref = domaintable_ref.child('lastupdatetime')
    if ( noofentry != domaintableNoofEntry_ref.get() ) or ( int(nowTime.timestamp())  < domaintableLastUpdate_ref.get() ) :
      print(' need to update ')
      domaintable_ref.update({ 'noofentry' : noofentry , 'lastupdatetime' : int(nowTime.timestamp())})
      domaintableEntry_ref = domaintable_ref.child('entry')
      for entry in domainresult :
        print (' entry= ' , entry)
        if domaintable_ref.child('entry'+'/'+str(entry.id)).get() is None :
          domaintableEntry_ref.child(str(entry.id)).set({ 'id' : entry.id , 'baseurl' : entry.baseurl , 'chi_name' : entry.chi_name , 'eng_name' : entry.eng_name } )
        else :
          domaintableEntry_ref.child(str(entry.id)).update({ 'id' : entry.id ,  'baseurl' : entry.baseurl , 'chi_name' : entry.chi_name , 'eng_name' : entry.eng_name } )
    else :
      print(' nothing to update in domaintable ')
  

def updatefirstsubdomaintable () :
  firstsubdomainresult = gong.getFirstSubDomainDict()
  noofentry = len(firstsubdomainresult)
  firstsubdomaintable_ref = db.reference().child('firstsubdomaintable')
  result = firstsubdomaintable_ref.get()
  if result is None :
    #create the table
    print (' noofentry = ', noofentry)
    firstsubdomaintable_ref.set({ 'noofentry' : noofentry , 'lastupdatetime' : int(nowTime.timestamp())})
    firstsubdomaintableNoofEntry_ref = firstsubdomaintable_ref.child('noofentry')
    firstsubdomaintableLastUpdate_ref = firstsubdomaintable_ref.child('lastupdatetime')
    firstsubdomaintableEntry_ref = firstsubdomaintable_ref.child('entry')
    for entry in firstsubdomainresult :
      print (' entry= ' , entry)
      firstsubdomaintableEntry_ref.child(str(entry.id)).set({ 'id' : entry.id ,
            'domaintable_id' : entry.domaintable_id, 
            'categorytable_id' : entry.categorytable_id, 
            'latestupdatetime' : entry.latestupdatetime.replace(tzinfo=timezone(timedelta(hours=8))).timestamp(), 
            'latestupdateurl' : entry.latestupdateurl 
      } )
  else :
    firstsubdomaintableRntry_ref = firstsubdomaintable_ref.child('entry')
    firstsubdomaintableNoofEntry_ref = firstsubdomaintable_ref.child('noofentry')
    firstsubdomaintableLastUpdate_ref = firstsubdomaintable_ref.child('lastupdatetime')
    if ( noofentry != firstsubdomaintableNoofEntry_ref.get() ) or ( int(nowTime.timestamp())  < firstsubdomaintableLastUpdate_ref.get() ) :
      print(' need to update ')
      firstsubdomaintable_ref.update({ 'noofentry' : noofentry , 'lastupdatetime' : int(nowTime.timestamp())})
      firstsubdomaintableEntry_ref = firstsubdomaintable_ref.child('entry')
      for entry in firstsubdomainresult :
        print (' entry= ' , entry)
        if firstsubdomaintable_ref.child('entry'+'/'+str(entry.id)).get() is None :
          firstsubdomaintableEntry_ref.child(str(entry.id)).set({ 'id' : entry.id ,
            'domaintable_id' : entry.domaintable_id, 
            'categorytable_id' : entry.categorytable_id, 
            'latestupdatetime' : entry.latestupdatetime.replace(tzinfo=timezone(timedelta(hours=8))).timestamp(), 
            'latestupdateurl' : entry.latestupdateurl 
          } )
        else :
          firstsubdomaintableEntry_ref.child(str(entry.id)).update({ 'id' : entry.id ,
            'domaintable_id' : entry.domaintable_id, 
            'categorytable_id' : entry.categorytable_id, 
            'latestupdatetime' : entry.latestupdatetime.replace(tzinfo=timezone(timedelta(hours=8))).timestamp(), 
            'latestupdateurl' : entry.latestupdateurl 
          } )

    else :
      print(' nothing to update in firstsubdomaintable ')
  


def updatearticletable () :
  articleresult = gong.getArticleDict()
  noofentry = len(articleresult)
  articletable_ref = db.reference().child('articletable')
  result = articletable_ref.get()
  if result is None :
    #create the table
    print (' noofentry = ', noofentry)
    articletable_ref.set({ 'noofentry' : noofentry , 'lastupdatetime' : int(nowTime.timestamp())})
    articletableNoofEntry_ref = articletable_ref.child('noofentry')
    articletableLastUpdate_ref = articletable_ref.child('lastupdatetime')
    articletableEntry_ref = articletable_ref.child('entry')
    #testcount=0
    for entry in articleresult :
      #testcount += 1
      #if testcount >10 :
      #  break
      #print (' entry= ' , entry)
      articletableEntry_ref.child(str(entry.id)).set({ 'id' : entry.id ,
            'firstsubdomaintable_id' : entry.firstsubdomaintable_id, 
            'finalurl' : entry.finalurl, 
            'timestampondoc' : entry.timestampondoc.replace(tzinfo=timezone(timedelta(hours=8))).timestamp(), 
            'timestamponretrieve' : entry.timestamponretrieve.replace(tzinfo=timezone(timedelta(hours=8))).timestamp(), 
            'title' : entry.title ,
            'content' : entry.content ,
            'imageurl' : entry.imageurl if ((entry.imageurl is not None) and ( len(entry.imageurl) > 0) ) else EMPTYSTRINGVALUE ,
            'similaritieslist' : entry.similaritieslist if (( entry.similaritieslist is not None) and ( len(entry.similaritieslist) > 0 ) ) else EMPTYSTRINGVALUE,
            'similaritiescount' : entry.similaritiescount 
      } )
  else :
    articletableRntry_ref = articletable_ref.child('entry')
    articletableNoofEntry_ref = articletable_ref.child('noofentry')
    articletableLastUpdate_ref = articletable_ref.child('lastupdatetime')
    if ( noofentry > articletableNoofEntry_ref.get() ) :
      #print(' need to update ')
      articletable_ref.update({ 'noofentry' : noofentry , 'lastupdatetime' : int(nowTime.timestamp())})
      articletableEntry_ref = articletable_ref.child('entry')
      for entry in articleresult :
        #print (' entry= ' , entry)
        if articletable_ref.child('entry'+'/'+str(entry.id)).get() is None :
          #new entry
          articletableEntry_ref.child(str(entry.id)).set({ 'id' : entry.id ,
            'firstsubdomaintable_id' : entry.firstsubdomaintable_id, 
            'finalurl' : entry.finalurl, 
            'timestampondoc' : entry.timestampondoc.replace(tzinfo=timezone(timedelta(hours=8))).timestamp(), 
            'timestamponretrieve' : entry.timestamponretrieve.replace(tzinfo=timezone(timedelta(hours=8))).timestamp(), 
            'title' : entry.title ,
            'content' : entry.content ,
            'imageurl' : entry.imageurl if ((entry.imageurl is not None) and ( len(entry.imageurl) > 0) ) else EMPTYSTRINGVALUE ,
            'similaritieslist' : entry.similaritieslist if (( entry.similaritieslist is not None) and ( len(entry.similaritieslist) > 0 ) ) else EMPTYSTRINGVALUE,
            'similaritiescount' : entry.similaritiescount 
          } )
        elif entry.updatetofirebase == 1  :
          #update entry
          articletableEntry_ref.child(str(entry.id)).update({ 'id' : entry.id ,
            'firstsubdomaintable_id' : entry.firstsubdomaintable_id, 
            'finalurl' : entry.finalurl, 
            'timestampondoc' : entry.timestampondoc.replace(tzinfo=timezone(timedelta(hours=8))).timestamp(), 
            'timestamponretrieve' : entry.timestamponretrieve.replace(tzinfo=timezone(timedelta(hours=8))).timestamp(), 
            'title' : entry.title ,
            'content' : entry.content ,
            'imageurl' : entry.imageurl if ((entry.imageurl is not None) and ( len(entry.imageurl) > 0) ) else EMPTYSTRINGVALUE ,
            'similaritieslist' : entry.similaritieslist if (( entry.similaritieslist is not None) and ( len(entry.similaritieslist) > 0 ) ) else EMPTYSTRINGVALUE,
            'similaritiescount' : entry.similaritiescount 
          } )

    else :
      print(' nothing to update in articletable ')
  









#updatecategorytable()
#updatedomaintable()
#updatefirstsubdomaintable()
updatearticletable()




