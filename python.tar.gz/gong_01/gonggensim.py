#! /usr/bin/env python
import sys
import gensim
from gensim import corpora
import time
import json
from datetime import datetime, timedelta,timezone
from gensim import corpora, models, similarities
from collections import defaultdict
import re
from gong_01_db import GongAllTable
import os
import operator
from pprint import pprint
import data_helpers
from oauth2client import tools


gong=GongAllTable('gong.db')
session=gong.init_all_table()
nowTime = datetime.now(timezone(timedelta(hours=8)))
print ("start time for gensim = ", nowTime )


try:
    import argparse
    parser = argparse.ArgumentParser(parents=[tools.argparser])
    parser.add_argument('--updatetable', action='store_true')
    parser.add_argument('--daysrange', nargs=1, type=int, default=7)
    flags = parser.parse_args()

except ImportError:
    flags = None
print ("executing ..... " , sys.argv[0])
print ("daysrange=", flags.daysrange)
in_endTime = nowTime  
daysrange = flags.daysrange[0] if type(flags.daysrange) is list else flags.daysrange
print ("daysrange=", daysrange)
in_startTime = nowTime  - timedelta(days=daysrange)

#in_startTime = datetime(2017,11,7,0,0,0,0,tzinfo=timezone(timedelta(hours=8)))
#in_endTime = datetime(2017,11,14,0,0,0,0,tzinfo=timezone(timedelta(hours=8)))
startRangeTime = datetime(2017, 11, 7,0,0,0, tzinfo=timezone(timedelta(hours=8)))
endRangeTime = datetime(2017, 11, 14,0,0,0, tzinfo=timezone(timedelta(hours=8)))

print (' time 1 : ', datetime.now(timezone(timedelta(hours=8))) )

in_domain_eng_name = 'singtao'
in_category_eng_name = 'dailynews'
singtaoDailyNews = gong.getTokenDailyNewsArticle( in_startTime , in_endTime, in_domain_eng_name, in_category_eng_name )
singtaoDailyTexts = [ indArticleTuple[1].split() for indArticleTuple in singtaoDailyNews]
singtaodictionary = corpora.Dictionary(singtaoDailyTexts)


print (' time 2 : ', datetime.now(timezone(timedelta(hours=8))) )


in_domain_eng_name = 'mingpao'
in_category_eng_name = 'dailynews'
mingpaoDailyNews = gong.getTokenDailyNewsArticle( in_startTime , in_endTime, in_domain_eng_name, in_category_eng_name )

print (' time 3 : ', datetime.now(timezone(timedelta(hours=8))) )

mingpaoDailyTexts = [ indArticleTuple[1].split()  for indArticleTuple in mingpaoDailyNews]
#mingpaodictionary = corpora.Dictionary(mingpaoDailyTexts)
#mingpaodictionary.save(os.path.join('.','dailynewsGensim-mingpao.dict'))
#mingpaocorpus = [ mingpaodictionary.doc2bow(text) for text in mingpaoDailyTexts ]
singtaodictionary.add_documents(mingpaoDailyTexts)



print (' time 4 : ', datetime.now(timezone(timedelta(hours=8))) )

in_domain_eng_name = 'appledaily'
in_category_eng_name = 'dailynews'
appledailyDailyNews = gong.getTokenDailyNewsArticle( in_startTime , in_endTime, in_domain_eng_name, in_category_eng_name )

print (' time 5 : ', datetime.now(timezone(timedelta(hours=8))) )

appledailyDailyTexts = [ indArticleTuple[1].split() for indArticleTuple in appledailyDailyNews]
appledailyDailyNewsListOnly = [ indArticleTuple[1] for indArticleTuple in appledailyDailyNews ]
#appledailydictionary = corpora.Dictionary(appledailyDailyTexts)
#appledailydictionary.save(os.path.join('.','dailynewsGensim-appledaily.dict'))
#appledailycorpus = [ appledailydictionary.doc2bow(text) for text in appledailyDailyTexts ]
singtaodictionary.add_documents(appledailyDailyTexts)



print (' time 6 : ', datetime.now(timezone(timedelta(hours=8))) )


in_domain_eng_name = 'appledaily'
in_category_eng_name = 'latestnews'
appledailyLatestNews = gong.getTokenDailyNewsArticle( in_startTime , in_endTime, in_domain_eng_name, in_category_eng_name )

print (' time 7 : ', datetime.now(timezone(timedelta(hours=8))) )

appledailyLatestTexts = [ indArticleTuple[1].split() for indArticleTuple in appledailyLatestNews]
appledailyLatestNewsListOnly = [ indArticleTuple[1] for indArticleTuple in appledailyLatestNews ]
singtaodictionary.add_documents(appledailyLatestTexts)



print (' time 8 : ', datetime.now(timezone(timedelta(hours=8))) )


in_domain_eng_name = 'orientaldaily'
in_category_eng_name = 'dailynews'
orientaldailyDailyNews = gong.getTokenDailyNewsArticle( in_startTime , in_endTime, in_domain_eng_name, in_category_eng_name )

print (' time 9 : ', datetime.now(timezone(timedelta(hours=8))) )

orientaldailyDailyTexts = [ indArticleTuple[1].split() for indArticleTuple in orientaldailyDailyNews]
singtaodictionary.add_documents(orientaldailyDailyTexts)



print (' time 10 : ', datetime.now(timezone(timedelta(hours=8))) )


in_domain_eng_name = 'orientaldaily_net'
in_category_eng_name = 'latestnews'
orientaldailyNetLatestNews = gong.getTokenDailyNewsArticle( in_startTime , in_endTime, in_domain_eng_name, in_category_eng_name )

print (' time 11 : ', datetime.now(timezone(timedelta(hours=8))) )

orientaldailyNetLatestTexts = [ indArticleTuple[1].split() for indArticleTuple in orientaldailyNetLatestNews]
singtaodictionary.add_documents(orientaldailyNetLatestTexts)


print (' time 12 : ', datetime.now(timezone(timedelta(hours=8))) )

in_domain_eng_name = 'mingpao'
in_category_eng_name = 'latestnews'
mingpaoLatestNews = gong.getTokenDailyNewsArticle( in_startTime , in_endTime, in_domain_eng_name, in_category_eng_name )
mingpaoLatestTexts = [ indArticleTuple[1].split()  for indArticleTuple in mingpaoLatestNews]
singtaodictionary.add_documents(mingpaoLatestTexts)


print (' time 13 : ', datetime.now(timezone(timedelta(hours=8))) )

in_domain_eng_name = 'singtao'
in_category_eng_name = 'latestnews'
singtaoLatestNews = gong.getTokenDailyNewsArticle( in_startTime , in_endTime, in_domain_eng_name, in_category_eng_name )

print (' time 14 : ', datetime.now(timezone(timedelta(hours=8))) )

singtaoLatestTexts = [ indArticleTuple[1].split() for indArticleTuple in singtaoLatestNews]
singtaodictionary.add_documents(singtaoLatestTexts)


print (' time 15 : ', datetime.now(timezone(timedelta(hours=8))) )

in_domain_eng_name = 'rthk'
in_category_eng_name = 'latestnews'
rthkLatestNews = gong.getTokenDailyNewsArticle( in_startTime , in_endTime, in_domain_eng_name, in_category_eng_name )

print (' time 16 : ', datetime.now(timezone(timedelta(hours=8))) )

rthkLatestTexts = [ indArticleTuple[1].split() for indArticleTuple in rthkLatestNews]
singtaodictionary.add_documents(rthkLatestTexts)

in_domain_eng_name = 'crhk'
in_category_eng_name = 'latestnews'
crhkLatestNews = gong.getTokenDailyNewsArticle( in_startTime , in_endTime, in_domain_eng_name, in_category_eng_name )
crhkLatestTexts = [ indArticleTuple[1].split() for indArticleTuple in crhkLatestNews]
singtaodictionary.add_documents(crhkLatestTexts)
in_domain_eng_name = 'standnews'
in_category_eng_name = 'latestnews'
standnewsLatestNews = gong.getTokenDailyNewsArticle( in_startTime , in_endTime, in_domain_eng_name, in_category_eng_name )
standnewsLatestTexts = [ indArticleTuple[1].split() for indArticleTuple in standnewsLatestNews]
singtaodictionary.add_documents(standnewsLatestTexts)

in_domain_eng_name = 'passiontimes'
in_category_eng_name = 'latestnews'
passiontimesLatestNews = gong.getTokenDailyNewsArticle( in_startTime , in_endTime, in_domain_eng_name, in_category_eng_name )
passiontimesLatestTexts = [ indArticleTuple[1].split() for indArticleTuple in passiontimesLatestNews]
singtaodictionary.add_documents(passiontimesLatestTexts)

in_domain_eng_name = 'post852'
in_category_eng_name = 'latestnews'
post852LatestNews = gong.getTokenDailyNewsArticle( in_startTime , in_endTime, in_domain_eng_name, in_category_eng_name )
post852LatestTexts = [ indArticleTuple[1].split() for indArticleTuple in post852LatestNews]
singtaodictionary.add_documents(post852LatestTexts)

in_domain_eng_name = 'hk01'
in_category_eng_name = 'latestnews'
hk01LatestNews = gong.getTokenDailyNewsArticle( in_startTime , in_endTime, in_domain_eng_name, in_category_eng_name )
hk01LatestTexts = [ indArticleTuple[1].split() for indArticleTuple in hk01LatestNews]
singtaodictionary.add_documents(hk01LatestTexts)

in_domain_eng_name = 'now'
in_category_eng_name = 'latestnews'
nowLatestNews = gong.getTokenDailyNewsArticle( in_startTime , in_endTime, in_domain_eng_name, in_category_eng_name )
nowLatestTexts = [ indArticleTuple[1].split() for indArticleTuple in nowLatestNews]
singtaodictionary.add_documents(nowLatestTexts)

in_domain_eng_name = 'am730'
in_category_eng_name = 'dailynews'
am730LatestNews = gong.getTokenDailyNewsArticle( in_startTime , in_endTime, in_domain_eng_name, in_category_eng_name )
am730LatestTexts = [ indArticleTuple[1].split() for indArticleTuple in am730LatestNews]
singtaodictionary.add_documents(am730LatestTexts)







print (' time 17 : ', datetime.now(timezone(timedelta(hours=8))) )

singtaocorpus_org = [ singtaodictionary.doc2bow(text, allow_update=True) for text in singtaoDailyTexts ]
singtaocorpus = [ [ indCorpusTuple  for indCorpusTuple in indCorpus if indCorpusTuple[1] > 1 ] for indCorpus in singtaocorpus_org ]


print (' time 18 : ', datetime.now(timezone(timedelta(hours=8))) )

mingpaocorpus_org = [ singtaodictionary.doc2bow(text, allow_update=True) for text in mingpaoDailyTexts ]
mingpaocorpus = [ [ indCorpusTuple  for indCorpusTuple in indCorpus if indCorpusTuple[1] > 1 ] for indCorpus in mingpaocorpus_org ]


print (' time 19 : ', datetime.now(timezone(timedelta(hours=8))) )

appledailycorpus_org = [ singtaodictionary.doc2bow(text, allow_update=True) for text in appledailyDailyTexts ]
appledailycorpus = [ [ indCorpusTuple  for indCorpusTuple in indCorpus if indCorpusTuple[1] > 1 ] for indCorpus in appledailycorpus_org ]

print (' time 20 : ', datetime.now(timezone(timedelta(hours=8))) )


appledailylatestcorpus_org = [ singtaodictionary.doc2bow(text, allow_update=True) for text in appledailyLatestTexts ]
appledailylatestcorpus = [ [ indCorpusTuple  for indCorpusTuple in indCorpus if indCorpusTuple[1] > 1 ] for indCorpus in appledailylatestcorpus_org ]


print (' time 21 : ', datetime.now(timezone(timedelta(hours=8))) )

orientaldailycorpus_org = [ singtaodictionary.doc2bow(text, allow_update=True) for text in orientaldailyDailyTexts ]
orientaldailycorpus = [ [ indCorpusTuple  for indCorpusTuple in indCorpus if indCorpusTuple[1] > 1 ] for indCorpus in orientaldailycorpus_org ]

orientaldailylatestnewscorpus_org = [ singtaodictionary.doc2bow(text, allow_update=True) for text in orientaldailyNetLatestTexts ]
orientaldailylatestnewscorpus = [ [ indCorpusTuple  for indCorpusTuple in indCorpus if indCorpusTuple[1] > 1 ] for indCorpus in orientaldailylatestnewscorpus_org ]

mingpaolatestnewscorpus_org = [ singtaodictionary.doc2bow(text, allow_update=True) for text in mingpaoLatestTexts ]
mingpaolatestnewscorpus = [ [ indCorpusTuple  for indCorpusTuple in indCorpus if indCorpusTuple[1] > 1 ] for indCorpus in mingpaolatestnewscorpus_org ]

singtaolatestnewscorpus_org = [ singtaodictionary.doc2bow(text, allow_update=True) for text in singtaoLatestTexts ]
singtaolatestnewscorpus = [ [ indCorpusTuple  for indCorpusTuple in indCorpus if indCorpusTuple[1] > 1 ] for indCorpus in singtaolatestnewscorpus_org ]

rthklatestnewscorpus_org = [ singtaodictionary.doc2bow(text, allow_update=True) for text in rthkLatestTexts ]
rthklatestnewscorpus = [ [ indCorpusTuple  for indCorpusTuple in indCorpus if indCorpusTuple[1] > 1 ] for indCorpus in rthklatestnewscorpus_org ]

crhklatestnewscorpus_org = [ singtaodictionary.doc2bow(text, allow_update=True) for text in crhkLatestTexts ]
crhklatestnewscorpus = [ [ indCorpusTuple  for indCorpusTuple in indCorpus if indCorpusTuple[1] > 1 ] for indCorpus in crhklatestnewscorpus_org ]

standnewslatestnewscorpus_org = [ singtaodictionary.doc2bow(text, allow_update=True) for text in standnewsLatestTexts ]
standnewslatestnewscorpus = [ [ indCorpusTuple  for indCorpusTuple in indCorpus if indCorpusTuple[1] > 1 ] for indCorpus in standnewslatestnewscorpus_org ]

passiontimeslatestnewscorpus_org = [ singtaodictionary.doc2bow(text, allow_update=True) for text in passiontimesLatestTexts ]
passiontimeslatestnewscorpus = [ [ indCorpusTuple  for indCorpusTuple in indCorpus if indCorpusTuple[1] > 1 ] for indCorpus in passiontimeslatestnewscorpus_org ]

post852latestnewscorpus_org = [ singtaodictionary.doc2bow(text, allow_update=True) for text in post852LatestTexts ]
post852latestnewscorpus = [ [ indCorpusTuple  for indCorpusTuple in indCorpus if indCorpusTuple[1] > 1 ] for indCorpus in post852latestnewscorpus_org ]

hk01latestnewscorpus_org = [ singtaodictionary.doc2bow(text, allow_update=True) for text in hk01LatestTexts ]
hk01latestnewscorpus = [ [ indCorpusTuple  for indCorpusTuple in indCorpus if indCorpusTuple[1] > 1 ] for indCorpus in hk01latestnewscorpus_org ]

nowlatestnewscorpus_org = [ singtaodictionary.doc2bow(text, allow_update=True) for text in nowLatestTexts ]
nowlatestnewscorpus = [ [ indCorpusTuple  for indCorpusTuple in indCorpus if indCorpusTuple[1] > 1 ] for indCorpus in nowlatestnewscorpus_org ]

am730latestnewscorpus_org = [ singtaodictionary.doc2bow(text, allow_update=True) for text in am730LatestTexts ]
am730latestnewscorpus = [ [ indCorpusTuple  for indCorpusTuple in indCorpus if indCorpusTuple[1] > 1 ] for indCorpus in am730latestnewscorpus_org ]



print (' time 22 : ', datetime.now(timezone(timedelta(hours=8))) )



newsArticleList = [ [appledailyDailyNews , appledailycorpus_org]  ,
                    [orientaldailyDailyNews, orientaldailycorpus_org],
                    [mingpaoDailyNews, mingpaocorpus_org ],
                    [singtaoDailyNews, singtaocorpus_org]  ,
                    [orientaldailyNetLatestNews, orientaldailylatestnewscorpus_org]  ,
                    [appledailyLatestNews, appledailylatestcorpus_org]  ,
                    [mingpaoLatestNews, mingpaolatestnewscorpus_org]  ,
                    [singtaoLatestNews, singtaolatestnewscorpus_org]  ,
                    [rthkLatestNews, rthklatestnewscorpus_org]  ,
                    [crhkLatestNews, crhklatestnewscorpus_org]  ,
                    [standnewsLatestNews, standnewslatestnewscorpus_org]  ,
                    [passiontimesLatestNews, passiontimeslatestnewscorpus_org],
                    [post852LatestNews, post852latestnewscorpus_org]  ,
                    [hk01LatestNews, hk01latestnewscorpus_org]  ,
                    [nowLatestNews, nowlatestnewscorpus_org]  ,
                    [am730LatestNews, am730latestnewscorpus_org]  ,
                  ]








def updateArticleSimiliarities ( in_dictionary, in_newsArticleList , in_similaritesRatio, in_gong , in_starttime, in_endtime ):
  for indexArtList , indnewsArticle in enumerate(in_newsArticleList) :
    #indnewsArticle[1] is the corpus of the corresponding articlelist
    #print ('--> updateArticleSimiliarities 1 len of len(indnewsArticle)=%d, indexArtList=%d' %(len(indnewsArticle[1]), indexArtList) )
    print ('--> updateArticleSimiliarities 1 len of len(indnewsArticle)=%d, indexArtList=' %(len(indnewsArticle[1])) )

    print (' time 23 : ', datetime.now(timezone(timedelta(hours=8))) )

    similaritiesIndex = similarities.MatrixSimilarity(indnewsArticle[1], num_features = len(in_dictionary.items()))
    #similaritiesIndex = similarities.SparseMatrixSimilarity(indnewsArticle[1])
    #print ('updateArticleSimiliarities 2 ' )
    for crosscheckindexArtList , indcrosscheckRestPairofNewsArticle in enumerate(in_newsArticleList) :
      #print ('updateArticleSimiliarities 4 crosscheckindexArtList=%d' % crosscheckindexArtList )
      for indcorpusindex , indArticleCorpus in enumerate(indcrosscheckRestPairofNewsArticle[1] ) :
        #print ('updateArticleSimiliarities 5 len= ', len(indArticleCorpus) )
        indArticleCorpusSimValue = similaritiesIndex[indArticleCorpus]
        #print ('updateArticleSimiliarities 6 ' )
        sortedindArticleCorpusSimValue = sorted(list(enumerate(indArticleCorpusSimValue)) ,  key=lambda tu : -abs(tu[1]))
        #sortedindArticleCorpusSimValue[0] of tuple (indextoNewsArticleList, score) has the highest score
        if sortedindArticleCorpusSimValue[0][1] > in_similaritesRatio :
          #print ('updateArticleSimiliarities 7 ratio = ' , sortedindArticleCorpusSimValue[0][1])
          #set the related list
          #indcrosscheckRestPairofNewsArticle[0] list of NewsArticle
          #indnewsArticle[0] list of NewsArticle
          if indcrosscheckRestPairofNewsArticle[0][indcorpusindex][0] != indnewsArticle[0][sortedindArticleCorpusSimValue[0][0]][0] :
            articleTableIndexPair = [ indcrosscheckRestPairofNewsArticle[0][indcorpusindex][0] ,  indnewsArticle[0][sortedindArticleCorpusSimValue[0][0]][0] ]
            in_gong.setArticleSimilaritieslist(articleTableIndexPair )
            #print ('updateArticleSimiliarities 8 ' )



#startRangeTime = datetime(2017, 10, 8,0,0,0, tzinfo=timezone(timedelta(hours=8)))
#endRangeTime = datetime(2017, 11, 9,0,0,0, tzinfo=timezone(timedelta(hours=8)))
similaritesRatio = 0.35
updateArticleSimiliarities ( singtaodictionary, newsArticleList , similaritesRatio, gong , startRangeTime, endRangeTime )

print ("end time for gensim = ", datetime.now(timezone(timedelta(hours=8))) )












